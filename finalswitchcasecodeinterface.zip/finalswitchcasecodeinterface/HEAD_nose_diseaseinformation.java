public interface HEAD_nose_diseaseinformation {
    //nose
    //common cold
    //about
     String nose_Commoncold_title="The common cold";
    String nose_Commoncold_status="Very common";
    String nose_Commoncold_about="More than 10 million cases per year (India)\n" +
            "Spreads easily\n" +
            "Usually self-treatable\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging not required\n" +
            "Short-term: resolves within days to weeks\n";
    String nose_Commoncold_desc="The common cold is a viral infection of your nose and throat (upper respiratory tract). It's usually harmless, although it might not feel that way. Many types of viruses can cause a common cold.";
    String nose_Commoncold_card_desc="The common cold is a viral infection of your nose and throat (upper respiratory tract). It's usually harmless, although it might not feel that way. Many types of viruses can cause a common cold.";
    //symptoms
    String nose_Commoncold_cause_para1="Although many types of viruses can cause a common cold, rhinoviruses are the most common culprit.\n\n" +
            "A cold virus enters your body through your mouth, eyes or nose. The virus can spread through droplets in the air when someone who is sick coughs, sneezes or talks.\n\n" +
            "It also spreads by hand-to-hand contact with someone who has a cold or by sharing contaminated objects, such as utensils, towels, toys or telephones. If you touch your eyes, nose or mouth after such contact or exposure, you're likely to catch a cold.\n\n";
    String nose_Commoncold_symptoms_para1="Symptoms of a common cold usually appear one to three days after exposure to a cold-causing virus. Signs and symptoms, which can vary from person to person, might include:\n\n\n" +
            "•\tRunny or stuffy nose\n\n" +
            "•\tSore throat\n\n" +
            "•\tCough\n\n" +
            "•\tCongestion\n\n" +
            "•\tSlight body aches or a mild headache\n\n" +
            "•\tSneezing\n\n" +
            "•\tLow-grade fever\n\n";
    String nose_Commoncold_treatment_para1="There's no cure for the common cold. Antibiotics are of no use against cold viruses and shouldn't be used unless there's a bacterial infection. Treatment is directed at relieving signs and symptoms.\n\n" +
            "Pros and cons of commonly used cold remedies include:\n\n\n" +
            "•\tPain relievers. For fever, sore throat and headache, many people turn to acetaminophen (Tylenol, others) or other mild pain relievers. Use acetaminophen for the shortest time possible and follow label directions to avoid side effects.\n\n\n" +
            "Use caution when giving aspirin to children or teenagers. Children and teenagers recovering from chickenpox or flu-like symptoms should never take aspirin. This is because aspirin has been linked to Reye's syndrome, a rare but potentially life-threatening condition, in such children." +
            "\n" +
            "Consider giving your child over-the-counter (OTC) pain medications designed for infants or children. These include acetaminophen (Tylenol, Infant's Feverall, others) or ibuprofen (Pediatric Advil, Motrin Infant, others) to ease symptoms.\n" +
            "•\tDecongestant nasal sprays. Adults can use decongestant drops or sprays for up to five days. Prolonged use can cause rebound symptoms. Children younger than six shouldn't use decongestant drops or sprays.\n" +
            "•\tCough syrups. The Food and Drug Administration (FDA) and the American Academy of Pediatrics strongly recommends against giving OTC cough and cold medicines to children younger than age 4. There's no good evidence that these remedies are beneficial and safe for children.\n";
    String nose_Commoncold_prevention_para1="There's no vaccine for the common cold, but you can take common-sense precautions to slow the spread of cold viruses:\n\n\n" +
            "•\tWash your hands. Clean your hands thoroughly and often with soap and water, and teach your children the importance of hand-washing. If soap and water aren't available, use an alcohol-based hand sanitizer.\n\n" +
            "•\tDisinfect your stuff. Clean kitchen and bathroom countertops with disinfectant, especially when someone in your family has a cold. Wash children's toys periodically.\n\n" +
            "•\tUse tissues. Sneeze and cough into tissues. Discard used tissues right away, then wash your hands carefully.\n\n" +
            "Teach children to sneeze or cough into the bend of their elbow when they don't have a tissue. That way they cover their mouths without using their hands.\n\n" +
            "•\tDon't share. Don't share drinking glasses or utensils with other family members. Use your own glass or disposable cups when you or someone else is sick. Label the cup or glass with the name of the person with the cold.\n\n" +
            "•\tSteer clear of colds. Avoid close contact with anyone who has a cold.\n\n";
    //sinus
    String nose_Sinus_title="Sinus ";
    String nose_Sinus_status="Very common";
    String nose_Sinus_about="More than 10 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging rarely required\n" +
            "Short-term: resolves within days to weeks\n";
    String nose_Sinus_desc="Sinusitis is an inflammation or swelling of the tissue lining the sinuses. Healthy sinuses are filled with air. But when they become blocked and filled with fluid, germs can grow and cause an infection.";
    String nose_Sinus_card_desc="Sinusitis is an inflammation or swelling of the tissue lining the sinuses. Healthy sinuses are filled with air. But when they become blocked and filled with fluid, germs can grow and cause an infection.";
    String nose_Sinus_cause_para1="•\tThe common cold\n\n\n" +
            "•\tAllergic rhinitis, which is swelling of the lining of the nose\n\n" +
            "•\tSmall growths in the lining of the nose called nasal polyps\n\n" +
            "•\tA deviated septum, which is a shift in the nasal cavity\n\n";
    //treatment
    String nose_Sinus_symptoms_para1="You may have these symptoms for 12 weeks or more:\n\n\n" +
            "•\tA feeling of congestion or fullness in your face\n\n" +
            "•\tA nasal obstruction or nasal blockage\n\n" +
            "•\tPus in the nasal cavity\n\n" +
            "•\tFever\n\n" +
            "•\tRunny nose or discolored postnasal drainage\n\n" +
            "You may also have headaches, bad breath, and tooth pain. You may feel tired a lot.\n" +
            "Lots of things can cause symptoms like these. You'll need to see your doctor to find out if you have sinusitis.\n";
    String nose_Sinus_treatment_para1="Consult a Doctor if the symptoms worsen.";
    String nose_Sinus_prevention_para1="take care of your nose.\n\n" +
            " Wash your hands.\n\n" +
            " Use a saline spray when needed.\n\n";
    String nose_Sinus_homeremedies_para1="Home remedies to help relieve symptoms of a sinus infection (sinusitis) you should drink plenty of water, inhale steam and use a humidifier, take hot, steamy showers, use mentholated preparations such as Vicks Vapor Rub, and iIrrigate the sinuses once or twice a day using a Neti pot or Sterile Saline Mist Spray. Use only distilled water in your Neti-Pot. Do not use tap water in a Neti-Pot because it has caused serious infections.";

    //Influenza
    //about
    String nose_Influenza_title="Influenza(Flu)";
    String nose_Influenza_status="Very common";
    String nose_Influenza_about="More than 10 million cases per year (India)\n" +
            "Spreads easily\n" +
            "Partly preventable by vaccine\n" +
            "Usually self-treatable\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging rarely required\n" +
            "Short-term: resolves within days to weeks\n";
    String nose_Influenza_desc="Influenza is a viral infection that attacks your respiratory system — your nose, throat and lungs. Influenza is caused by three types of RNA viruses called influenza types A, B and C (considered different genera), which all belong to the family Orthomyxoviridae. The disease, colloquially called “flu” in humans, is generally caused by the viruses A and B, which are transmitted by aerosols from infected individuals or via close contact with infected animals.";
    String nose_Influenza_card_desc="Influenza is a viral infection that attacks your respiratory system — your nose, throat and lungs. Influenza is caused by three types of RNA viruses called influenza types A, B and C (considered different genera), which all belong to the family Orthomyxoviridae. ";
    //symptoms
    String nose_Influenza_cause_para1="Influenza is contagious, which means it can be spread easily from person to person. Viruses that cause influenza spread from person to person mainly by droplets of respiratory fluids sent through the air when someone infected with the virus coughs or sneezes. Other people inhale the airborne virus and can become infected.\n\n" +
            "Flu virus can live on some surfaces for up to 24 hours. This means that, in some cases, the flu can be spread when someone touches a surface (e.g., doorknobs, countertops, telephones) that has the virus on it and then touches their nose, mouth, or eyes. The flu is most easily spread in crowded places such as schools and offices.\n";
    String nose_Influenza_symptoms_para1="The symptoms of influenza (flu) appear suddenly and often include:\n\n" +
            "•\tFever of 100.4°F (38°C) to 104°F (40°C), which can reach 106°F (41°C)\n\n" +
            "•\tBody aches and muscle pain (often severe), commonly in the back, arms, or legs.\n\n" +
            "•\tInfants with the flu also may seem fussy all of a sudden or just “not look right.”\n\n" +
            "•\tPain when you move your eyes.\n\n" +
            "•\tFatigue, a general feeling of sickness (malaise).\n\n" +
            "•\tLoss of appetite.\n\n" +
            "•\tEar pain\n\n" +
            "•\tDiarrhea\n\n" +
            "•\tSore throat\n\n" +
            "•\tRunny nose\n\n" +
            "•\tA dry cough\n\n" +
            "•\tConfusion\n\n" +
            "•\tSevere vomiting\n\n" +
            "•\tNasal congestion\n\n";
    //treatment
    String nose_Influenza_treatment_para1="As flu is caused by a virus, antibiotics cannot help, unless the flu has led to another illness caused by bacteria. Antivirals, such as oseltamivir (Tamiflu) and zanamivir (Relenza), may be prescribed in some circumstances.\n\n" +
            "Painkillers can alleviate some of the symptoms, such as headache and body pains.\n\n" ;


    String nose_Influenza_treatment_para2="Some painkillers, such as aspirin, should not be given to children under 12.\n\n\n" +
            "Individuals with flu should:\n\n" +
            "•\tStay at home\n\n" +
            "•\tAvoid contact with other people where possible\n\n" +
            "•\tKeep warm and rest\n\n" +
            "•\tConsume plenty of liquids\n\n" +
            "•\tAvoid alcohol\n\n" +
            "•\tStop smoking\n\n" +
            "•\tEat if possible\n\n";
    String nose_Influenza_prevention_para1="You can reduce the risk of infection by getting vaccinated and practicing good hand and respiratory hygiene to protect yourself and others:\n\n\n" +
            "•\tStay home when you are sick\n\n" +
            "•\tWash your hands regularly with soap and water or use an alcohol-based hand rub\n\n" +
            "•\tWash your hands before touching your eyes, nose, and mouth\n\n" +
            "•\tUse a tissue, or the inside of your arm, when you cough and sneeze\n\n" +
            "•\tThrow tissues away immediately and wash hands\n\n" +
            "•\tDon’t share items such as cigarettes, cups, lipstick, toys, or anything which has come into contact with the mouth or nose\n\n" +
            "•\tStay at least 1 metre away from people who have flu-like symptoms\n\n" +
            "•\tClean frequently touched surfaces regularly, such as door handles, taps, tables, benches, and fridge doors (flu viruses can be removed using household detergent)\n\n";
//Nose Fracture
    //about
    String nose_Nosefracture_title="Nose Fracture";
    String nose_Nosefracture_status="" +
            "";

    String nose_Nosefracture_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging often required\n" +
            "Short-term: resolves within days to weeks\n";
    String nose_Nosefracture_desc="A broken nose, also called a nasal fracture, is a break or crack in a bone in your nose — often the bone over the bridge of your nose.";
    String nose_Nosefracture_card_desc="A broken nose, also called a nasal fracture, is a break or crack in a bone in your nose — often the bone over the bridge of your nose.";
    //symptoms
    String nose_Nosefracture_cause_para1="Common causes of a broken nose include contact sports, physical fights, falls and motor vehicle accidents that result in facial trauma. A broken nosecan cause pain, along with swelling and bruising around your nose and under your eyes. Your nose may look crooked, and you may have trouble breathing.";
    String nose_Nosefracture_symptoms_para1="Signs and symptoms of a broken nose:\n\n\n" +
            "•\tPain or tenderness, especially when touching your nose\n\n" +
            "•\tSwelling of your nose and surrounding areas\n\n" +
            "•\tBleeding from your nose\n\n" +
            "•\tBruising around your nose or eyes\n\n" +
            "•\tCrooked or misshapen nose\n\n" +
            "•\tDifficulty breathing through your nose\n\n" +
            "•\tDischarge of mucus from your nose\n\n" +
            "•\tFeeling that one or both of your nasal passages are blocked\n\n";
    String nose_nosefracture_homeremedies_para1="You can help prevent a nose fracture with these guidelines:\n\n" +
            "•\tWear your seat belt when traveling in a motorized vehicle, and keep children restrained in age-appropriate child safety seats.\n" +
            "•\tWear the recommended safety equipment, such as a helmet with a face mask, when playing hockey, football or other contact sports.\n" +
            "•\tWear a helmet during bicycle or motorcycle rides.\n" +
            "Treatment:\n";






}
