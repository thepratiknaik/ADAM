public interface HEAD_frontneck_diseasesinformation {
    // Tonsil
    //about
    String frontneck_Tonsil_title="Tonsillitis inflammation";
    String frontneck_Tonsil_status="Common";
    String frontneck_Tonsil_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging often required\n" +
            "Spreads easily\n" +
            "Short-term: resolves within days to weeks\n";
    String frontneck_Tonsil_desc="Tonsillitis is inflammation of the tonsils, two oval-shaped pads of tissue at the back of the throat — one tonsil on each side. Signs and symptoms of tonsillitis include swollen tonsils, sore throat, difficulty swallowing and tender lymph nodes on the sides of the neck.";
    String frontneck_Tonsil_card_desc="Tonsillitis is inflammation of the tonsils, two oval-shaped pads of tissue at the back of the throat — one tonsil on each side. Signs and symptoms of tonsillitis include swollen tonsils, sore throat, difficulty swallowing and tender lymph nodes on the sides of the neck.";
    String frontneck_Tonsil_cause_para1="Tonsillitis is most often caused by common viruses, but bacterial infections can also be the cause.\n\n" +
            "The most common bacterium causing tonsillitis is Streptococcus pyogenes (group A streptococcus), the bacterium that causes strep throat. Other strains of strep and other bacteria also may cause tonsillitis.\n";
    String frontneck_Tonsil_symptoms_para1="•\tRed, swollen tonsils\n\n" +
            "•\tWhite or yellow coating or patches on the tonsils\n\n" +
            "•\tSore throat\n\n" +
            "•\tDifficult or painful swallowing\n\n" +
            "•\tFever\n\n" +
            "•\tEnlarged, tender glands (lymph nodes) in the neck\n\n" +
            "•\tA scratchy, muffled or throaty voice\n\n" +
            "•\tBad breath\n\n" +
            "•\tStomachache, particularly in younger children\n\n" +
            "•\tStiff neck\n\n" +
            "•\tHeadache\n\n";
    String frontneck_Tosil_treatment_para1="•\tEncourage rest. Encourage your child to get plenty of sleep and to rest his or her voice.\n\n" +
            "•\tProvide adequate fluids. Give your child plenty of water to keep the throat moist and prevent dehydration.\n\n" +
            "•\tProvide comforting foods and beverage. Warm liquids — broth, caffeine-free tea or warm water with honey — and cold treats like ice pops can soothe a sore throat.\n\n" +
            "•\tPrepare a saltwater gargle. If your child can gargle, a saltwater gargle of 1 teaspoon (5 milliliters) of table salt to 8 ounces (237 milliliters) of warm water can help soothe a sore throat. Have your child gargle the solution and then spit it out.\n\n" +
            "•\tHumidify the air. Use a cool-air humidifier to eliminate dry air that may further irritate a sore throat, or sit with your child for several minutes in a steamy bathroom.\n\n" +
            "•\tOffer lozenges. Children older than age 4 can suck on lozenges to relieve a sore throat.\n\n" +
            "•\tAvoid irritants. Keep your home free from cigarette smoke and cleaning products that can irritate the throat.\n\n" +
            "•\tTreat pain and fever. Talk to your doctor about using ibuprofen (Advil, Motrin, others) or acetaminophen (Tylenol, others) to minimize throat pain and control a fever. Use caution when giving aspirin to children or teenagers\n";
    String frontneck_Tonsil_medication_para1="Antibiotics\n" +
            "If tonsillitis is caused by a bacterial infection, your doctor will prescribe a course of antibiotics. Penicillin taken by mouth for 10 days is the most common antibiotic treatment prescribed for tonsillitis caused by group A streptococcus. If your child is allergic to penicillin, your doctor will prescribe an alternative antibiotic.\n" +
            "Your child must take the full course of antibiotics as prescribed even if the symptoms go away completely. Failure to take all of the medication as directed may result in the infection worsening or spreading to other parts of the body. Not completing the full course of antibiotics can, in particular, increase your child's risk of rheumatic fever and serious kidney inflammation.\n" +
            "Talk to your doctor or pharmacist about what to do if you forget to give your child a dose.\n";
    String frontneck_Tonsil_suregery_desc="Surgery to remove tonsils (tonsillectomy) may be used to treat frequently recurring tonsillitis, chronic tonsillitis or bacterial tonsillitis that doesn't respond to antibiotic treatment. Frequent tonsillitis is generally defined as:\n" +
            "•\tMore than seven episodes in one year\n" +
            "•\tMore than five episodes a year in each of the preceding two years\n" +
            "•\tMore than three episodes a year in each of the preceding three years\n";
    String frontneck_Tonsil_homeremedies_para1="•\tWash his or her hands thoroughly and frequently, especially after using the toilet and before eating\n\n" +
            "•\tAvoid sharing food, drinking glasses or utensils\n";

//Strepthroat
//about
    String frontneck_Strepthroat_title=" Strep Throat";
    String frontneck_Strepthroat_status="very common";

    String frontneck_Strepthroat_desc="Strep throat is a bacterial throat infection that can make your throat feel sore and scratchy. Only a small portion of sore throats are the result of strep throat";
    String frontneck_Strepthroat_card_desc="Strep throat is a bacterial throat infection that can make your throat feel sore and scratchy. Only a small portion of sore throats are the result of strep throat";
    String frontneck_Strepthroat_cause_para1="The cause of strep throat is bacteria known as Streptococcus pyogenes, also known as group A streptococcus.\n\n" +
            "Streptococcal bacteria are highly contagious. They can spread through airborne droplets when someone with the infection coughs or sneezes, or through shared food or drinks. You can also pick up the bacteria from a doorknob or other surface and transfer them to your nose, mouth or eyes\n";
    String frontneck_Stepthroat_symptoms_para1="•\tThroat pain\n\n" +
            "•\tDifficulty swallowing\n\n" +
            "•\tRed and swollen tonsils, sometimes with white patches or streaks of pus\n\n" +
            "•\tTiny red spots on the soft or hard palate — the area at the back of the roof of the mouth\n\n" +
            "•\tSwollen, tender lymph glands (nodes) in your neck\n\n" +
            "•\tFever\n\n" +
            "•\tHeadache\n\n" +
            "•\tRash\n\n" +
            "•\tStomachache and sometimes vomiting, especially in younger children\n\n" +
            "•\tFatigue\n\n";
    String frontneck_Strepthroat_treatment_para1="If you or your child has strep throat, your doctor will likely prescribe an oral antibiotic such as:\n\n" +
            "•\tPenicillin. This drug may be given by injection in some cases — such as if you have a young child who is having a hard time swallowing or is vomiting.\n" +
            "•\tAmoxicillin. This drug is in the same family as penicillin, but is often a preferred option for children because it tastes better and is available as a chewable tablet.\n";
    String frontneck_Strepthroat_homeremedies_para1="•\tClean your hands. Proper hand cleaning is the best way to prevent all kinds of infections. That's why it's important to clean your own hands regularly and to teach your children how to clean their hands properly, using soap and water or an alcohol-based hand sanitizer.\n" +
            "•\tCover your mouth. Teach your children to cover their mouths when they cough or sneeze.\n" +
            "•\tDon't share personal items. If you or your child does have strep throat, don't share drinking glasses or eating utensils. Wash those items carefully in hot, soapy water or in a dishwasher\n";



}
