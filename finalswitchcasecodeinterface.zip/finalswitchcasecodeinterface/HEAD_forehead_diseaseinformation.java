public interface HEAD_forehead_diseaseinformation {
    //forehead
    //heatstroke
    //about
 String forehead_Heatstroke_title="Heatstroke";
    String forehead_Heatstroke_status="Common";
    String forehead_Heatstroke_about="More than 1 million cases per year (India)\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging always required\n" +
            "Treatment can help, but this condition can't be cured\n";
    String forehead_Heatstroke_desc="Heatstroke is a condition caused by your body overheating, usually as a result of prolonged exposure to or physical exertion in high temperatures. This most serious form of heat injury, heatstroke can occur if your body temperature rises to 104 F (40 C) or higher.";
    String forehead_Heatstroke_card_desc="Heatstroke is a condition caused by your body overheating, usually as a result of prolonged exposure to or physical exertion in high temperatures. This most serious form of heat injury, heatstroke can occur if your body temperature rises to 104 F (40 C) or higher.";
    //symptoms
    String forehead_Heatstroke_cause_para1="Heatstroke can occur as a result of:\n\n\n" +
            "•\tExposure to a hot environment. In a type of heatstroke, called nonexertional or classic heatstroke, being in a hot environment leads to a rise in body temperature. This type of heatstroke typically occurs after exposure to hot, humid weather, especially for prolonged periods, such as two or three days. It occurs most often in older adults and in people with chronic illness.\n\n" +
            "•\tStrenuous activity. Exertional heatstroke is caused by an increase in body temperature brought on by intense physical activity in hot weather. Anyone exercising or working in hot weather can get exertional heatstroke, but it's most likely to occur if you're not used to high temperatures.\n" +
            "In either type of heatstroke, your condition can be brought on by:\n\n\n" +
            "•\tWearing excess clothing that prevents sweat from evaporating easily and cooling your body\n\n" +
            "•\tDrinking alcohol, which can affect your body's ability to regulate your temperature\n\n" +
            "•\tBecoming dehydrated by not drinking enough water to replenish fluids lost through sweating\n\n";

    String forehead_Heatstroke_symptoms_para1="Heatstroke symptoms include:\n\n\n" +
            "•\tHigh body temperature. A body temperature of 104 F (40 C) or higher is the main sign of heatstroke.\n\n" +
            "•\tAltered mental state or behavior. Confusion, agitation, slurred speech, irritability, delirium, seizures and coma can all result from heatstroke.\n\n" +
            "•\tAlteration in sweating. In heatstroke brought on by hot weather, your skin will feel hot and dry to the touch. However, in heatstroke brought on by strenuous exercise, your skin may feel moist.\n\n" +
            "•\tNausea and vomiting. You may feel sick to your stomach or vomit.\n\n" +
            "•\tFlushed skin. Your skin may turn red as your body temperature increases.\n\n" +
            "•\tRapid breathing. Your breathing may become rapid and shallow.\n\n" +
            "•\tRacing heart rate. Your pulse may significantly increase because heat stress places a tremendous burden on your heart to help cool your body.\n\n" +
            "•\tHeadache. Your head may throb.\n";
    //treatment
    String forehead_Heatstroke_treatment_para1="Heatstroke treatment centers on cooling your body to a normal temperature to prevent or reduce damage to your brain and vital organs. To do this, your doctor may take these steps:\n\n\n" +
            "•\tImmerse you in cold water. A bath of cold or ice water can quickly lower your temperature.\n\n" +
            "•\tUse evaporation cooling techniques. Some doctors prefer to use evaporation instead of immersion to lower your body temperature. In this technique, cool water is misted on your skin while warm air fanned over your body causes the water to evaporate, cooling the skin.\n\n" +
            "•\tPack you with ice and cooling blankets. Another method is to wrap you in a special cooling blanket and apply ice packs to your groin, neck, back and armpits to lower your temperature.\n\n" +
            "•\tGive you medications to stop your shivering. If treatments to lower your body temperature make you shiver, your doctor may give you a muscle relaxant, such as a benzodiazepine. Shivering increases your body temperature, making treatment less effective.\n\n";
    String forehead_Heatstroke_homeremedies_para1="Heatstroke is predictable and preventable. Take these steps to prevent heatstroke during hot weather:\n\n\n" +
            "•\tWear loosefitting, lightweight clothing. Wearing excess clothing or clothing that fits tightly won't allow your body to cool properly.\n\n" +
            "•\tProtect against sunburn. Sunburn affects your body's ability to cool itself, so protect yourself outdoors with a wide-brimmed hat and sunglasses and use a broad-spectrum sunscreen with an SPF of at least 15. Apply sunscreen generously, and reapply every two hours — or more often if you're swimming or sweating.\n\n" +
            "•\tDrink plenty of fluids. Staying hydrated will help your body sweat and maintain a normal body temperature.\n\n" +
            "•\tTake extra precautions with certain medications.Be on the lookout for heat-related problems if you take medications that can affect your body's ability to stay hydrated and dissipate heat.\n\n" +
            "•\tNever leave anyone in a parked car. This is a common cause of heat-related deaths in children. When parked in the sun, the temperature in your car can rise 20 degrees F (more than 6.7 C) in 10 minutes.\n\n" +
            "It's not safe to leave a person in a parked car in warm or hot weather, even if the windows are cracked or the car is in shade. When your car is parked, keep it locked to prevent a child from getting inside.\n\n" +
            "•\tTake it easy during the hottest parts of the day. If you can't avoid strenuous activity in hot weather, drink fluids and rest frequently in a cool spot. Try to schedule exercise or physical labor for cooler parts of the day, such as early morning or evening.\n\n" +"•" +
            "\tGet acclimated. Limit time spent working or exercising in heat until you're conditioned to it. People who are not used to hot weather are especially susceptible to heat-related illness. It can take several weeks for your body to adjust to hot weather.\n\n";
    //meningitis
    //about

    String forehead_Meningitis_title="Meningitis";
    String forehead_Meningitis_status="Rare";
    String forehead_Meningitis_about="Fewer than 1 million cases per year (India)\n" +
            "Some types preventable by vaccine\n" +
            "Treatable by a medical professional\n" +
            "Spreads by airborne droplets\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging always required\n" +
            "Short-term: resolves within days to weeks\n";
    String forehead_Meningitis_desc="•\tMeningitis is an inflammation of the membranes (meninges) surrounding your brain and spinal cord.";
    String forehead_Meningitis_card_desc="•\tMeningitis is an inflammation of the membranes (meninges) surrounding your brain and spinal cord.";
    //symptoms
    String forehead_Meningitis_cause_para1="➢\tViral infection\n\n" +
            "➢\tBacterial infection\n\n" +
            "➢\tFungal infection(rarely)\n\n" +
            "➢\tDrug allergies\n\n" +
            "➢\tCancer\n\n";
    String forehead_Meningtis_symptoms_para1="➢\tSudden high fever\n\n" +
            "➢\tStiff neck\n\n" +
            "➢\tSevere headache that seems different than normal\n\n" +
            "➢\tHeadache with nausea or vomiting\n\n" +
            "➢\tConfusion or difficulty concentrating\n\n" +
            "➢\tSeizures\n\n" +
            "➢\tSleepiness or difficulty waking\n\n" +
            "➢\tSensitivity to light\n\n" +
            "➢\tNo appetite or thirst\n\n" +
            "➢\tSkin rash\n\n";
    //treatment
    String forehead_Meningitis_treatment_para1="➢\tConsult the doctor immediately.";
    String forehead_Meningitis_prevention_para1="These steps can help prevent meningitis:\n\n\n" +
            "•\tWash your hands. Careful hand-washing helps prevent the spread of germs. Teach children to wash their hands often, especially before eating and after using the toilet, spending time in a crowded public place or petting animals.\n \n" +
            "•\tPractice good hygiene. Don't share drinks, foods, straws, eating utensils, lip balms or toothbrushes with anyone else. Teach children and teens to avoid sharing these items too.\n\n" +
            "•\tStay healthy. Maintain your immune system by getting enough rest, exercising regularly, and eating a healthy diet with plenty of fresh fruits, vegetables and whole grains.\n\n" +
            "•\tCover your mouth. When you need to cough or sneeze, be sure to cover your mouth and nose.\n\n" +
            "•\tIf you're pregnant, take care with food.\n\n";

//headandneckcancer
    //about

    String forehead_Headneckcancer_title="Head and Neck Cancer";
    String forehead_Headneckcancer_status="Common";
    String forehead_Headneckcancer_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging always required\n";
    String forehead_Headneckcancer_desc="Head and neck cancers are a broad category of cancers that occur in the head and neck region.\n" +
            "Types of head and neck cancers include:\n" +
            "•\tEsthesioneuroblastoma\n" +
            "•\tFloor of mouth cancer\n" +
            "•\tLip cancer\n" +
            "•\tMouth cancer\n" +
            "•\tNasal cavity cancer\n" +
            "•\tNasopharyngeal cancer\n" +
            "•\tParanasal sinus cancer\n" +
            "•\tParathyroid cancer\n" +
            "•\tSalivary gland cancer\n" +
            "•\tSoft palate cancer\n" +
            "•\tThroat cancer\n" +
            "•\tThyroid cancer\n" +
            "•\tTongue cancer\n" +
            "•\tTonsil cancer\n";
    String forehead_Headneckcancer_card_desc="Head and Neck Cancer is growth of unwanted cells in certain body parts which is harmful for the body";
    //symptoms
    String forehead_Headneckcancer_symptoms_para1="Symptoms can occur in mouth, sinuses, nose or throat and include a sore or lump that doesn't heal, a persistent sore throat, trouble swallowing and changes in the voice.\n" +
            "People may experience:\n" +
            "Pain areas: in the ear\n" +
            "Also common: enlarged neck lymph nodes, hoarseness, or mouth ulcer\n";
    //treatment
    String forehead_Headneckcancer_treatment_para1="Treatment depends on the type, location and size of your cancer. Treatment for head and neck cancers often involves surgery, radiation therapy and chemotherapy. Rehabilitation specialists and other experts often work with people who experience hearing loss, difficulty eating or difficulty speaking as a result of head and neck cancers.\n" +
            "Consult the doctor immediately if above symptoms are detected.\n";
    String forehead_Headneckcancer_medication_para1="Chemotherapy\n\n" +
            "Kills cells that are growing or multiplying too quickly.\n" +
            "Medical procedure\n" +
            "PEG\n\n" +
            "Using a lighted medical instrument (endoscope) to insert a feeding tube through the abdominal wall and into the stomach.\n" +
            "Radiation therapy\n\n" +
            "Treatment that uses x-rays and other high-energy rays to kill abnormal cells.\n" ;

    String forehead_Headneckcancer_surgery_desc="Laryngectomy\n\n" +
            "Surgical removal of all or part of the voice box (larynx) in the throat.\n" +
            "Neck dissection\n\n" +
            "Surgical removal of lymph nodes in the neck.\n" +
            "Flap surgery\n\n" +
            "Surgically moving tissue from one part of the body to another. Often done to repair a wound or rebuild damaged tissue.\n";
//pharyngitis
    //about
    String forehead_Pharyngitis_title="Pharyngitis";
    String forehead_Pharyngitis_desc="Pharyngitis is inflammation of the pharynx, which is in the back of the throat. It’s most often referred to simply as “sore throat.” Pharyngitis can also cause scratchiness in the throat and difficulty swallowing.";
    String forehead_Pharyngitis_card_desc="Pharyngitis is inflammation of the pharynx, which is in the back of the throat. It’s most often referred to simply as “sore throat.” Pharyngitis can also cause scratchiness in the throat and difficulty swallowing.";
    //symptoms
    String forehead_Pharyngitis_cause_para1="There are numerous viral and bacterial agents that can cause pharyngitis. They include:\n\n\n" +
            "•\tmeasles\n\n" +
            "•\tadenovirus, which is one of the causes of the common cold\n\n" +
            "•\tchickenpox\n\n" +
            "•\tcroup, which is a childhood illness distinguished by a barking cough\n\n" +
            "•\twhooping cough\n\n" +
            "•\tgroup A streptococcus\n\n";
    String forehead_Pharyngitis_symptoms_para1="In addition to a sore, dry, or scratchy throat, a cold or flu may cause:\n\n\n" +
            "•\tsneezing\n\n" +
            "•\trunny nose\n\n" +
            "•\theadache\n\n" +
            "•\tcough\n\n" +
            "•\tfatigue\n\n" +
            "•\tbody aches\n\n" +
            "•\tchills\n\n" +
            "•\tfever (a low-grade fever with a cold and higher-grade fever with the flu)\n\n";
    String forehead_Pharyngitis_prevention_para1="To prevent pharyngitis:\n\n\n" +
            "•\tavoid sharing food, drinks, and eating utensils\n\n" +
            "•\tavoid individuals who are sick\n\n" +
            "•\twash your hands often, especially before eating and after coughing or sneezing\n\n" +
            "•\tuse alcohol-based hand sanitizers when soap and water aren’t available\n\n" +
            "•\tavoid smoking and inhaling secondhand smoke\n\n";
    //treatment
    String forehead_Pharyngitis_homeremedies_para1="If a virus is causing your pharyngitis, home care can help relieve symptoms. Home care includes:\n\n\n" +
            "•\tdrinking plenty of fluids to prevent dehydration\n\n" +
            "•\teating warm broth\n\n" +
            "•\tgargling with warm salt water (1 teaspoon of salt per 8 ounces of water)\n\n" +
            "•\tusing a humidifier\n\n" +
            "•\tresting until you feel better\n\n";


}
