public interface HEAD_mouth_diseaseinformation {


//mouth
   // Canker Sores
    //about

    String mouth_Crankersores_title="Cranker sore";
    String mouth_Crankersores_status="Very common";
    String mouth_Cankersores_about="More than 10 million cases per year (India)\n" +
            "Usually self-treatable\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging not required\n" +
            "Short-term: resolves within days to weeks\n";
    String mouth_Crankersores_desc="Canker sores, also called aphthous ulcers, are small, shallow lesions that develop on the soft tissues in your mouth or at the base of your gums. Unlike cold sores, canker sores don't occur on the surface of your lips and they aren't contagious. They can be painful, however, and can make eating and talking difficult.";
    String mouth_Crankersores_card_desc="Canker sores, also called aphthous ulcers, are small, shallow lesions that develop on the soft tissues in your mouth or at the base of your gums. Unlike cold sores, canker sores don't occur on the surface of your lips and they aren't contagious. They can be painful, however, and can make eating and talking difficult.";
    String mouth_Crankersores_cause_para1="Possible triggers for canker sores include:\n\n\n" +
            "•\tA minor injury to your mouth from dental work, overzealous brushing, sports mishaps or an accidental cheek bite\n\n" +
            "•\tToothpastes and mouth rinses containing sodium lauryl sulfate\n\n" +
            "•\tFood sensitivities, particularly to chocolate, coffee, strawberries, eggs, nuts, cheese, and spicy or acidic foods\n\n" +
            "•\tA diet lacking in vitamin B-12, zinc, folate (folic acid) or iron\n\n" +
            "•\tAn allergic response to certain bacteria in your mouth\n\n" +
            "•\tHelicobacter pylori, the same bacteria that cause peptic ulcers\n\n" +
            "•\tHormonal shifts during menstruation\n\n" +
            "•\tEmotional stress\n\n";
    String mouth_Crankersores_cause_para2="Canker sores may also occur because of certain conditions and diseases, such as:\n\n\n" +
            "•\tCeliac disease, a serious intestinal disorder caused by a sensitivity to gluten, a protein found in most grains\n\n" +
            "•\tInflammatory bowel diseases, such as Crohn's disease and ulcerative colitis\n\n" +
            "•\tBehcet's disease, a rare disorder that causes inflammation throughout the body, including the mouth\n\n" +
            "•\tA faulty immune system that attacks healthy cells in your mouth instead of pathogens, such as viruses and bacteria\n\n" +
            "•\tHIV/AIDS, which suppresses the immune system\n\n";
    String mouth_Crankersores_symptoms_para1="Most canker sores are round or oval with a white or yellow center and a red border. They form inside your mouth — on or under your tongue, inside your cheeks or lips, at the base of your gums, or on your soft palate. You might notice a tingling or burning sensation a day or two before the sores actually appear.\n\n" +
            "There are several types of canker sores, including minor, major and herpetiform sores.\n" +
            "Minor canker sores\n\n" +
            "Minor canker sores are the most common and:\n" +
            "•\tAre usually small\n" +
            "•\tAre oval shaped with a red edge\n" +
            "•\tHeal without scarring in one to two weeks\n" +
            "Major canker sores\n\n" +
            "Major canker sores are less common and:\n" +
            "•\tAre larger and deeper than minor canker sores\n" +
            "•\tAre usually round with defined borders, but may have irregular edges when very large\n" +
            "•\tCan be extremely painful\n" +
            "•\tMay take up to six weeks to heal and can leave extensive scarring\n" +
            "Herpetiform canker sores\n\n" +
            "Herpetiform canker sores are uncommon and usually develop later in life, but they're not caused by herpes virus infection. These canker sores:\n" +
            "•\tAre pinpoint size\n" +
            "•\tOften occur in clusters of 10 to 100 sores, but may merge into one large ulcer\n" +
            "•\tHave irregular edges\n" +
            "•\tHeal without scarring in one to two weeks\n";
    String mouth_Crankersores_treatment_para1="Treatment usually isn't necessary for minor canker sores, which tend to clear on their own in a week or two. But large, persistent or unusually painful sores often need medical care. A number of treatment options exist.\n" +
            "Mouth rinses\n\n" +
            "If you have several canker sores, your doctor may prescribe a mouth rinse containing the steroid dexamethasone (dek-suh-METH-uh-sown) to reduce pain and inflammation or lidocaine to reduce pain.\n";
    String mouth_Crankersores_treatment_para2="Topical products\n\n" +
            "Over-the-counter and prescription products (pastes, creams, gels or liquids) may help relieve pain and speed healing if applied to individual sores as soon as they appear. Some products have active ingredients, such as:\n" +
            "•\tBenzocaine (Anbesol, Kank-A, Orabase, Zilactin-B)\n" +
            "•\tFluocinonide (Lidex, Vanos)\n" +
            "•\tHydrogen peroxide (Orajel Antiseptic Mouth Sore Rinse, Peroxyl)\n" +
            "There are many other topical products for canker sores, including those without active ingredients. Ask your doctor or dentist for advice on which may work best for you.\n" +
            "Oral medications\n\n" +
            "Oral medications may be used when canker sores are severe or do not respond to topical treatments. These may include:\n" +
            "•\tMedications not intended specifically for canker sore treatment, such as the intestinal ulcer treatment sucralfate (Carafate) used as a coating agent and colchicine, which is normally used to treat gout.\n" +
            "•\tOral steroid medications when severe canker sores don't respond to other treatments. But because of serious side effects, they're usually a last resort.\n";
    String mouth_Crankersores_homeremedies_para1="Canker sores often recur, but you may be able to reduce their frequency by following these tips:\n\n\n" +
            "•\tWatch what you eat. Try to avoid foods that seem to irritate your mouth. These may include nuts, chips, pretzels, certain spices, salty foods and acidic fruits, such as pineapple, grapefruit and oranges. Avoid any foods to which you're sensitive or allergic.\n\n" +
            "•\tChoose healthy foods. To help prevent nutritional deficiencies, eat plenty of fruits, vegetables and whole grains.\n\n" +
            "•\tFollow good oral hygiene habits. Regular brushing after meals and flossing once a day can keep your mouth clean and free of foods that might trigger a sore. Use a soft brush to help prevent irritation to delicate mouth tissues, and avoid toothpastes and mouth rinses that contain sodium lauryl sulfate.\n\n" +
            "•\tProtect your mouth. If you have braces or other dental appliances, ask your dentist about orthodontic waxes to cover sharp edges.\n\n" +
            "•\tReduce your stress. If your canker sores seem to be related to stress, learn and use stress-reduction techniques, such as meditation and guided imagery.\n\n";
//Dry Mouth
    //about


    String mouth_Drymouth_title="Dry Mouth";
    String mouth_Drymouth_desc="Dry mouth, or xerostomia (zeer-o-STOE-me-uh), refers to any condition in which your mouth is unusually dry. Most often, dry mouth is the result of a decrease in saliva produced by the glands in your mouth (salivary glands), and it's frequently a side effect of medication. Less often, dry mouth may be caused by a condition that directly affects the salivary glands.";
    String mouth_Drymouth_card_desc="Dry mouth, or xerostomia (zeer-o-STOE-me-uh), refers to any condition in which your mouth is unusually dry. Most often, dry mouth is the result of a decrease in saliva produced by the glands in your mouth (salivary glands), and it's frequently a side effect of medication. Less often, dry mouth may be caused by a condition that directly affects the salivary glands.";
    String mouth_Drymouth_cause_para1="Dry mouth has numerous causes:\n\n\n" +
            "•\tMedications. Hundreds of medications, including many over-the-counter drugs, produce dry mouth as a side effect. Among the more likely types to cause problems are some of the drugs used to treat depression, nerve pain (neuropathy) and anxiety, as well as some antihistamines, decongestants, muscle relaxants and pain medications.\n\n" +
            "•\tAging. The aging process doesn't necessarily cause dry mouth. However, older people are more likely to take medications that may cause dry mouth, and they're more likely to have other health conditions that can cause dry mouth.\n\n" +
            "•\tCancer therapy. Chemotherapy drugs can change the nature of saliva and the amount produced. This may be temporary, with normal salivary flow returning after treatment has been completed. Radiation treatments to your head and neck can damage salivary glands, causing a marked decrease in saliva production. This can be temporary or permanent, depending on the radiation dose and area treated.\n\n" +
            "•\tNerve damage. An injury or surgery that causes nerve damage to your head and neck area can result in dry mouth.\n\n" +
            "•\tOther health conditions. Dry mouth can be a consequence of certain health conditions, including the autoimmune disease Sjogren's syndrome or HIV/AIDS. Stroke and Alzheimer's disease may cause a perception of dry mouth, even though the salivary glands are functioning normally. Snoring and breathing with your mouth open also can contribute to dry mouth.\n\n" +
            "•\tTobacco use. Smoking or chewing tobacco can increase dry mouth symptoms.\n\n" +
            "•\tMethamphetamine use. Methamphetamine use can cause severe dry mouth and damage to teeth, a condition also known as \"meth mouth.\"\n\n";
    String mouth_Drymouth_symptoms_para1="If you're not producing enough saliva, you may notice these signs and symptoms all or most of the time:\n\n\n" +
            "•\tDryness in your mouth or throat\n\n" +
            "•\tSaliva that seems thick and stringy\n\n" +
            "•\tBad breath\n\n" +
            "•\tDifficulty chewing, speaking and swallowing\n\n" +
            "•\tA changed sense of taste\n\n" +
            "•\tProblems wearing dentures\n\n" +
            "•\tMore frequent tooth decay\n\n" +
            "•\tGum irritation and gum disease\n\n";
    String mouth_Drymouth_treatment_para1="Your treatment depends on the cause of your dry mouth. Your doctor or dentist may:\n\n\n" +
            "•\tChange medications that cause dry mouth. If your doctor believes medication to be the cause, he or she may adjust your dosage or switch you to another medication that doesn't cause a dry mouth.\n" +
            "•\tRecommend products to moisturize your mouth.These can include prescription or over-the-counter mouth rinses, artificial saliva or moisturizers to lubricate your mouth.\n" +
            "If you have severe dry mouth, your doctor or dentist may:\n\n" +
            "•\tPrescribe medication that stimulates saliva. Your doctor may consider prescribing pilocarpine (Salagen) or cevimeline (Evoxac) to stimulate saliva production.\n" +
            "•\tProtect your teeth. To prevent cavities, your dentist might fit you for fluoride trays, which you fill with fluoride and wear over your teeth for a few minutes at night. Your dentist may also recommend weekly use of a chlorhexidine rinse to control cavities.\n";
    String mouth_Drymouth_homeremedies_para1="In addition to the advice from your doctor or dentist, these tips may help relieve your dry mouth symptoms:\n\n\n" +
            "•\tSip water or sugar-free drinks or suck ice chips throughout the day to moisten your mouth, and drink water during meals to aid chewing and swallowing.\n\n" +
            "•\tChew sugar-free gum or suck on sugar-free hard candies. However, in some people, xylitol, which is often found in sugar-free gum or sugar-free candies, may cause diarrhea or cramps if consumed in large amounts.\n\n" +
            "•\tTry over-the-counter saliva substitutes that contain carboxymethylcellulose (kahr-bok-see-meth-ul-SEL-u-lohs) or hydroxyethyl cellulose (hi-drok-see-ETH-ul SEL-u-lohs), such as Biotene Oral Balance.\n\n" +
            "•\tBreathe through your nose, not your mouth. You may need to seek treatment for snoring that causes you to breathe through your mouth during the night.\n\n" +
            "•\tAdd moisture to the air at night with a room humidifier.\n\n" +
            "•\tMoisturize your lips to soothe dry or cracked areas.\n\n";
    String mouth_Drymouth_alternative_desc="Several herbal remedies have been used historically to treat dry mouth, such as teas made from marshmallow or slippery elm, but there are no recent studies showing benefit or harm in using them for dry mouth.\n\n" +
            "Electroacupuncture, which involves stimulating traditional acupuncture points on the skin using electrodes rather than the traditional needles, looks promising in some studies on dry mouth treatment. However, researchers are still working to determine whether this therapy is truly better than others for dry mouth.\n";
    //TrenchMouth
    //about
    String mouth_TrenchMouth_title="Treanch Mouth";
    String mouth_Trenchmouth_desc="Trench mouth is a severe form of gingivitis that causes painful, infected, bleeding gums and ulcerations. Although trench mouth is rare today in developed nations, it's common in developing countries that have poor nutrition and poor living conditions.";
    String mouth_Trenchmouth_card_desc="Trench mouth is a severe form of gingivitis that causes painful, infected, bleeding gums and ulcerations. Although trench mouth is rare today in developed nations, it's common in developing countries that have poor nutrition and poor living conditions.";
    //symptoms
    String mouth_Trenchmouth_cause_para1="Your mouth naturally contains microorganisms, including fungi, viruses and bacteria. If your immune system, which fights infections, is weak, its ability to fight harmful bacteria is lowered. This can result in trench mouth, where harmful bacteria grow out of control, causing infection of your gums. This infection can damage or destroy the delicate gum tissue (gingiva) that surrounds and supports your teeth.\n\n" +
            "Large ulcers, often filled with bacteria, food debris and decaying tissue, may form on your gums, leading to severe pain, bad breath and a foul taste in your mouth. Exactly how these bacteria destroy gum tissue isn't known, but it's likely that enzymes and toxins produced by the bacteria play a role\n";
    String mouth_Trenchmouth_symptoms_para1="Signs and symptoms of trench mouth can include:\n\n\n" +
            "•\tSevere gum pain\n\n" +
            "•\tBleeding from gums when they're pressed even slightly\n\n" +
            "•\tRed or swollen gums\n\n" +
            "•\tPain when eating or swallowing\n\n" +
            "•\tGray film on your gums\n\n" +
            "•\tCrater-like sores (ulcers) between your teeth and on your gums\n\n" +
            "•\tFoul taste in your mouth\n\n" +
            "•\tBad breath\n\n" +
            "•\tFever and fatigue (malaise)\n\n" +
            "•\tSwollen lymph nodes around your head, neck or jaw\n\n";
    //treatment
    String mouth_Trenchmouth_treatment_para1="Treatment of trench mouth is generally highly effective, and complete healing often occurs in just a couple of weeks. However, healing may take longer if your immune system is weakened, such as by HIV/AIDS.";
    String mouth_Trenchmouth_medication_para1="•\tAntibiotics. Because trench mouth involves an overgrowth of bacteria, antibiotics are often prescribed to get rid of the bacteria and prevent infection from spreading.\n\n" +
            "•\tPain relievers. You may also need an over-the-counter or prescription pain reliever. Getting pain under control is important so you can eat properly and resume good dental care habits, such as brushing your teeth and flossing. Your dentist may also recommend a pain reliever that you can apply directly to your gums (topical anesthetic).\n\n" +
            "•\tAntiseptic mouth wash. Prescription antiseptic mouthwash containing chlorhexidine can decrease the bacterial count, speeding recovery.\n\n" +
            "Cleaning your teeth and gums\n\n" +
            "Treatment also includes a thorough but gentle cleaning of your teeth and gums. Your mouth may be rinsed with an antiseptic solution. When your gums are less tender, you'll have a type of tooth cleaning called scaling and root planing. This procedure removes plaque and tartar from beneath your gumline and smooths any roughened surfaces of your teeth that catch bacteria.\n\n" +
            "Right after cleaning, your gums will be quite tender. Your dentist will probably advise you to rinse your mouth with a hydrogen peroxide mouthwash, salt water or a prescription mouth rinse, in addition to brushing gently with a soft toothbrush. Once your gums begin to heal, brush and floss at least twice a day — preferably after every meal and at bedtime — to prevent future problems.\n" +
            "When surgery is necessary\n\n" +
            "Although your gums are likely to heal and return to their normal shape with professional cleaning and proper home care, you may need surgery to help repair them if you have extensive damage.\n";
    String mouth_Trenchmouth_medication_para2="\n";
    String mouth_Trenchmouth_homeremedies_para1="•\tPractice good oral hygiene. Brush and floss your teeth at least twice a day or as often as your dentist recommends. Get regular professional dental cleanings. Antiseptic mouthwashes also may be helpful. Some studies show that an electric toothbrush may be more effective than a manual toothbrush.\n\n" +
            "•\tDon't smoke or use other tobacco products.Tobacco products are a leading factor in the development of trench mouth.\n\n" +
            "•\tEat a healthy diet. Include plenty of fruits and vegetables, choose whole grains instead of refined grains, eat healthy protein such as fish or legumes, and opt for low-fat dairy foods.\n\n" +
            "•\tManage stress. Because stress takes both a physical and an emotional toll, learning to manage it is essential for your overall well-being. Exercise, relaxation techniques, yoga and hobbies are examples of healthy ways to cope with stress.\n\n";
    //BurningMouth
    //about

    String mouth_Burningmouth_title="Burning Mouth";
    String mouth_Burningmouth_desc="Burning mouth syndrome is the medical term for ongoing (chronic) or recurrent burning in the mouth without an obvious cause. The discomfort may affect your tongue, gums, lips, inside of your cheeks, roof of your mouth or widespread areas of your whole mouth. Burning mouth syndrome appears suddenly and can be severe, as if you scalded your mouth.";
    String mouth_Burningmouth_card_desc="Burning mouth syndrome is the medical term for ongoing (chronic) or recurrent burning in the mouth without an obvious cause. The discomfort may affect your tongue, gums, lips, inside of your cheeks, roof of your mouth or widespread areas of your whole mouth. Burning mouth syndrome appears suddenly and can be severe, as if you scalded your mouth.";
    String mouth_Burningmouth_cause_para1="The cause of burning mouth syndrome can be classified as either primary or secondary.\n\n\n" +
            "Primary burning mouth syndrome\n\n" +
            "When no clinical or lab abnormalities can be identified, the condition is called primary or idiopathic burning mouth syndrome. Some research suggests that primary burning mouth syndrome is related to problems with taste and sensory nerves of the peripheral or central nervous system.\n" +
            "Secondary burning mouth syndrome\n\n" +
            "Sometimes burning mouth syndrome is caused by an underlying medical condition. In these cases, it's called secondary burning mouth syndrome\n";
    String mouth_Burningmouth_cause_para2="Underlying problems that may be linked to secondary burning mouth syndrome include:\n\n" +
            "•\tDry mouth (xerostomia), which can be caused by various medications, health problems, problems with salivary gland function or the side effects of cancer treatment\n" +
            "•\tOther oral conditions, such as a fungal infection of the mouth (oral thrush), an inflammatory condition called oral lichen planus, or a condition called geographic tongue that gives the tongue a map-like appearance\n" +
            "•\tNutritional deficiencies, such as lack of iron, zinc, folate (vitamin B-9), thiamin (vitamin B-1), riboflavin (vitamin B-2), pyridoxine (vitamin B-6) and cobalamin (vitamin B-12)\n" +
            "•\tDentures, especially if they don't fit well, which can place stress on some muscles and tissues of your mouth, or if they contain materials that irritate mouth tissues\n" +
            "•\tAllergies or reactions to foods, food flavorings, other food additives, fragrances, dyes or dental-work substances\n" +
            "•\tReflux of stomach acid (gastroesophageal reflux disease or GERD) that enters your mouth from your stomach\n" +
            "•\tCertain medications, particularly high blood pressure medications called angiotensin-converting enzyme (ACE) inhibitors\n" +
            "•\tOral habits, such as tongue thrusting, biting the tip of the tongue and teeth grinding (bruxism)\n" +
            "•\tEndocrine disorders, such as diabetes or underactive thyroid (hypothyroidism)\n" +
            "•\tExcessive mouth irritation, which may result from overbrushing your tongue, using abrasive toothpastes, overusing mouthwashes or having too many acidic drinks, such as lemon\n" +
            "•\tPsychological factors, such as anxiety, depression or stress.\n";
    String mouth_Burningmouth_symptoms_para1="•\tA burning sensation that most commonly affects your tongue, but may also affect your lips, gums, palate, throat or whole mouth\n\n" +
            "•\tA sensation of dry mouth with increased thirst\n\n" +
            "•\tTaste changes, such as a bitter or metallic taste\n\n" +
            "•\tLoss of taste\n\n";
    String mouth_Burningmouth_treatment_para1="There's no one test that can determine if you have burning mouth syndrome. Instead, your doctor or dentist will try to rule out other problems before diagnosing burning mouth syndrome.\n" +
            "Your doctor or dentist will review your medical history and medications, examine your mouth, and ask you to describe your symptoms, oral habits and oral care routine. In addition, your doctor will likely perform a general medical exam, looking for signs of other conditions.\n" +
            "You may have some of the following tests:\n" +
            "•\tBlood tests. Blood tests can check your complete blood count, glucose level, thyroid function, nutritional factors and immune functioning, all of which may provide clues about the source of your mouth discomfort.\n" +
            "•\tOral cultures or biopsies. Taking samples from your mouth can tell whether you have a fungal, bacterial or viral infection.\n" +
            "•\tAllergy tests. Your doctor may suggest allergy testing to see if you may be allergic to certain foods, additives or even substances in dentures.\n" +
            "•\tSalivary measurements. With burning mouth syndrome, you may feel that you have a dry mouth. Salivary tests can confirm whether you have a reduced salivary flow.\n" +
            "•\tGastric reflux tests. These can determine if you have gastroesophageal reflux disease (GERD).\n" +
            "•\tImaging. Your doctor may recommend an MRI, CT scan or other imaging tests to check for other health problems.\n" +
            "•\tTemporarily stopping medication. If you take medications that may contribute to mouth discomfort, your doctor may suggest temporarily stopping those medications, if possible, to see if your discomfort goes away. Don't try this on your own, since it can be dangerous to stop some medications.\n" +
            "•\tPsychological questionnaires. You may be asked to fill out questionnaires that can help determine if you have symptoms of depression, anxiety or other mental health conditions.\n";
    String mouth_Burningmouth_treatment_para2="/n";
    String mouth_Burningmouth_homeremedies_para1="There's no known way to prevent burning mouth syndrome. But by avoiding tobacco, acidic foods, spicy foods and carbonated beverages, and excessive stress, you may be able to reduce the discomfort from burning mouth syndrome or prevent your discomfort from getting worse.";
    String mouth_Burningmouth_coping_para1="Burning mouth syndrome can be uncomfortable and frustrating. It can reduce your quality of life if you don't take steps to stay positive and hopeful.\n" +
            "Consider some of these techniques to help cope with the chronic discomfort of burning mouth syndrome:\n" +
            "\n" +
            "•\tPractice relaxation exercises, such as yoga.\n" +
            "•\tJoin a chronic pain support group.\n" +
            "•\tEngage in pleasurable activities, such as physical activities or hobbies, especially when you feel anxious.\n" +
            "•\tTry to stay socially active by connecting with understanding family and friends.\n";



    //MouthCancer


    String mouth_Mouthcancer_title="Mouth Cancer";
    String mouth_Mouthcancer_status="Common";
    String mouth_Mouthcancer_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging always required\n";
    String mouth_Mouthcancer_desc="Mouth cancer refers to cancer that develops in any of the parts that make up the mouth. Mouth cancer can occur on the:\n" +
            "•\tLips\n" +
            "•\tGums\n" +
            "•\tTongue\n" +
            "•\tInside lining of the cheeks\n" +
            "•\tRoof of the mouth\n" +
            "•\tFloor of the mouth\n" +
            "Cancer that occurs on the inside of the mouth is sometimes called oral cancer or oral cavity cancer\n";
    String mouth_Mouthcancer_card_desc="Mouth cancer refers to cancer that develops in any of the parts that make up the mouth";
    String mouth_Mouthcancer_cause_para1="Mouth cancer occurs when cells on your lips or in your mouth develop changes (mutations) in their DNA. These mutations allow cancer cells to grow and divide when healthy cells would die. The accumulating mouth cancer cells can form a tumor. With time they may spread to other areas of the mouth and on to other areas of the head and neck or other parts of the body.\n\n" +
            "Mouth cancers most commonly begin in the flat, thin cells (squamous cells) that line your lips and the inside of your mouth. Most oral cancers are squamous cell carcinomas.\n\n" +
            "It's not clear what causes the mutations in squamous cells that lead to mouth cancer. But doctors have identified factors that may increase the risk of mouth cancer.\n\n";
    String mouth_Mouthcancer_symptoms_para1="Signs and symptoms of mouth cancer may include:\n\n\n" +
            "•\tA sore that doesn't heal\n\n" +
            "•\tA lump or thickening of the skin or lining of your mouth\n\n" +
            "•\tA white or reddish patch on the inside of your mouth\n\n" +
            "•\tLoose teeth\n\n" +
            "•\tPoorly fitting dentures\n\n" +
            "•\tTongue pain\n\n" +
            "•\tJaw pain or stiffness\n\n" +
            "•\tDifficult or painful chewing\n\n" +
            "•\tDifficult or painful swallowing\n\n" +
            "•\tSore throat\n\n" +
            "•\tFeeling that something is caught in your throat\n\n";
    String mouth_Mouthcancer_treatment_para1="Treatment for mouth cancer depends on your cancer's location and stage, as well as your overall health and personal preferences. You may have just one type of treatment, or you may undergo a combination of cancertreatments. Discuss your options with your doctor";
    String mouth_Mouthcancer_surgery_desc="•\tSurgery to remove the tumor. Your surgeon may cut away the tumor and a margin of healthy tissue that surrounds it. Smaller cancers may be removed through minor surgery. Larger tumors may require more-extensive procedures. For instance, removing a larger tumor may involve removing a section of your jawbone or a portion of your tongue.\n\n" +
            "•\tSurgery to remove cancer that has spread to the neck. If cancer cells have spread to the lymph nodes in your neck, your surgeon may recommend a procedure to remove cancerous lymph nodes and related tissue in the neck (neck dissection).\n\n" +
            "•\tSurgery to reconstruct the mouth. After an operation to remove your cancer, your surgeon may recommend reconstructive surgery to restore the appearance of your face or to help you regain the ability to talk and eat. Your surgeon may transplant grafts of skin, muscle or bone from other parts of your body to reconstruct your face. Dental implants may replace your natural teeth.\n\n";
    String mouth_Mouthcancer_chemotherapy_title="Chemotherapy";
    String mouth_Mouthcancer_chemotheraphy_desc="Chemotherapy is a treatment that uses chemicals to kill cancer cells. Chemotherapy drugs can be given alone, in combination with other chemotherapy drugs or in combination with other cancer treatments. Chemotherapy may increase the effectiveness of radiation therapy, so the two are often combined.\n" +
            "Side effects of chemotherapy depend on which drugs you receive. Common side effects include nausea, vomiting and hair loss\n";
    String mouth_Mouthcancer_radiationtheraphy_title="Radiation Theraphy";
    String mouth_Mouthcancer_radiationtherphy_desc="Radiation therapy uses high-energy beams, such as X-rays, to kill cancer cells. Radiation therapy can be delivered from a machine outside of your body (external beam radiation) or from radioactive seeds and wires placed near your cancer (brachytherapy).\n\n" +
            "Radiation therapy may be the only treatment you receive if you have an early-stage mouth cancer. Radiation therapy can also be used after surgery. In other cases, radiation therapy may be combined with chemotherapy. This combination increases the effectiveness of radiation therapy, but it also increases the side effects you may experience. In cases of advanced mouth cancer, radiation therapy may help relieve signs and symptoms caused by the cancer, such as pain.\n\n" +
            "Side effects of radiation therapy to your mouth may include dry mouth, tooth decay, mouth sores, bleeding gums, jaw stiffness, fatigue and red, burn-like skin reactions.\n\n";
    String mouth_Mouthcancer_homeremedies_para1="•\tStop using tobacco or don't start. If you use tobacco, stop. If you don't use tobacco, don't start. Using tobacco, whether smoked or chewed, exposes the cells in your mouth to dangerous cancer-causing chemicals.\n\n" +
            "•\tDrink alcohol only in moderation, if at all. Chronic excessive alcohol use can irritate the cells in your mouth, making them vulnerable to mouth cancer. If you choose to drink alcohol, limit yourself to one drink a day if you're a woman or two drinks a day if you're a man.\n\n" +
            "•\tEat a variety of fruits and vegetables. Choose a diet rich in fruits and vegetables. The vitamins and antioxidants found in fruits and vegetables may help reduce your risk of mouth cancer.\n\n" +
            "•\tAvoid excessive sun exposure to your lips.Protect the skin on your lips from the sun by staying in the shade when possible. Wear a broad-brimmed hat that effectively shades your entire face, including your mouth. Apply a sunscreen lip product as part of your routine sun protection regimen.\n\n" +
            "•\tSee your dentist regularly. As part of a routine dental exam, ask your dentist to inspect your entire mouth for abnormal areas that may indicate mouth cancer or precancerous changes\n\n";
 String mouth_Mouthcancer_alternative_para1="No complementary or alternative medicine treatments can cure mouth cancer. But complementary and alternative medicine treatments may help you cope with mouth cancer and the side effects of cancer treatment."+
         "•\tExercise. Try gentle exercise for 30 minutes on most days of the week. Moderate exercise, such as brisk walking, during and after cancertreatment reduces fatigue. Talk to your doctor before you begin exercising, to make sure it's safe for you.\n\n" +
         "•\tMassage therapy. During a massage, a massage therapist uses his or her hands to apply pressure to your skin and muscles. Some massage therapists are specially trained to work with people who have cancer. Ask your doctor for names of massage therapists in your community\n.\n" +
         "•\tRelaxation. Activities that help you feel relaxed may help you cope. Try listening to music or writing in a journal.\n";
String mouth_Mouthcancer_coping_para1="•\tLearn enough about mouth cancer to make treatment decisions. Make a list of questions to ask at your next appointment. Bring a recorder or a friend to help you take notes. Ask your doctor about books or websites to turn to for information. The more you know about your cancer and your treatment options, the more confident you'll feel as you make treatment decisions.\n\n" +
        "•\tTalk to other mouth cancer survivors. Connect with people who understand what you're going through. Ask your doctor about support groups for people with cancer in your community. Or contact your local chapter of the American Cancer Society. Another option is online message boards, such as those run by the Oral Cancer Foundation.\n\n" +
        "•\tTake time for yourself. Set aside time for yourself each day. Use this time to take your mind off your cancer and do what makes you happy. Even a short break for some relaxation in the middle of a day full of tests and scans may help you cope.\n\n" +
        "•\tKeep family and friends close. Friends and family can provide both emotional and practical support as you go through treatment. Your friends and family will likely ask you what they can do to help. Take them up on their offers. Think ahead to ways you might like help, whether it's asking a friend to prepare a meal for you or asking a family member to be there when you need someone to talk with\n\n";






}
