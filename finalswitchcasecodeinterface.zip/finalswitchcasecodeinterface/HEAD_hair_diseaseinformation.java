public interface HEAD_hair_diseaseinformation {
    //hair
    //dandruff
    //about
    String HAIR_Dandruff_title="Dandruff";
    String HAIR_Dandruff_status="Common";
    String HAIR_Dandruff_desc="Dandruff is a common chronic scalp condition marked by flaking of the skin on your scalp. Although dandruff isn't contagious and is rarely serious, it can be embarrassing and sometimes difficult to treat.";
    String HAIR_Dandruff_card_desc="Dandruff is a common chronic scalp condition marked by flaking of the skin on your scalp. Although dandruff isn't contagious and is rarely serious, it can be embarrassing and sometimes difficult to treat.";
    //SYMPTOMS
    String HAIR_Dandruff_cause_para1="Dandruff can have several causes, including:\n\n\n" +
            "•\tDry skin. Simple dry skin is the most common cause of dandruff. Flakes from dry skin are generally smaller and less oily than those from other causes of dandruff, and you'll likely have symptoms and signs of dry skin on other parts of the body, such as your legs and arms.\n\n" +
            "•\tIrritated, oily skin (seborrheic dermatitis). This condition, one of the most frequent causes of dandruff, is marked by red, greasy skin covered with flaky white or yellow scales. Seborrheic dermatitis may affect your scalp and other areas rich in oil glands, such as your eyebrows, the sides of your nose and the backs of your ears, your breastbone, your groin area, and sometimes your armpits.\n\n" +
            "•\tNot shampooing often enough. If you don't regularly wash your hair, oils and skin cells from your scalp can build up, causing dandruff.\n\n" +
            "•\tOther skin conditions. People with skin conditions such as eczema — a chronic, inflammatory skin condition — or psoriasis — a skin condition marked by a rapid buildup of rough, dry, dead skin cells that form thick scales — may appear to have dandruff.\n\n" +
            "•\tA yeast-like fungus (malassezia). Malassezia lives on the scalps of most adults, but for some, it irritates the scalp. This can irritate your scalp and cause more skin cells to grow. The extra skin cells die and fall off, making them appear white and flaky in your hair or on your clothes. Why malassezia irritates some scalps isn't known.\n\n" +
            "•\tSensitivity to hair care products (contact dermatitis). Sometimes sensitivities to certain ingredients in hair care products or hair dyes, especially paraphenylenediamine, can cause a red, itchy, scaly scalp. Shampooing too often or using too many styling products also may irritate your scalp, causing dandruff.\n\n";
   String HAIR_Dandruff_symptoms_para1="For most teens and adults, dandruff symptoms are easy to spot: white, oily looking flakes of dead skin that dot your hair and shoulders, and a possibly itchy, scaly scalp. The condition may worsen during the fall and winter, when indoor heating can contribute to dry skin, and improve during the summer.\n\n" +
           "A type of dandruff called cradle cap can affect babies. This disorder, which causes a scaly, crusty scalp, is most common in newborns, but it can occur anytime during infancy. Although it can be alarming for parents, cradle cap isn't dangerous and usually clears up on its own by the time a baby is 3 years old.\n";

    //TREATMENT
    String HAIR_Dandruff_treatment_para1="Dandruff can almost always be controlled, but dandruff treatment may take patience and persistence. In general, daily cleansing with a gentle shampoo to reduce oiliness and skin cell buildup can often help mild dandruff.\n\n" +
            "When regular shampoos fail, dandruff shampoos you can buy at a drugstore may succeed. But dandruff shampoos aren't all alike, and you may need to experiment until you find one that works for you. If you develop itching, stinging, redness or burning from any product, stop using it. If you develop an allergic reaction, such as a rash, hives or difficulty breathing, seek immediate medical attention.\n";
    String HAIR_Dandruff_treatment_para2="Dandruff shampoos are classified according to the medication they contain:\n\n\n" +
            "•\tZinc pyrithione shampoos (such as Head & Shoulders, Jason Dandruff Relief 2 in 1, others).These contain the antibacterial and antifungal agent zinc pyrithione, which can reduce the fungus on your scalp that can cause dandruff and seborrheic dermatitis.\n\n" +
            "•\tTar-based shampoos (such as Neutrogena T/Gel). Coal tar, a byproduct of the coal manufacturing process, helps conditions such as dandruff, seborrheic dermatitis and psoriasis by slowing how quickly skin cells on your scalp die and flake off.\n\n" +
            "•\tShampoos containing salicylic acid (such as Neutrogena T/Sal). These scalp scrubs help eliminate scale, but they may leave your scalp dry, leading to more flaking. Using a conditioner after shampooing can help relieve dryness.\n\n" +
            "•\tSelenium sulfide shampoos (such as Selsun Blue). These shampoos slow your skin cells from dying and may also reduce malassezia. Because they can discolor blond, gray or chemically colored hair, be sure to use them only as directed, and rinse well after shampooing.\n\n" +
            "•\tKetoconazole shampoos (such as Nizoral).Ketoconazole is a broad-spectrum antifungal agent that may work when other shampoos fail. It's available over-the-counter as well as by prescription.\n";
    String HAIR_Dandruff_homeremedies_para1="In addition to regular shampooing, you can take steps to reduce your risk of developing dandruff:\n\n\n" +
            "•\tLearn to manage stress. Stress affects your overall health, making you susceptible to a number of conditions and diseases. It can even help trigger dandruff or worsen existing symptoms.\n\n" +
            "•\tShampoo often. If you tend to have an oily scalp, daily shampooing may help prevent dandruff.\n\n" +
            "•\tCut back on styling products. Hair sprays, styling gels, mousses and hair waxes can all build up on your hair and scalp, making them oilier.\n\n" +
            "•\tEat a healthy diet. A diet that provides enough zinc, B vitamins and certain types of fats may help prevent dandruff.\n\n" +
            "•\tGet a little sun. Sunlight may be good for dandruff. But because exposure to ultraviolet light damages your skin and increases your risk of skin cancer, don't sunbathe. Instead, just spend a little time outdoors. And be sure to wear sunscreen on your face and body.\n";
    String HAIR_Dandruff_alternative_desc="One alternative therapy that has been shown to reduce dandruff in small studies is daily shampooing with tea tree oil. More study is needed.\n\n" +
            "Tea tree oil, which comes from the leaves of the Australian tea tree (Melaleucaalternifolia), has been used for centuries as an antiseptic, antibiotic and antifungal agent. It's now included in a number of shampoos found in natural foods stores. The oil may cause allergic reactions in some people.\n";


    //hairloss
    //about
    String HAIR_Hairloss_title="Hair Loss ";
    String HAIR_Hairloss_status="Very common";
    String HAIR_Hairloss_about="More than 10 million cases per year (India)\n" +
            "Treatment can help, but this condition can't be cured\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging not required\n" +
            "Chronic: can last for years or be lifelong\n";
    String HAIR_Hairloss_desc="Hair loss can affect just your scalp or your entire body. It can be the result of heredity, hormonal changes, medical conditions or medications. Anyone men, women and children — can experience hair loss.";
    String HAIR_Hairloss_card_desc="Hair loss can affect just your scalp or your entire body. It can be the result of heredity, hormonal changes, medical conditions or medications. Anyone men, women and children — can experience hair loss.";
    //symptoms
    String HAIR_Hairloss_cause_para1="Most people normally shed 50 to 100 hairs a day. This usually doesn't cause noticeable thinning of scalp hair because new hair is growing in at the same time. Hair loss occurs when this cycle of hair growth and shedding is disrupted or when the hair follicle is destroyed and replaced with scar tissue.\n\n" +
            "The exact cause of hair loss may not be fully understood, but it's usually related to one or more of the following factors:\n\n" +
            "•\tFamily history (heredity)\n" +
            "•\tHormonal changes\n" +
            "•\tMedical conditions\n" +
            "•\tMedications\n\n" +
            "Family history (heredity)\n" +
            "The most common cause of hair loss is a hereditary condition called male-pattern baldness or female-pattern baldness. It usually occurs gradually and in predictable patterns — a receding hairline and bald spots in men and thinning hair in women.\n\n" +
            "Heredity also affects the age at which you begin to lose hair, the rate of hair loss and the extent of baldness. Pattern baldness is most common in men and can begin as early as puberty. This type of hair loss may involve both hair thinning and miniaturization (hair becomes soft, fine and short).\n\n";
    String HAIR_hairloss_cause_para2="A variety of conditions can cause hair loss, including:\n\n\n" +
            "•\tHormonal changes. Hormonal changes and imbalances can cause temporary hair loss. This could be due to pregnancy, childbirth or the onset of menopause. Hormone levels are also affected by the thyroid gland, so thyroid problems may cause hair loss.\n\n" +
            "•\tPatchy hair loss. This type of nonscarring hair loss is called alopecia areata (al-o-PEE-she-uh ar-e-A-tuh). It occurs when the body's immune system attacks hair follicles — causing sudden hair loss that leaves smooth, roundish bald patches on the skin.\n\n" +
            "•\tScalp infections. Infections, such as ringworm, can invade the hair and skin of your scalp, leading to scaly patches and hair loss. Once infections are treated, hair generally grows back.\n\n" +
            "•\tOther skin disorders. Diseases that cause scarring alopecia may result in permanent loss at the scarred areas. These conditions include lichen planus, some types of lupus and sarcoidosis.\n\n" +
            "•\tHair-pulling disorder. This condition, also called trichotillomania (trik-o-til-o-MAY-nee-uh), causes people to have an irresistible urge to pull out their hair, whether it's from the scalp, the eyebrows or other areas of the body.\n";
    String HAIR_Hairloss_symptoms_para1="Hair loss can appear in many different ways, depending on what's causing it. It can come on suddenly or gradually and affect just your scalp or your whole body. Some types of hair loss are temporary, and others are permanent";
    String HAIR_Hairloss_symptoms_para2="Signs and symptoms of hair loss may include:\n\n\n" +
            "•\tGradual thinning on top of head. This is the most common type of hair loss, affecting both men and women as they age. In men, hair often begins to recede from the forehead in a line that resembles the letter M. Women typically retain the hairline on the forehead but have a broadening of the part in their hair.\n\n" +
            "•\tCircular or patchy bald spots. Some people experience smooth, coin-sized bald spots. This type of hair loss usually affects just the scalp, but it sometimes also occurs in beards or eyebrows. In some cases, your skin may become itchy or painful before the hair falls out.\n\n" +
            "•\tSudden loosening of hair. A physical or emotional shock can cause hair to loosen. Handfuls of hair may come out when combing or washing your hair or even after gentle tugging. This type of hair loss usually causes overall hair thinning and not bald patches.\n\n" +
            "•\tFull-body hair loss. Some conditions and medical treatments, such as chemotherapy for cancer, can result in the loss of hair all over your body. The hair usually grows back.\n\n" +
            "•\tPatches of scaling that spread over the scalp.This is a sign of ringworm. It may be accompanied by broken hair, redness, swelling and, at times, oozing.\n";
    //treatment
    String HAIR_Hairloss_treatment_para1="Effective treatments for some types of hair loss are available. But some hair loss is permanent. With some conditions, such as patchy alopecia, hair may regrow without treatment within a year.\n\n" +
            "Treatments for hair loss include medications, surgery, laser therapy, and wigs or hairpieces. Your doctor may suggest a combination of these approaches in order to get the best results.\n";
    String HAIR_Hairloss_medication_para1="If your hair loss is caused by an underlying disease, treatment for that disease will be necessary. This may include drugs to reduce inflammation and suppress your immune system, such as prednisone. If a certain medication is causing the hair loss, your doctor may advise you to stop using it for at least three months.";
    String HAIR_Hairloss_medication_para2="Medications are available to treat pattern baldness. Two medications approved by the Food and Drug Administration (FDA) to treat hair loss are:\n\n\n" +
            "•\tMinoxidil (Rogaine). Minoxidil is an over-the-counter liquid or foam that you rub into your scalp twice a day to grow hair and to prevent further hair loss. It may be used by men and women. With this treatment, some people experience hair regrowth, a slower rate of hair loss or both. The effect peaks at 16 weeks and you need to keep applying the medication to retain benefits.\n" +
            "Possible side effects include scalp irritation, unwanted hair growth on the adjacent skin of the face and hands, and rapid heart rate (tachycardia).\n\n" +
            "•\tFinasteride (Propecia). This prescription drug is available only to men. It's taken daily in pill form. Many men taking finasteride experience a slowing of hair loss, and some may show some new hair growth. You need to keep taking it to retain benefits.\n\n" +
            "Rare side effects of finasteride include diminished sex drive and sexual function and an increased risk of prostate cancer. Women who are or may be pregnant need to avoid touching crushed or broken tablets.\n\n";
    String HAIR_Hairloss_surgery_desc="In the most common type of permanent hair loss, only the top of the head is affected. Hair transplant or restoration surgery can make the most of the hair you have left.\n\n" +
            "During this procedure, your surgeon removes tiny plugs of skin, each containing a few hairs, from the back or sides of your scalp. He or she then implants the plugs into the bald sections of your scalp. You may be asked to take a hair loss medication before and after surgery to improve results.\n\n" +
            "Surgical procedures to treat baldness are expensive and can be painful. Possible risks include infection and scarring.\n\n";
    String HAIR_Hairloss_lasertherapy_title="Laser therapy";
    String HAIR_Hairloss_lasertherapy_desc="A low-level laser device is available to treat men and women with pattern baldness. It has been cleared by the FDA. A study of 128 male and 141 female subjects indicated the device resulted in an overall improvement of hair loss condition and thickness among those who used the device. The researchers said no side effects were noted but that further study is needed to consider the long-term effects of this therapy.";
    String HAIR_Hairloss_wigs_title="Wigs and hairpieces";
    String HAIR_Hairloss_wigs_desc="You may want to try a wig or a hairpiece as an alternative to medical treatment or if you don't respond to treatment. It can be used to cover either permanent or temporary hair loss. Quality, natural-looking wigs and hairpieces are available.\n" +
            "If your hair loss is due to a medical condition, the cost of a wig may be covered by insurance. You'll need a prescription for the wig from your doctor.\n";
    String HAIR_Hairloss_homeremedies_para1="These tips may help you avoid preventable types of hair loss:\n" +
            "•\tEat a nutritionally balanced diet.\n\n\n" +
            "•\tAvoid tight hairstyles, such as braids, buns or ponytails.\n" +
            "•\tAvoid compulsively twisting, rubbing or pulling your hair.\n" +
            "•\tTreat your hair gently when washing and brushing. A wide-toothed comb may help prevent pulling out hair.\n" +
            "•\tAvoid harsh treatments such as hot rollers, curling irons, hot oil treatments and permanents.\n";
    String HAIR_Hairloss_alternative_desc="If you are otherwise well-nourished, taking nutritional supplements has not been shown to be helpful.\n\n" +
            "Some studies report that the patchy hair loss caused by alopecia areata may be helped by lavender oil combined with oils from thyme, rosemary and cedar wood. Further study is needed\n";
    //Trichotillomania
    //about
    String HAIR_Trichotillomania_title="Trichotillomania";
    String HAIR_Trichotillomania_status="Common";
    String HAIR_Trichotillomania_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging not required\n";
    String HAIR_Trichotillomania_desc="Trichotillomania (trik-o-til-o-MAY-nee-uh) is a disorder that involves recurrent, irresistible urges to pull out hair from your scalp, eyebrows or other areas of your body, despite trying to stop.";
    String HAIR_Trichotillomania_card_desc="Trichotillomania (trik-o-til-o-MAY-nee-uh) is a disorder that involves recurrent, irresistible urges to pull out hair from your scalp, eyebrows or other areas of your body, despite trying to stop.";
    //symptoms
    String HAIR_Trichotillomania_cause_para1="The cause of trichotillomania is unclear. But like many complex disorders, trichotillomania probably results from a combination of genetic and environmental factors. Also, abnormalities in the natural brain chemicals serotonin and dopamine may play a role in trichotillomania.";
    String HAIR_Trichotillomania_symptoms_para1="Signs and symptoms of trichotillomania often include:\n\n\n" +
            "•\tRepeatedly pulling your hair out, typically from your scalp, eyebrows or eyelashes, but can be from other body areas, and sites may vary over time\n\n" +
            "•\tAn increasing sense of tension before pulling, or when you try to resist pulling\n\n" +
            "•\tA sense of pleasure or relief after the hair is pulled\n\n" +
            "•\tShortened hair or thinned or bald areas on the scalp or other areas of your body, including sparse or missing eyelashes or eyebrows\n\n";
    //treatment
    String HAIR_Trichotillomania_treatment_para1="Research on treatment of trichotillomania is limited. However some treatment options have helped many people reduce their hair pulling or stop entirely.\n" +
            "Psychotherapy\n" +
            "Habit reversal training is the primary psychotherapy for trichotillomania. This type of therapy helps you learn how to recognize situations where you're likely to pull hair and how to substitute other behaviors instead. For example, you might clench your fists for a period to \"freeze\" the urge, or redirect your hand from your hair to your ear.\n" +
            "Sometimes elements of other therapies may be blended with habit reversal training, including:\n" +
            "•\tCognitive therapy. This therapy can help you challenge and examine distorted beliefs you may have in relation to hair pulling.\n" +
            "•\tAcceptance and commitment therapy. This therapy can help you learn to accept your hair-pulling urges without acting on them.\n";


    String HAIR_Trichotillomania_medication_para1="No medications are approved by the Food and Drug Administration specifically for the treatment of trichotillomania. However, some medications may help control your symptoms.\n\n" +
            "For example, your doctor may recommend an antidepressant, such as clomipramine (Anafranil). Other medications that research suggests may have some benefit include N-acetylcysteine (as-uh-tul-SIS-tee-een), an amino acid that influences neurotransmitters related to mood, and olanzapine (Zyprexa), an atypical antipsychotic.\n\n" +
            "Talk with your doctor about any medication that he or she suggests. The possible benefits of medications should always be balanced against possible side effects.\n\n";
    String HAIR_Trichotillomania_coping_para1="Many people with trichotillomania report feeling alone in their experience of hair pulling. It may help to join a support group for people with trichotillomania so that you can meet others with similar experiences who can relate to your feelings. You might ask your doctor for a recommendation or visit the Trichotillomania Learning Center website to find a support group.";









}
