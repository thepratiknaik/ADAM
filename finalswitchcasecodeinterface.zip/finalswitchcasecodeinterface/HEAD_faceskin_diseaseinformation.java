public interface HEAD_faceskin_diseaseinformation {
    //Acne
    String faceskin_Acne_title="Acne";
    String faceskin_Acne_status="Very common";
    String faceskin_Acne_about="More than 10 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging not required\n";
    String faceskin_Acne_desc="Acne is a skin condition that occurs when your hair follicles become plugged with oil and dead skin cells. Acne usually appears on your face, neck, chest, back and shoulders. Effective treatments are available, but acne can be persistent. The pimples and bumps heal slowly, and when one begins to go away, others seem to crop up.";
    String faceskin_Acne_card_desc="Acne is a skin condition that occurs when your hair follicles become plugged with oil and dead skin cells. Acne usually appears on your face, neck, chest, back and shoulders. Effective treatments are available, but acne can be persistent. The pimples and bumps heal slowly, and when one begins to go away, others seem to crop up.";
    String faceskin_Acne_cause_para1="•\tOil production\n\n" +
            "•\tDead skin cells\n\n" +
            "•\tClogged pores\n\n" +
            "•\tBacteria\n\n";
    String faceskin_Acne_symptoms_para1="•\tWhiteheads (closed plugged pores)\n\n" +
            "•\tBlackheads (open plugged pores — the oil turns brown when it is exposed to air)\n\n" +
            "•\tSmall red, tender bumps (papules)\n\n" +
            "•\tPimples (pustules), which are papules with pus at their tips\n\n" +
            "•\tLarge, solid, painful lumps beneath the surface of the skin (nodules)\n\n" +
            "•\tPainful, pus-filled lumps beneath the surface of the skin (cystic lesions)\n\n";
    String faceskin_Acne_treatment_para1="•\tRetinoids. These come as creams, gels and lotions. Retinoid drugs are derived from vitamin A and include tretinoin (Avita, Retin-A, others), adapalene (Differin) and tazarotene (Tazorac, Avage). You apply this medication in the evening, beginning with three times a week, then daily as your skin becomes used to it. It works by preventing plugging of the hair follicles.\n\n" +
            "•\tAntibiotics. These work by killing excess skin bacteria and reducing redness. For the first few months of treatment, you may use both a retinoid and an antibiotic, with the antibiotic applied in the morning and the retinoid in the evening. The antibiotics are often combined with benzoyl peroxide to reduce the likelihood of developing antibiotic resistance. Examples include clindamycin with benzoyl peroxide (Benzaclin, Duac, Acanya) and erythromycin with benzoyl peroxide (Benzamycin).\n\n" +
            "•\tDapsone (Aczone). This gel is most effective when combined with a topical retinoid. Skin side effects include redness and dryness.\n" +
            "Oral medications\n\n\n" +
            "•\tAntibiotics. For moderate to severe acne, you may need oral antibiotics to reduce bacteria and fight inflammation. Choices for treating acne include tetracyclines, such as minocycline and doxycycline.\n\n" +
            "•\tCombined oral contraceptives. Combined oral contraceptives are useful in treating acne in women and adolescent girls. The Food and Drug Administration approved three products that combine estrogen and progestin (Ortho Tri-Cyclen, Estrostep and Yaz).\n\n" +
            "The most common side effects of these drugs are headache, breast tenderness, nausea, weight gain and breakthrough bleeding. A serious potential complication is a slightly increased risk of blood clots.\n\n" +
            "•\tAnti-androgen agent. The drug spironolactone (Aldactone) may be considered for women and adolescent girls if oral antibiotics aren't helping. It works by blocking the effect of androgen hormones on the sebaceous glands. Possible side effects include breast tenderness, painful periods and the retention of potassium.\n\n" +
            "•\tIsotretinoin. This medicine is reserved for people with the most severe acne. Isotretinoin (Amnesteem, Claravis, Sotret) is a powerful drug for people whose acne doesn't respond to other treatments.\n " ;

    String Faceskin_Acne_therapy_title="Light Theraphy";
    String Faceskin_Acne_therapy_desc="•\t A variety of light-based therapies have been tried with success. But further study is needed to determine the ideal method, light source and dose. Light therapy targets the bacteria that cause acne inflammation. Some types of light therapy are done in a doctor's office. Blue-light therapy can be done at home with a hand-held device.";
    String Faceskin_Acne_scars_title="Soft tissue fillers.";
    String Faceskin_Acne_scars_desc="•\t Injecting soft tissue fillers, such as collagen or fat, under the skin and into indented scars can fill out or stretch the skin. This makes the scars less noticeable. Results are temporary, so you would need to repeat the injections periodically. Side effects include temporary swelling, redness and bruising.";
    String Faceskin_Acne_homeremedies_para1="•\tWash acne-prone areas only twice a day.Washing removes excess oil and dead skin cells. But too much washing can irritate the skin. Wash affected areas with a gentle cleanser and use oil-free, water-based skin care products.\n\n" +
            "•\tUse an over-the-counter acne cream or gel to help dry excess oil. Look for products containing benzoyl peroxide or salicylic acid as the active ingredient.\n\n" +
            "•\tUse nonoily makeup. Choose oil-free cosmetics that won't clog pores (noncomedogenics).\n\n" +
            "•\tRemove makeup before going to bed. Going to sleep with cosmetics on your skin can clog your pores. Also, it's a good idea to throw out old makeup and regularly clean your cosmetic brushes and applicators with soapy water.\n\n" +
            "•\tWear loosefitting clothing. Tightfitting clothing traps heat and moisture and can irritate your skin. When possible, avoid tightfitting straps, backpacks, helmets, hats and sports equipment to prevent friction against your skin.\n\n" +
            "•\tShower after strenuous activities. Oil and sweat on your skin can lead to breakouts.\n\n" +
            "•\tAvoid touching or picking at the problem areas.Doing so can trigger more acne.\n\n";
    String Faceskin_Acne_alternative_para1="•\tTea tree oil. Gels containing 5 percent tea tree oil may be as effective as are lotions containing 5 percent benzoyl peroxide, although tea tree oil might work more slowly. Possible side effects include contact dermatitis and, if you have rosacea, a worsening of those symptoms. One study reported that a young boy experienced breast development after using a combination lavender and tea tree oil hair product. Tea tree oil should be used only topically.\n\n" +
            "•\tAlpha hydroxy acid. This natural acid is found in citrus fruit and other foods. When applied to your skin, it helps remove dead skin cells and unclog pores. It may also improve the appearance of acne scars. Side effects include increased sensitivity to the sun, redness, mild stinging and skin irritation.\n\n" +
            "•\tAzelaic acid. This natural acid is found in whole-grain cereals and animal products. It has antibacterial properties. A 20 percent azelaic acid cream seems to be as effective as many other conventional acne treatments when used twice a day for at least four weeks. It is even more effective when used in combination with erythromycin. Prescription azelaic acid (Azelex, Finacea) is an option during pregnancy and while breastfeeding.\n\n" +
            "•\tBovine cartilage. Creams containing 5 percent bovine cartilage, applied to the affected skin twice a day, may be effective in reducing acne.\n\n" +
            "•\tZinc. Zinc in lotions and creams may reduce acne breakouts.\n\n" +
            "•\tGreen tea extract. A lotion of 2 percent green tea extract helped reduce acne in two studies of adolescents and young adults with mild to moderate acne.\n\n" +
            "•\tAloe vera. A 50 percent aloe vera gel was combined with a conventional acne drug (tretinoin) and tested for 8 weeks on 60 people with moderate acne. The combination approach was significantly more effective than tretinoin alone.\n\n";
    //itchy skin
    String Faceskin_Itchyskin_title="Itchy skin";
    String Faceskin_Itchskin_desc="Itchy skin is an uncomfortable, irritating sensation that makes you want to scratch. Also known as pruritus (proo-RIE-tus), itchy skin may be the result of a rash or another condition, such as psoriasis or dermatitis. Or itchy skin may be a symptom of a disease, such as liver disease or kidney failure.";
    String Faceskin_Itchyskin_card_desc="Itchy skin is an uncomfortable, irritating sensation that makes you want to scratch. Also known as pruritus (proo-RIE-tus), itchy skin may be the result of a rash or another condition, such as psoriasis or dermatitis. Or itchy skin may be a symptom of a disease, such as liver disease or kidney failure.";
    String Faceskin_Itchyskin_cause_para1="•\tDry skin. If you don't see a crop of bright, red bumps or some other dramatic change in the itchy area, dry skin (xerosis) is a likely cause. Dry skin usually results from environmental factors such as hot or cold weather with low humidity, long-term use of air conditioning or central heating, and washing or bathing too much.\n\n" +
            "•\tSkin conditions and rashes. Many skin conditions itch, including eczema (dermatitis), psoriasis, scabies, lice, chickenpox and hives. The itching usually affects specific areas and is accompanied by other signs, such as red, irritated skin or bumps and blisters.\n\n" +
            "•\tInternal diseases. These include liver disease, malabsorption of wheat (celiac disease), kidney failure, iron deficiency anemia, thyroid problems and cancers, including leukemia and lymphoma. The itching usually affects the whole body. The skin may look otherwise normal except for the repeatedly scratched areas.\n\n" +
            "•\tNerve disorders. Conditions that affect the nervous system — such as multiple sclerosis, diabetes mellitus, pinched nerves and shingles(herpes zoster) — can cause itching.\n\n" +
            "•\tIrritation and allergic reactions. Wool, chemicals, soaps and other substances can irritate the skin and cause itching. Sometimes the substance, such as poison ivy or cosmetics, causes an allergic reaction. Food allergies also may cause skin to itch.\n\n" +
            "•\tDrugs. Reactions to drugs, such as antibiotics, antifungal drugs or narcotic pain medications, can cause widespread rashes and itching.\n\n" +
            "•\tPregnancy. During pregnancy, some women experience itchy skin, especially on the abdomen, thighs, breasts and arms. Also, itchy skin conditions, such as dermatitis, can worsen during pregnancy.\n\n";
    String Faceskin_Itchyskin_treatment_para1="•\tCorticosteroid creams. Applied topically, these may control itching. Your doctor may recommend applying the medicated cream to affected areas, then covering these areas with damp cotton material that has been soaked in water or other solutions. The moisture in the wet dressings helps the skin absorb the cream.\n\n" +
            "•\tCalcineurin inhibitors. Certain drugs, such as tacrolimus (Protopic) and pimecrolimus (Elidel), can be used instead of corticosteroid creams in some cases, especially if the itchy area isn't large.\n\n" +
            "•\tOral antihistamines. Your doctor may recommend anti-allergy medications to ease your itch. This group of medications includes over-the-counter drugs that don't make you sleepy, such as cetirizine (Zyrtec) and loratadine (Claritin), or those that make you sleepy, such as diphenhydramine (Benadryl). The ones that make you sleepy can be particularly helpful at night if your itchy skin keeps you awake.\n\n" +
            "•\tAntidepressants. Selective serotonin-reuptake inhibitors, such as fluoxetine (Prozac) and sertraline (Zoloft), may help reduce various types of skin itching.\n\n";
    String Faceskin_Itchyskin_lightskintheraphy_title="Light therapy (phototherapy)";
    String Faceskin_Itchyskin_lightskintheraphy_desc="Phototherapy involves exposing your skin to certain wavelengths of ultraviolet light. Multiple sessions are usually scheduled until the itching is under control.";
    String Faceskin_Itchyskin_homeremedies_para1="•\tUse a high-quality moisturizing cream on your skin. Apply this cream at least once or twice daily, concentrating on the areas where itching is most severe. Examples include Cetaphil, Eucerin, CeraVe and others.\n\n" +
            "•\tApply an anti-itch cream or lotion to the affected area. Short-term use of nonprescription hydrocortisone cream containing at least 1 percent hydrocortisone can temporarily relieve the itch. So can menthol, camphor or calamine.\n\n" +
            "Topical anesthetics, such as lidocaine or benzocaine, may be helpful. However, benzocaine has been linked to a rare but serious, sometimes deadly condition known as methemoglobinemia, which decreases the amount of oxygen that the blood can carry. Don't use benzocaine in children younger than age 2 without supervision from a health care professional. If you're an adult, never use more than the recommended dose of benzocaine, and consider talking with your doctor.\n\n" +
            "•\tAvoid scratching whenever possible. Cover the itchy area if you can't keep from scratching it. Trim nails and wear gloves at night.\n\n" +
            "•\tApply cool, wet compresses. Covering the affected area with bandages and dressings can help protect the skin and prevent scratching.\n\n" +
            "•\tTake a lukewarm bath. Sprinkle the bath water with baking soda, uncooked oatmeal or colloidal oatmeal — a finely ground oatmeal that is made for the bathtub (Aveeno, others).\n\n" +
            "•\tWear smooth-textured, loose cotton clothing.This will help you avoid irritation.\n\n" +
            "•\tChoose mild soaps without dyes or perfumes. Be sure to rinse the soap completely off your body. And after washing, apply a moisturizer to protect your skin.\n\n" +
            "•\tUse a mild, unscented laundry detergent when washing clothes, towels and bedding. Try using the extra-rinse cycle on your washing machine.\n\n" +
            "•\tAvoid substances that irritate your skin or that cause an allergic reaction. These can include nickel, jewelry, perfume or skin 9999products with fragrance, cleaning products, and cosmetics.\n\n" +
            "•\tReduce stress. Stress can worsen itching. Counseling, behavior modification therapy, meditation and yoga are some ways of relieving stress.\n\n";
    //Skin Cancer
    String Faceskin_Skincancer_title="Skin Cancer";
    String Faceskin_Skincancer_desc="Skin cancer — the abnormal growth of skin cells — most often develops on skin exposed to the sun. But this common form of cancer can also occur on areas of your skin not ordinarily exposed to sunlight.";
    String Faceskin_Skincancer_card_desc="Skin cancer — the abnormal growth of skin cells — most often develops on skin exposed to the sun. But this common form of cancer can also occur on areas of your skin not ordinarily exposed to sunlight.";
    String Faceskin_Skincancer_cause_para1="Skin cancer occurs when errors (mutations) occur in the DNA of skin cells. The mutations cause the cells to grow out of control and form a mass of cancer cells.";
    String Faceskin_Skincancer_symptoms_para1="Basal cell carcinoma signs and symptoms\n\n" +
            "Basal cell carcinoma usually occurs in sun-exposed areas of your body, such as your neck or face.\n" +
            "Basal cell carcinoma may appear as:\n" +
            "•\tA pearly or waxy bump\n" +
            "•\tA flat, flesh-colored or brown scar-like lesion\n" +
            "Squamous cell carcinoma signs and symptoms\n\n" +
            "Most often, squamous cell carcinoma occurs on sun-exposed areas of your body, such as your face, ears and hands. People with darker skin are more likely to develop squamous cell carcinoma on areas that aren't often exposed to the sun.\n" +
            "Squamous cell carcinoma may appear as:\n" +
            "•\tA firm, red nodule\n" +
            "•\tA flat lesion with a scaly, crusted surface\n" +
            "Melanoma signs and symptoms\n\n" +
            "Melanoma can develop anywhere on your body, in otherwise normal skin or in an existing mole that becomes cancerous. Melanoma most often appears on the face or the trunk of affected men. In women, this type of cancer most often develops on the lower legs. In both men and women, melanoma can occur on skin that hasn't been exposed to the sun.\n" +
            "Melanoma can affect people of any skin tone. In people with darker skin tones, melanoma tends to occur on the palms or soles, or under the fingernails or toenails.\n" +
            "Melanoma signs include:\n\n" +
            "•\tA large brownish spot with darker speckles\n" +
            "•\tA mole that changes in color, size or feel or that bleeds\n" +
            "•\tA small lesion with an irregular border and portions that appear red, white, blue or blue-black\n" +
            "•\tDark lesions on your palms, soles, fingertips or toes, or on mucous membranes lining your mouth, nose, vagina or anus\n";

    String Faceskin_Skincancer_treatment_para1="•\tFreezing. Your doctor may destroy actinic keratoses and some small, early skin cancers by freezing them with liquid nitrogen (cryosurgery). The dead tissue sloughs off when it thaws.\n\n" +
            "•\tExcisional surgery. This type of treatment may be appropriate for any type of skin cancer. Your doctor cuts out (excises) the cancerous tissue and a surrounding margin of healthy skin. A wide excision — removing extra normal skin around the tumor — may be recommended in some cases.\n\n" +
            "•\tMohs surgery. This procedure is for larger, recurring or difficult-to-treat skin cancers, which may include both basal and squamous cell carcinomas. It's often used in areas where it's necessary to conserve as much skin as possible, such as on the nose.\n\n" +
            "During Mohs surgery, your doctor removes the skin growth layer by layer, examining each layer under the microscope, until no abnormal cells remain. This procedure allows cancerous cells to be removed without taking an excessive amount of surrounding healthy skin.\n\n" +
            "•\tCurettage and electrodesiccation or cryotherapy.After removing most of a growth, your doctor scrapes away layers of cancer cells using a device with a circular blade (curet). An electric needle destroys any remaining cancer cells. In a variation of this procedure, liquid nitrogen can be used to freeze the base and edges of the treated area.\n\n" +
            "These simple, quick procedures may be used to treat basal cell cancers or thin squamous cell cancers.\n\n" +
            "•\tRadiation therapy. Radiation therapy uses high-powered energy beams, such as X-rays, to kill cancer cells. Radiation therapy may be an option when cancer can't be completely removed during surgery.\n\n" +
            "•\tChemotherapy. In chemotherapy, drugs are used to kill cancer cells. For cancers limited to the top layer of skin, creams or lotions containing anti-cancer agents may be applied directly to the skin. Systemic chemotherapy can be used to treat skin cancers that have spread to other parts of the body.\n\n" +
            "•\tPhotodynamic therapy. This treatment destroys skin cancer cells with a combination of laser light and drugs that makes cancer cells sensitive to light.\n\n" +
            "•\tBiological therapy. Biological therapy uses your body's immune system to kill cancer cells.\n\n";
    String Faceskin_Skincancer_homeremedies_para1="•\tAvoid the sun during the middle of the day. For many people in North America, the sun's rays are strongest between about 10 a.m. and 4 p.m. Schedule outdoor activities for other times of the day, even in winter or when the sky is cloudy.\n\n" +
            "You absorb UV radiation year-round, and clouds offer little protection from damaging rays. Avoiding the sun at its strongest helps you avoid the sunburns and suntans that cause skin damage and increase your risk of developing skin cancer. Sun exposure accumulated over time also may cause skin cancer.\n\n" +
            "•\tWear sunscreen year-round. Sunscreens don't filter out all harmful UV radiation, especially the radiation that can lead to melanoma. But they play a major role in an overall sun protection program.\n\n" +
            "Use a broad-spectrum sunscreen with an SPF of at least 15. Apply sunscreen generously, and reapply every two hours — or more often if you're swimming or perspiring. Use a generous amount of sunscreen on all exposed skin, including your lips, the tips of your ears, and the backs of your hands and neck.\n\n" +
            "•\tWear protective clothing. Sunscreens don't provide complete protection from UV rays. So cover your skin with dark, tightly woven clothing that covers your arms and legs, and a broad-brimmed hat, which provides more protection than a baseball cap or visor does.\n\n" +
            "Some companies also sell photoprotective clothing. A dermatologist can recommend an appropriate brand.\n\n" +
            "Don't forget sunglasses. Look for those that block both types of UV radiation — UVA and UVB rays.\n\n" +
            "•\tAvoid tanning beds. Lights used in tanning beds emit UV rays and can increase your risk of skin cancer.\n\n" +
            "•\tBe aware of sun-sensitizing medications. Some common prescription and over-the-counter drugs, including antibiotics, can make your skin more sensitive to sunlight.\n\n";
}
