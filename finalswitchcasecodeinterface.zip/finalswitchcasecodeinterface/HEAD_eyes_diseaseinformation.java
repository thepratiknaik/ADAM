public interface HEAD_eyes_diseaseinformation {
    //eyes
    //EyeStrain
    //about

    String eyes_EyeStrain_title="Eye Strain";
    String eyes_EyeStrain_desc="Although eyestrain can be annoying, it usually isn't serious and goes away once you rest your eyes. In some cases, signs and symptoms of eyestrain can indicate an underlying eye condition that needs treatment. Although you may not be able to change the nature of your job or all the factors that can cause eyestrain, you can take steps to reduce eyestrain.";
    String eyes_EyeStrain_card_desc="Eyestrain occurs when your eyes get tired from intense use, such as driving a car for extended periods, reading or working at a computer.";
    //symptoms
    String eyes_EyeStrain_cause_para1="Common causes of eyestrain include:\n\n\n" +
            "•\tExtended use of a computer or digital electronic devices\n\n" +
            "•\tReading for extended periods\n\n" +
            "•\tOther activities involving extended periods of intense focus and concentration, such as driving a vehicle\n\n" +
            "•\tExposure to bright light or glare\n\n" +
            "•\tStraining to see in very dim light.\n\n";
    String eyes_EyeStrain_symptoms_para1="Eyestrain signs and symptoms include:\n\n\n" +
            "•\tSore, tired, burning or itching eyes\n\n" +
            "•\tWatery eyes\n\n" +
            "•\tDry eyes\n\n" +
            "•\tBlurred or double vision\n\n" +
            "•\tHeadache\n\n" +
            "•\tSore neck\n\n" +
            "•\tSore back\n\n" +
            "•\tShoulder pain\n\n" +
            "•\tIncreased sensitivity to light\n\n" +
            "•\tDifficulty focusing\n\n";
    //treatment
    String eyes_EyeStrain_treatment_para1="Generally, treatment for eyestrain consists of making changes in your work habits or your environment.\n\n" +
            "•\tIn some cases, eyestrain may improve if you get treatment for another underlying eye condition.\n" +
            "•\tFor some people, wearing glasses that are prescribed for specific activities, such as using a computer or reading, may help reduce eyestrain.\n" +
            "•\tYour doctor may suggest that you do regular eye exercises to help your eyes focus at different distances.\n";
    String eyes_EyeStrain_homeremedies_para1="•\tTake eye breaks. Throughout the day, give your eyes a break by forcing them to focus on something other than on your computer screen. A good rule of thumb is to follow the 20-20-20 rule: Every 20 minutes, take your eyes off your computer and look at something 20 feet away for at least 20 seconds. It's reasonable to take a break every 15 to 30 minutes for one to three minutes. Do other work, such as phone calls or filing, during this time. Try to stand up and move around at least once every hour or so. If possible, lean back and close your eyes for a few moments.\n\n" +
            "•\tBlink often to refresh your eyes. Because many people blink less than normal when working at a computer, dry eyes can result from prolonged computer use. Blinking produces tears that moisten and refresh your eyes. Make a conscious effort to blink more often.\n\n" +
            "•\tConsider using artificial teardrops. Over-the-counter artificial tears can help prevent and relieve dry eyes that result from prolonged sessions at the computer. Your doctor can suggest which drops might be best for you. Lubricating drops that don't contain preservatives can be used as often as you need. If the drops you're using contain preservatives, don't use them more than four times a day. Avoid eyedrops with a redness remover, as these may worsen dry eye symptoms.\n\n" +
            "•\tImprove the air quality in your work space. Some changes that may help prevent dry eyes include using a humidifier, lowering the thermostat and avoiding smoke.\n\n" +
            "•\tPractice relaxation. Ease muscle tension with relaxation exercises. Place your elbows on your desk, palms facing up. Let your weight fall forward and your head fall into your hands. Position your head so that your hands cover your eyes, with your fingers extended toward your forehead. Close your eyes and take a deep breath through your nose; hold it for four seconds, then exhale. Continue this deep breathing for 15 to 30 seconds. Perform this simple exercise several times a day.\n\n" +
            "•\tMassage your eyelids and muscles over your brow, temple and upper cheek once or twice daily. This maneuver can be performed with your bare hands and fingers or can be done using a warm towel over closed eyes. Gently massage your upper eyelid against your brow bone for about 10 seconds. Follow by massaging your lower eyelid against the lower bone for about 10 seconds. This process can stimulate your tear glands, which may help prevent dry eyes. Massaging the muscles in the area around your eye (orbit) also helps relax those muscles, which may reduce some of the symptoms of eyestrain.\n\n" +
            "•\tGet appropriate eyewear. If you wear glasses or contacts, make sure the correction is right for computer work. Most lenses are fitted for reading print and may not be optimal for computer work. Glasses or contact lenses designed specifically for computer work may be a worthwhile investment.\n\n";
//Dry Eye
    //about

    String eyes_DryEye_title="Dry Eyes";
    String eyes_DryEye_status="Very common";
    String eyes_DryEye_about="More than 10 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging rarely required\n" +
            "Medium-term: resolves within months\n";
    String eyes_DryEye_desc="Dry eyes occur when your tears aren't able to provide adequate moisture for your eyes. Tears can be inadequate for many reasons. For example, dry eyes may occur if you don't produce enough tears or if you produce poor-quality tears.";
    String eyes_DryEyes_card_desc="Dry eyes occur when your tears aren't able to provide adequate moisture for your eyes. Tears can be inadequate for many reasons. For example, dry eyes may occur if you don't produce enough tears or if you produce poor-quality tears.";
    //symptoms
    String eyes_DryEyes_cause_para1="Dry eyes are caused by a lack of adequate tears. Your tears are a complex mixture of water, fatty oils, and mucus. This mixture helps make the surface of your eyes smooth and clear, and it helps protect your eyes from infection.\n\n" +
            "For some people, the cause of dry eyes is an imbalance in the composition of their tears. Other people don't produce enough tears to keep their eyes comfortably lubricated. Eyelid problems, medications and other causes, such as environmental factors, also can lead to dry eyes.\n\n";
    String eyes_DryEyes_symptoms_para1="Signs and symptoms, which usually affect both eyes, may include:\n\n\n" +
            "•\tA stinging, burning or scratchy sensation in your eyes\n\n" +
            "•\tStringy mucus in or around your eyes\n\n" +
            "•\tIncreased eye irritation from smoke or wind\n\n" +
            "•\tEye fatigue\n\n" +
            "•\tSensitivity to light\n\n" +
            "•\tEye redness\n\n" +
            "•\tA sensation of having something in your eyes\n\n" +
            "•\tDifficulty wearing contact lenses\n\n" +
            "•\tPeriods of excessive tearing\n\n" +
            "•\tBlurred vision, often worsening at the end of the day or after focusing for a prolonged period.\n\n";
   //treatment
    String eyes_DryEyes_treatment_para1="Treatments that may be used include:\n\n\n" +
            "•\tClosing your tear ducts to reduce tear loss. Your doctor may suggest treatment to keep your tears from leaving your eye too quickly. This can be done by partially or completely closing your tear ducts, which normally serve to drain tears away. Tear ducts can be plugged with tiny silicone plugs (punctal plugs) that conserve both your own tears and artificial tears you may add. Silicone plugs can be removed or left in. Or, tear ducts can be plugged with a procedure that uses heat. In a more permanent procedure called thermal cautery, your doctor numbs the area with an anesthetic and then applies a hot wire that shrinks the tissues of the drainage area and causes scarring, which closes the tear duct.\n\n" +
            "•\tCovering your eyes with a special contact lens.People with severe dry eyes may opt for special contact lenses. These contact lenses help protect or shield the surface of your eyes, trapping moisture close to your eyes in order to relieve your dry eyes symptoms. Ask your eye doctor whether these special lenses, called bandage lenses or corneal shields, are an option for you.\n\n" +
            "•\tUnblocking blocked oil glands. A new treatment called LipiFlo thermal pulsation helps clear blocked oil glands. During the treatment, a device that looks like an eyecup is placed over your eye. The device then delivers a gentle, warm massage to the lower eyelid. The procedure takes less than 15 minutes, and you can go home right afterward. Results usually begin within a few days. Because this is a new treatment, it may not yet be available everywhere\n\n";
    String eyes_DryEyes_medication_para1="Prescriptions used to treat dry eyes include:\n\n\n" +
            "•\tAntibiotics to reduce eyelid inflammation. If inflammation along the edge of your eyelids keeps the oil glands from secreting oil into your tears, your doctor may recommend antibiotics to reduce inflammation. Antibiotics can be administered as eyedrops or ointment, or they can be taken in pill form.\n\n" +
            "•\tPrescription eyedrops to control cornea inflammation. Inflammation on the surface of your eyes may be controlled with prescription eyedrops that contain the immune-suppressing medication cyclosporine (Restasis) or that contain corticosteroids to control inflammation.\n\n" +
            "•\tPrescription eye inserts that work like artificial tears. For people with moderate to severe dry eyes symptoms who can't use artificial tears, one option may be a tiny eye insert that looks like a clear grain of rice. Once a day, you place the hydroxypropyl cellulose (Lacrisert) insert between your lower eyelid and your eyeball. The insert dissolves slowly, releasing a substance that's used in eyedrops to lubricate your eye.\n\n";
    String eyes_DryEyes_homeremedies_para1="If you experience dry eyes, pay attention to the situations that are most likely to cause your symptoms. Then find ways to avoid those situations in order to prevent your dry eyes symptoms. For instance:\n\n\n" +
            "•\tAvoid air blowing in your eyes. Don't direct hair dryers, car heaters, air conditioners or fans toward your eyes.\n\n" +
            "•\tAdd moisture to the air. In winter, a humidifier can add moisture to dry indoor air.\n\n" +
            "•\tConsider wearing wraparound glasses or eyeglass shields to protect your eyes. Safety shields can be added to the tops and sides of eyeglasses to block wind and dry air from getting to your eyes. Ask about shields where you buy your eyeglasses. Swim goggles may create the same effect.\n\n" +
            "•\tTake eye breaks during long tasks. If you're reading or doing another task that requires visual concentration, take periodic eye breaks. Close your eyes for a few minutes. Or blink repeatedly for a few seconds to help spread your tears evenly over your eyes.\n\n" +
            "•\tBe aware of your environment. Ambient air at high altitudes, desert areas, and in airplanes can be extremely dry. When spending time in such an environment, especially when flying over long distances, it may be helpful to frequently close your eyes for a few minutes at a time to minimize evaporation of your tears.\n" +
            "•\tPosition your computer screen below eye level. If your computer screen is above eye level, you'll open your eyes wider to view the screen. Position your computer screen below eye level so that you won't open your eyes as wide. This may help slow the evaporation of your tears between eye blinks.\n" +
            "•\tStop smoking and avoid smoke. If you smoke, stop. Ask your doctor for help devising a quit-smoking strategy that's most likely to work for you. If you don't smoke, stay away from people who do. Smoke can worsen dry eyes symptoms\n";
    //cataract
    //about
    String eyes_Cataract_title="Cataract";
    String eyes_Cataract_status="Common";
    String eyes_Cataract_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging not required\n" +
            "Chronic: can last for years or be lifelong\n";
    String eyes_Cataract_desc="A cataract is a clouding of the normally clear lens of your eye. For people who have cataracts, seeing through cloudy lenses is a bit like looking through a frosty or fogged-up window.";
    String eyes_Cataract_card_desc="A cataract is a clouding of the normally clear lens of your eye. For people who have cataracts, seeing through cloudy lenses is a bit like looking through a frosty or fogged-up window.";
    //symptoms
    String eyes_Cataract_cause_para1="Most cataracts develop when aging or injury changes the tissue that makes up your eye's lens.\n\n" +
            "Some cataracts are related to inherited genetic disorders that cause other health problems and increase your risk of cataracts. Cataracts can also be caused by other eye conditions, medical conditions such as diabetes, trauma or past eye surgery. Long-term use of steroid medications, too, can cause cataracts to develop.\n";
    String eyes_Cataract_symptoms_para1="Signs and symptoms of cataracts include:\n\n\n" +
            "•\tClouded, blurred or dim vision\\nn" +
            "•\tIncreasing difficulty with vision at night\n\n" +
            "•\tSensitivity to light and glare\n\n" +
            "•\tSeeing \"halos\" around lights\n\n" +
            "•\tFrequent changes in eyeglass or contact lens prescription\n\n" +
            "•\tFading or yellowing of colors\n\n" +
            "•\tDouble vision in a single eye\n\n";
    //treatment
    String eyes_Cataract_treatment_para1="The only effective treatment for cataracts is surgery.\n\n" +
            "When to consider cataract surgery\n\n" +
            "Talk with your eye doctor about whether surgery is right for you. Most eye doctors suggest considering cataract surgery when your cataracts begin to affect your quality of life or interfere with your ability to perform normal daily activities, such as reading or driving at night.\n" +
            "It's up to you and your doctor to decide when cataract surgery is right for you. For most people, there is no rush to remove cataracts because they usually don't harm the eye.\n" +
            "Delaying the procedure won't make it more likely that you won't recover your vision if you later decide to have cataract surgery. Take time to consider the benefits and risks of cataract surgery with your doctor.\n" +
            "If you choose not to undergo cataract surgery now, your eye doctor may recommend periodic follow-up exams to see if your cataracts are progressing. How often you'll see your eye doctor depends on your situation.\n";
    String eyes_Cataract_homeremedies_para1="No studies have proved how to prevent cataracts or slow the progression of cataracts. However, doctors think several strategies may be helpful, including:\n\n\n" +
            "•\tHave regular eye examinations. Eye examinations can help detect cataracts and other eye problems at their earliest stages. Ask your doctor how often you should have an eye examination.\n\n" +
            "•\tQuit smoking. Ask your doctor for suggestions about how to stop smoking. Medications, counseling and other strategies are available to help you.\n\n" +
            "•\tReduce alcohol use. Excessive alcohol use can increase the risk of cataracts.\n\n" +
            "•\tWear sunglasses. Ultraviolet light from the sun may contribute to the development of cataracts. Wear sunglasses that block ultraviolet B (UVB) rays when you're outdoors.\n\n" +
            "•\tManage other health problems. Follow your treatment plan if you have diabetes or other medical conditions that can increase your risk of cataracts.\n\n" +
            "•\tMaintain a healthy weight. If you currently have a healthy weight, work to maintain it by exercising most days of the week. If you're overweight or obese, work to lose weight slowly by reducing your calorie intake and increasing the amount of exercise you get each day.\n\n" +
            "•\tChoose a healthy diet that includes plenty of fruits and vegetables. Adding a variety of colorful fruits and vegetables to your diet ensures that you're getting many vitamins and nutrients. Fruits and vegetables have many antioxidants, which help maintain the health of your eyes.\n\n";
   //Convergence Insufficiency
    //about

    String eyes_ConvergenceInsufficiency_title="Convergence Insufficiency";
    String eyes_ConvergenceInsufficiency_desc="Convergence insufficiency occurs when your eyes don't work together while you're trying to focus on a nearby object. When you read or look at a close object, your eyes need to turn inward together (converge) to focus. This gives you binocular vision, enabling you to see a single image.\n";
    String eyes_ConvergenceInsufficiency_Card_desc="Convergence insufficiency occurs when your eyes don't work together while you're trying to focus on a nearby object. When you read or look at a close object, your eyes need to turn inward together (converge) to focus. This gives you binocular vision, enabling you to see a single image.\n";
     //symptoms
    String eyes_Convergenceinsufficiency_cause_para1="Convergence insufficiency results from misalignment of the eyes when focusing on nearby objects. The exact cause isn't known, but the misalignment involves the muscles that move the eye. Typically, one eye drifts outward when you're focusing on a nearby word or object.";
    String eyes_Convergenceinsufficiency_symptoms_para1="Not everyone with convergence insufficiency experiences symptoms. Signs and symptoms occur while you're reading or doing other close work and may include:\n\n\n" +
            "•\tEyestrain\n\n" +
            "•\tHeadaches\n\n" +
            "•\tDifficulty reading — words blur or seem to move on the page\n\n" +
            "•\tDouble vision\n\n" +
            "•\tDifficulty concentrating\n\n" +
            "•\tSquinting or closing one eye\n\n";
    //treatment
    String eyes_Convergenceinsufficiency_treatment_para1="Treatment options for convergence insufficiency include:\n\n\n" +
            "•\tPencil pushups. In this simple exercise, you focus on a small letter on the side of a pencil as you move it closer to the bridge of your nose, stopping the movement if you have double vision. Your doctor may suggest you do this at home for 15 minutes a day, five or more days a week.\n\n" +
            "•\tOffice or home-based vision therapy. You can do eye-focusing exercises to improve convergence. If you do this at home on a computer, you can print your results to share with your eye doctor.\n\n" +
            "•\tCombined therapy. Many experts recommend using vision therapy — often with computer software programs — along with pencil pushups. The combined approach may be more effective. And the computer-assisted therapy may be more engaging for children.\n\n" +
            "•\tReading glasses. If computer therapy or exercises don't help, your doctor may suggest you use glasses with built-in prisms for reading. This is usually more effective for children.\n\n" +
            "•\tContinued observation. It's possible to receive a diagnosis of convergence insufficiency but not show any signs or symptoms. If this is true for you, watch for symptoms when you're reading or doing close work. Your doctor may want to retest you sometime in the future.\n\n" +
            "•\tSurgery. In rare cases, if exercises or computer-assisted therapy doesn't work, your doctor may recommend surgery.\n\n";




}
