public interface HEAD_ears_diseasesinformation {
    //ears
   // Airplane Ear
    String ears_Airplaneear_title="Airplane Ear";
    String ears_Airplaneear_desc="Airplane ear is the stress exerted on your eardrum and other middle ear tissues when the air pressure in your middle ear and when the air pressure in the environment are out of balance";
    String ears_Airplaneear_card_desc="Airplane ear is the stress exerted on your eardrum and other middle ear tissues when the air pressure in your middle ear and when the air pressure in the environment are out of balance";
    String ears_Airplaneear_cause_para1="Airplane ear occurs when an imbalance in the air pressure in the middle ear and air pressure in the environment prevents your eardrum (tympanic membrane) from vibrating as it should. Air pressure regulation is the work of a narrow passage called the eustachian tube. One end is connected to the middle ear. The other end has a tiny opening where the back of the nasal cavity and the top of the throat meet (nasopharynx).\n" +
            " also may be caused by:\n\n\n" +
            "•\tScuba diving\n\n" +
            "•\tHyperbaric oxygen chambers\n\n" +
            "•\tExplosions nearby\n\n";
    String ears_Airplaneear_symptoms_para1="Airplane ear can occur in one or both ears. Airplane ear signs and symptoms may include:\n\n" +
            "•\tModerate discomfort or pain in your ear\n" +
            "•\tFeeling of fullness or stuffiness in your ear\n" +
            "•\tMuffled hearing or slight to moderate hearing loss\n" +
            "If airplane ear is severe or lasts more than a few hours, you may experience:\n\n" +
            "•\tSevere pain\n" +
            "•\tPressure in your ear similar to being underwater\n" +
            "•\tModerate to severe hearing loss\n" +
            "•\tRinging in your ear (tinnitus)\n" +
            "•\tSpinning sensation (vertigo)\n" +
            "•\tVomiting resulting from vertigo\n" +
            "•\tBleeding from your ear\n";
    String ears_Airplaneear_treatment_para1="For most people, airplane ear usually heals with time. When the symptoms persist, you may need treatments to equalize pressure and relieve symptoms";
    String ears_Airplaneear_prevention_para1="•\tEncourage swallowing. Give a baby or toddler a beverage during ascents and descents to encourage frequent swallowing. A pacifier also may help. Have the child sit up while drinking. Children older than age 4 can try chewing gum, drinking through a straw or blowing bubbles through a straw.\n\n" +
            "•\tConsider eardrops. Talk to your child's doctor about prescribing your child eardrops that contain a pain reliever and numbing agent for the flight.\n\n" +
            "•\tAvoid decongestants. Decongestants aren't recommended for young children.\n\n";
    String ears_Airplaneear_homeremedies_para1="•\tYawn and swallow during ascent and descent.Yawning and swallowing activate the muscles that open your eustachian tubes. You can suck on candy or chew gum to help you swallow.\n\n" +
            "•\tUse the Valsalva maneuver during ascent and descent. Gently blow, as if blowing your nose, while pinching your nostrils and keeping your mouth closed. Repeat several times, especially during descent, to equalize the pressure between your ears and the airplane cabin.\n\n" +
            "•\tDon't sleep during takeoffs and landings. If you're awake during ascents and descents, you can do the necessary self-care techniques when you feel pressure on your ears.\n\n" +
            "•\tReconsider travel plans. If possible, don't fly when you have a cold, sinus infection, nasal congestion or ear infection. If you've recently had ear surgery, talk to your doctor about when it's safe to travel.\n\n" +
            "•\tUse an over-the-counter decongestant nasal spray.\n\n";
    //EarWaxBlockage
    //about
    String ears_Earwaxblockage_title="Ear Wax Blockage";
    String ears_Earwaxblockage_desc="Earwax blockage occurs when earwax (cerumen) accumulates in your ear or becomes too hard to wash away naturally.";
    String ears_Earwaxblockage_card_desc="Earwax blockage occurs when earwax (cerumen) accumulates in your ear or becomes too hard to wash away naturally.";
    String ears_Earwaxblockages_cause_para1="The wax in your ears is secreted by glands in the skin that lines the outer half of your ear canals. The wax and tiny hairs in these passages trap dust and other foreign particles that could damage deeper structures, such as your eardrum.\n\n" +
            "In most people, a small amount of earwax regularly makes its way to the opening of the ear, where it's washed away or falls out as new wax is secreted to replace it. If you secrete an excessive amount of wax or if earwax isn't cleared effectively, it may build up and block your ear canal.\n";
    String ears_Earwaxblockage_symptoms_para1="•\tEarache\n\n" +
            "•\tFeeling of fullness in the affected ear\n\n" +
            "•\tRinging or noises in the ear (tinnitus)\n\n" +
            "•\tDecreased hearing in the affected ear\n\n" +
            "•\tDizziness\n\n" +
            "•\tCough\n\n";
    String ears_Earwaxblockage_treatment_para1="Your doctor can remove excess wax using a small, curved instrument called a curet or by using suction while inspecting the ear. Your doctor can also flush out the wax using a water pick or a rubber-bulb syringe filled with warm water.\n\n" +
            "If earwax buildup is a recurring problem, your doctor may recommend that you use a wax-removal medication, such as carbamide peroxide (Debrox, Murine Earwax Removal System). Because these drops can irritate the delicate skin of the eardrum and ear canal, use them only as directed.\n";
    String ears_Earwaxblockage_homeremedies_para1="•\tSoften the wax. Use an eyedropper to apply a few drops of baby oil, mineral oil, glycerin or hydrogen peroxide in your ear canal.\n\n" +
            "•\tUse warm water. After a day or two, when the wax is softened, use a rubber-bulb syringe to gently squirt warm water into your ear canal. Tilt your head and pull your outer ear up and back to straighten your ear canal. When finished irrigating, tip your head to the side to let the water drain out.\n\n" +
            "•\tDry your ear canal. When finished, gently dry your outer ear with a towel or hand-held dryer.\n\n";
  //Swimmersear
    //about

    String ears_Swimmersear_title="Swimmers Ear";
    String ears_Swimmersear_status="Common";
    String ears_Swimmersear_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging rarely required\n" +
            "Short-term: resolves within days to weeks\n";
    String ears_Swimmersear_desc="Swimmer's ear is an infection in the outer ear canal, which runs from your eardrum to the outside of your head. It's often brought on by water that remains in your ear after swimming, creating a moist environment that aids bacterial growth.";
    String ears_Swimmersear_card_desc="Swimmer's ear is an infection in the outer ear canal, which runs from your eardrum to the outside of your head. It's often brought on by water that remains in your ear after swimming, creating a moist environment that aids bacterial growth.";
    String ears_Swimmersear_cause_para1="Swimmer's ear is an infection that's usually caused by bacteria commonly found in water and soil. Infections caused by a fungus or a virus are less common";
    String ears_Swimmersear_symptoms_para1="Swimmer's ear symptoms are usually mild at first, but they may get worse if your infection isn't treated or spreads. Doctors often classify swimmer's ear according to mild, moderate and advanced stages of progression.\n\n";
    String ears_Swimmersear_symptoms_para2="Mild signs and symptoms\n\n" +
            "•\tItching in your ear canal\n" +
            "•\tSlight redness inside your ear\n" +
            "•\tMild discomfort that's made worse by pulling on your outer ear (pinna, or auricle) or pushing on the little \"bump\" (tragus) in front of your ear\n" +
            "•\tSome drainage of clear, odorless fluid\n" +
            "Moderate progression\n\n" +
            "•\tMore intense itching\n" +
            "•\tIncreasing pain\n" +
            "•\tMore extensive redness in your ear\n" +
            "•\tExcessive fluid drainage\n" +
            "•\tDischarge of pus\n" +
            "•\tFeeling of fullness inside your ear and partial blockage of your ear canal by swelling, fluid and debris\n" +
            "•\tDecreased or muffled hearing\n" +
            "Advanced progression\n\n" +
            "•\tSevere pain that may radiate to your face, neck or side of your head\n" +
            "•\tComplete blockage of your ear canal\n" +
            "•\tRedness or swelling of your outer ear\n" +
            "•\tSwelling in the lymph nodes in your neck\n" +
            "•\tFever\n";
    String ears_Swimmersear_treatment_para1="Cleaning\n\n" +
            "Cleaning your outer ear canal is necessary to help eardrops flow to all infected areas. Your doctor will use a suction device or ear curette to clean away any discharge, clumps of earwax, flaky skin and other debris.\n" +
            "Medications for infection\n\n" +
            "For most cases of swimmer's ear, your doctor will prescribe eardrops that have some combination of the following ingredients, depending on the type and seriousness of your infection:\n" +
            "•\tAcidic solution to help restore your ear's normal antibacterial environment\n" +
            "•\tSteroid to reduce inflammation\n" +
            "•\tAntibiotic to fight bacteria\n" +
            "•\tAntifungal medication to fight an infection caused by a fungus\n" +
            "Ask your doctor about the best method for taking your eardrops. Some ideas that may help you use eardrops include the following:\n\n" +
            "•\tReduce the discomfort of cool drops by holding the bottle in your hand for a few minutes to bring the temperature closer to body temperature.\n" +
            "•\tLie on your side with your infected ear up to help medication travel through the full length of your ear canal.\n" +
            "•\tIf possible, have someone help you put the drops in your ear.\n" +
            "If your ear canal is completely blocked by swelling, inflammation or excess discharge, your doctor may insert a wick made of cotton or gauze to promote drainage and help draw medication into your ear canal\n";
    String ears_Swimmersear_homeremedies_para1="•\tKeep your ears dry. Dry your ears thoroughly after exposure to moisture from swimming or bathing. Dry only your outer ear, wiping it slowly and gently with a soft towel or cloth. Tip your head to the side to help water drain from your ear canal. You can dry your ears with a blow dryer if you put it on the lowest setting and hold it at least a foot (about 0.3 meters) away from the ear.\n\n" +
            "•\tAt-home preventive treatment. If you know you don't have a punctured eardrum, you can use homemade preventive eardrops before and after swimming. A mixture of 1 part white vinegar to 1 part rubbing alcohol may help promote drying and prevent the growth of bacteria and fungi that can cause swimmer's ear. Pour 1 teaspoon (about 5 milliliters) of the solution into each ear and let it drain back out. Similar over-the-counter solutions may be available at your drugstore.\n\n" +
            "•\tSwim wisely. Watch for signs alerting swimmers to high bacterial counts and don't swim on those days.\n\n" +
            "•\tAvoid putting foreign objects in your ear. Never attempt to scratch an itch or dig out earwax with items such as a cotton swab, paper clip or hairpin. Using these items can pack material deeper into your ear canal, irritate the thin skin inside your ear or break the skin.\n\n" +
            "•\tProtect your ears from irritants. Put cotton balls in your ears while applying products such as hair sprays and hair dyes.\n\n" +
            "•\tUse caution after an ear infection or surgery. If you've recently had an ear infection or ear surgery, talk to your doctor before you go swimming.\n\n";
    //RupturedEardrum
//about
    String ears_Rupturedeardrum_title="Ruptured Eardrum";
    String ears_Rupturedeardrum_status="Common";
    String ears_Rupturedeardrum_about="More than 1 million cases per year (India)\n" +
            "Treatable by a medical professional\n" +
            "Requires a medical diagnosis\n" +
            "Lab tests or imaging not required\n" +
            "Short-term: resolves within days to weeks\n";
    String ears_Rupturedeardrum_desc="A ruptured eardrum — or perforated tympanic membrane as it's medically known — is a hole or tear in your eardrum, the thin tissue that separates your ear canal from your middle ear.";
    String ears_Rupturedeardrum_card_desc="A ruptured eardrum — or perforated tympanic membrane as it's medically known — is a hole or tear in your eardrum, the thin tissue that separates your ear canal from your middle ear.";
    String ears_Ruptureseardrum_cause_para1="•\tMiddle ear infection (otitis media). A middle ear infection often results in the accumulation of fluids in your middle ear. Pressure from these fluids can cause the eardrum to rupture.\n\n" +
            "•\tBarotrauma. Barotrauma is stress exerted on your eardrum when the air pressure in your middle ear and the air pressure in the environment are out of balance. If the pressure is severe, your eardrum can rupture. Barotrauma is also called airplane ear because it's most often caused by air pressure changes associated with air travel.\n\n" +
            "Other events that can cause sudden changes in pressure — and possibly a ruptured eardrum — include scuba diving and a direct blow to the ear, such as the impact of an automobile air bag.\n\n" +
            "•\tLoud sounds or blasts (acoustic trauma). A loud sound or blast, as from an explosion or gunshot — essentially an overpowering sound wave — can cause a tear in your eardrum.\n\n" +
            "•\tForeign objects in your ear. Small objects, such as a cotton swab or hairpin, can puncture or tear the eardrum.\n\n" +
            "•\tSevere head trauma. Severe injury, such as skull fracture, may cause the dislocation or damage to middle and inner ear structures, including your eardrum.\n\n";
    String ears_Rupturedeardrum_symptoms_para1="•\tEar pain that may subside quickly\n" +
            "•\tClear, pus-filled or bloody drainage from your ear\n\n" +
            "•\tHearing loss\n\n" +
            "•\tRinging in your ear (tinnitus)\n\n" +
            "•\tSpinning sensation (vertigo)\n\n" +
            "•\tNausea or vomiting that can result from vertigo.\n\n";
    String ears_Rupturedeardrum_treatment_para1="•\tEardrum patch. If the tear or hole in your eardrum doesn't close on its own, an ENT specialist may seal it with a patch. With this office procedure, your ENT may apply a chemical to the edges of the tear to stimulate growth and then apply a patch over the hole. The procedure may need to be repeated more than once before the hole closes.\n\n" +
            "•\tSurgery. If a patch doesn't result in proper healing or your ENT determines that the tear isn't likely to heal with a patch, he or she may recommend surgery. The most common surgical procedure is called tympanoplasty. Your surgeon grafts a tiny patch of your own tissue to close the hole in the eardrum. This procedure is done on an outpatient basis, meaning you can usually go home the same day unless medical anesthesia conditions require a longer hospital stay\n";
    String ears_Rupturedeardrum_homeremedies_para1="•\tGet treatment for middle ear infections. Be aware of the signs and symptoms of middle ear infection, including earache, fever, nasal congestion and reduced hearing. Children with a middle ear infection often rub or pull on their ears. Seek prompt evaluation from your primary care doctor to prevent potential damage to the eardrum.\n\n" +
            "•\tProtect your ears during flight. If possible, don't fly if you have a cold or an active allergy that causes nasal or ear congestion. During takeoffs and landings, keep your ears clear with pressure-equalizing earplugs, yawning or chewing gum. Or use the Valsalva maneuver — gently blowing, as if blowing your nose, while pinching your nostrils and keeping your mouth closed. Don't sleep during ascents and descents.\n\n" +
            "•\tKeep your ears free of foreign objects. Never attempt to dig out excess or hardened earwax with items such as a cotton swab, paper clip or hairpin. These items can easily tear or puncture your eardrum. Teach your children about the damage that can be done by putting foreign objects in their ears.\n\n" +
            "•\tGuard against excessive noise. Protect your ears from unnecessary damage by wearing protective earplugs or earmuffs in your workplace or during recreational activities if loud noise is present.\n\n";






}
