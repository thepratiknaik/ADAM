public interface STOMACH_Diseases {



    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String STOMACH_GERD_title = "Gastroesophageal Reflux Disease\n";
    String STOMACH_GERD_status = "Very common\n";
    String STOMACH_GERD_about = "More than 10 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Usually self-diagnosable\n\n" +
            "Lab tests or imaging rarely required\n\n" +
            "Medium-term: resolves within months\n\n";
    String STOMACH_GERD_desc = "When stomach acid backs up into your esophagus — a condition called acid reflux — you may feel a burning pain in the middle of your chest.\n\n" +
            " It often occurs after meals or at night.\n\n";
    String STOMACH_GERD_card_desc = "";


    //SYMPTOMS
    String STOMACH_GERD_causes_para1 = "GERD is caused by frequent acid reflux.\n\n" +
            "When you swallow, a circular band of muscle around the bottom of your esophagus (lower esophageal sphincter) relaxes to allow food and liquid to flow into your stomach. Then the sphincter closes again.\n\n" +
            "If the sphincter relaxes abnormally or weakens, stomach acid can flow back up into your esophagus. This constant backwash of acid irritates the lining of your esophagus, often causing it to become inflamed.\n\n";
    String STOMACH_GERD_symptoms_para1 = " It’s common for people to experience:\n\n\n" +
            "acid reflux\n\n" +
            "heartburn once in a while (for twice each week)\n\n" +
            " If you experience persistent heartburn, bad breath, tooth erosion, nausea, pain in your chest or upper part of your abdomen, or have trouble swallowing or breathing, see your doctor.\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    //TREATMENT
    String STOMACH_GERD_treatment_para1 = "If you have both GERD and asthma, managing your GERD will help control your asthma symptoms.\n\n" +
            "Studies have shown that people with asthma and GERD saw a decrease in asthma symptoms (and asthma medication use) after treating their reflux disease.\n\n" +
            "Lifestyle changes to treat GERD include:\n\n\n" +
            "•    Elevate the head of the bed 6-8 inches\n\n" +
            "•    Lose weight\n\n" +
            "•    Stop smoking\n\n" +
            "•    Decrease alcohol intake\n\n" +
            "•    Limit meal size and avoid heavy evening meals\n\n" +
            "•    Do not lie down within two to three hours of eating\n\n" +
            "•    Decrease caffeine intake\n\n" +
            "•    Avoid theophylline (if possible)\n\n" +
            "Your physician may also recommend medications to treat reflux or relieve symptoms. Over-the-counter antacids and H2 blockers may help decrease the effects of stomach acid. Proton pump inhibitors block acid production and also may be effective.\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String STOMACH_Gallstones_title = "Gallstones\n";
    String STOMACH_Gallstones_status = "Very common\n";
    String STOMACH_Gallstones_about = "More than 10 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String STOMACH_Gallstones_desc = "Gallstones are hard deposits that form in your gallbladder. Gallstones are hard deposits that form in your gallbladder.\n\n" +
            "Gallstones can form when there’s too much cholesterol or waste in your bile, or if your gallbladder doesn’t empty properly.\n\n" +
            "\n";
    String STOMACH_Gallstones_card_desc = "Gallstones are hard deposits that form in your gallbladder.\n\n";

    //SYMPTOMS
    String STOMACH_Gallstones_causes_para1 = "Your bile contains too much cholesterol. Normally, your bile contains enough chemicals to dissolve the cholesterol excreted by your liver. But if your liver excretes more cholesterol than your bile can dissolve, the excess cholesterol may form into crystals and eventually into stones.\n\n" +
            "Your bile contains too much bilirubin. Bilirubin is a chemical that's produced when your body breaks down red blood cells. Certain conditions cause your liver to make too much bilirubin, including liver cirrhosis, biliary tract infections and certain blood disorders. The excess bilirubin contributes to gallstone formation.\n\n" +
            "Your gallbladder doesn't empty correctly. If your gallbladder doesn't empty completely or often enough, bile may become very concentrated, contributing to the formation of gallstones.\n\n";
    String STOMACH_Gallstones_symptoms_para1 = "Gallstones may cause no signs or symptoms. If a gallstone lodges in a duct and causes a blockage, the resulting signs and symptoms may include:\n\n\n" +
            "Sudden and rapidly intensifying pain in the upper right portion of your abdomen\n\n" +
            "Sudden and rapidly intensifying pain in the center of your abdomen, just below your breastbone\n\n" +
            "Back pain between your shoulder blades\n\n" +
            "Pain in your right shoulder\n\n" +
            "Nausea or vomiting\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    //TREATMENT
    String STOMACH_Gallstones_treatment_para1 = "Low fat diet\n\n\n" +
            "Reducing intake of high-fat foods such as dairy, oil and red meat to improve cardiovascular health.\n\n" +
            "Cholesterol medication\n\n\n" +
            "Lowers levels of harmful cholesterol in the blood or increases levels of beneficial cholesterol.\n\n";
    String STOMACH_Gallstones_homeremedies_para1 = "Apple juice\n\n" +
            "Pear juice\n\n" +
            "Beetroot Carrot and Cucumber juice\n\n" +
            "\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String STOMACH_StomachPain_title = "Nonulcer Stomach Pain\n";
    String STOMACH_StomachPain_status = "Very Common\n";
    String STOMACH_StomachPain_desc = "Nonulcer stomach pain is a term used to describe signs and symptoms of indigestion that have no obvious cause. Nonulcer stomach pain is also called functional dyspepsia (dis-PEP-see-uh) or nonulcer dyspepsia.\n\n" +
            "Nonulcer stomach pain is common and can be long lasting. Nonulcer stomach pain can cause signs and symptoms that resemble those of an ulcer, such as pain or discomfort in your upper abdomen, often accompanied by bloating, belching and nausea.\n\n";
    String STOMACH_StomachPain_card_desc = "Nonulcer stomach pain is a term used to describe signs and symptoms of indigestion that have no obvious cause.\n";
    String STOMACH_ = "";

    //SYMPTOMS
    String STOMACH_StomachPain_causes_para1 = "It's not clear what causes nonulcer stomach pain. Doctors consider it a functional disorder, which means it's not found to be caused by a specific disease or diagnosable disorder.\n\n";
    String STOMACH_StomachPain_symptoms_para1 = "Signs and symptoms of nonulcer stomach pain may include:\n\n\n" +
            "A burning sensation or discomfort in your upper abdomen or lower chest, sometimes relieved by food or antacids\n\n" +
            "Bloating\n\n" +
            "Belching\n\n" +
            "An early feeling of fullness when eating\n\n" +
            "Nausea\n\n" +
            " \n" +
            "Drinking too much alcohol or too many caffeinated beverages\n\n" +
            "Smoking\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    //TREATMENT
    String STOMACH_StomachPain_treatment_para1 = "Nonulcer stomach pain that is long lasting and isn't controlled by lifestyle changes may require treatment. What treatment you receive depends on your signs and symptoms. Treatment may combine medications with behavior therapy.\n\n";
    String STOMACH_StomachPain_Medication_para1 = "Medications that may help in managing the signs and symptoms of nonulcer stomach pain include:\n\n\n" +
            "Over-the-counter gas remedies. Drugs that contain the ingredient simethicone may provide some relief by reducing intestinal gas. Examples of gas-relieving remedies include Mylanta and Gas-X.\n\n" +
            "Medications to reduce acid production. Called H-2-receptor blockers, these medications are available over-the-counter and include cimetidine (Tagamet HB), famotidine (Pepcid AC), nizatidine (Axid AR) and ranitidine (Zantac 75). Stronger versions of these medications are available in prescription form.\n\n" +
            "Medications that block acid 'pumps.' Proton pump inhibitors shut down the acid pumps within acid-secreting stomach cells. Proton pump inhibitors reduce acid by blocking the action of these tiny pumps.\n\n";
    String STOMACH_StomachPain_homeremedies_para1 = "7 Natural Remedies for Your Upset Stomach\n\n\n" +
            "Bitters and soda.\n\n" +
            "Ginger.\n\n" +
            "Chamomile tea.\n\n" +
            "BRAT diet.\n\n" +
            "Peppermint.\n\n" +
            "Apple cider vinegar.\n\n" +
            "Heating pad.\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";

    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String STOMACH_StomachCancer_title = "Stomach Cancer\n";
    String STOMACH_StomachCancer_status = "Rare\n";
    String STOMACH_StomachCancer_about = "Fewer than 1 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required.\n\n";
    String STOMACH_StomachCancer_desc = "Stomach cancer is cancer that occurs in the stomach –the muscular sac located in the upper middle of your abdomen,just below your ribs.Another term for stomach cancer is\n" +
            "gastic cancer.Theses are the most common type of stomach cancer.\n";
    String STOMACH_StomachCancer_card_desc = "Stomach cancer is cancer that occurs in the stomach –the muscular sac located in the upper middle of your abdomen\n\n";

    //SYMPTOMS
    String STOMACH_StomachCancer_causes_para1 = "Inflammation in your gut called gastritis, a certain type of long-lasting anemia called pernicious anemia, and growths in your stomach called polyps also can make you more likely to get cancer. \n\n";
    String STOMACH_StomachCancer_symptoms_para1 = "Symptoms:\n\n\n" +
            "Fatigue\n\n" +
            "Feeling bloated after eating\n\n" +
            "Feeling full after eating small amount of food\n\n" +
            "Heartburn that is severe and persistent\n\n" +
            "Stomach pain\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    //TREATMENT
    String STOMACH_StomachCancer_treatment_para1 = "Treatment for stomach cancer depends on several factors, including the severity of the cancer and the individual's overall health and preferences.\n\n" +
            "Treatments may include surgery, chemotherapy, radiation therapy, medications, and taking part in clinical trials.\n\n";
    String STOMACH_StomachCancer_surgery_desc = "The surgeon's aim is to remove the stomach cancer from the body as well as a margin of healthy tissue. This is necessary to make sure no cancerous cells are left behind.\n\n";
    String STOMACH_StomachCancer_radiational_title = "Radiation therapy\n";
    String STOMACH_StomachCancer_radiational_desc = "In radiation therapy, energy rays are used to target and kill cancerous cells. This type of therapy is not commonly used to treat stomach cancer because of the risk of harming other nearby organs. However, if the cancer is advanced or causing serious symptoms, such as bleeding or severe pain, radiation therapy is an option.\n\n";
    String STOMACH_StomachCancer_neoadjuvent_title = "Neoadjuvant radiation\n";
    String STOMACH_StomachCancer_neoadjuvent_desc = "Neoadjuvant radiation refers to the use of radiation therapy before surgery to make the tumors smaller, so that they can be removed more easily.\n\n";


    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String STOMACH_Polyps_title = "Polyps\n";
    String STOMACH_Polyps_status = "RARE\n";
    String STOMACH_Polyps_desc = "Stomach polyps are masses of cells that form on the inside lining of your stomach. Stomach polyps, also called gastric polyps, are rare.\n\n" +
            "Stomach polyps usually don't cause any signs or symptoms. The polyps are most often discovered when your doctor is examining you for some other reason.\n\n" +
            "Most stomach polyps don't become cancerous, but certain types can increase your risk of stomach cancer in the future. For this reason, some stomach polyps are removed and others are not treated.\n\n";
    String STOMACH_Polyps_card_desc = "Stomach polyps are masses of cells that form on the inside lining of your stomach.\n";
    String STOMACH_ = "";

    //SYMPTOMS
    String STOMACH_Polyps_causes_para1 = "Doctors don’t know the exact cause of colonic polyps, but polyps result from abnormal tissue growth.\n\n" +
            "The body periodically develops new healthy cells to replace old cells that are damaged or no longer needed. The growth and division of new cells is usually regulated. In some cases, however, new cells grow and divide before they’re needed. This excess growth causes polyps to form. The polyps can develop in any area of the colon.\n\n";
    String STOMACH_Polyps_symptoms_para1 = "Stomach polyps usually don't cause signs or symptoms. But as a stomach polyp enlarges, open sores (ulcers) may develop on its surface. In rare occurrences, the polyp blocks the opening between your stomach and your small intestine.\n\n" +
            "If you have stomach polyps, you may experience:\n\n\n" +
            "Pain or tenderness when you press your stomach area (abdomen)\n\n" +
            "Bleeding\n\n" +
            "Anemia\n\n" +
            "Stomach polyps are common among people aging 50 and older.\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";

    //TREATMENT
    String STOMACH_Polyps_treatment_para1 = "Some polyps won’t require treatment, especially if your doctor says they aren’t harmful. Throat polyps typically go away on their own with rest and voice therapy. Others may be surgically removed as a precaution against the future development of cancer.\n\n" +
            "Treatment for polyps depends on a number of factors, including:\n\n" +
            "whether or not the polyps are cancerous\n\n" +
            "how many polyps are found\n\n" +
            "where they are located\n\n" +
            "their size\n\n" +
            "In the case of colorectal polyps, a doctor may remove the polyps during a colonoscopy. A colonoscopy is when your doctor uses a thin tube with a camera attached to look at the insides of your rectum and large intestine.\n\n";
    String STOMACH_Polyps_homeremedies_para1 = "Treating Nasal Polyps at Home with Natural Remedies\n\n" +
            "Cayenne pepper.\n\n" +
            "Neti pot.\n\n" +
            "Steam.\n\n" +
            "Tea tree oil.\n\n" +
            "Chamomile.\n\n" +
            "Butterbur.\n\n" +
            "Turmeric.\n\n";
    String STOMACH_ = "";
    String STOMACH_ = "";
    String STOMACH_ = "";



}

