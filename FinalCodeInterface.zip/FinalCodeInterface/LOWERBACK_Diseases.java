public interface LOWERBACK_Diseases {

    //LOWERBACK
        //ABOUT
        //about
    String LOWERBACK_BackPain_title = "Lower Back Pain\n";
    String LOWERBACK_BackPain_status = "Very common\n";
    String LOWERBACK_BackPain_about = "More than 10 million cases per year (India)\n\n" +
            "Usually self-treatable\n\n" +
            "Usually self-diagnosable\n\n" +
            "Lab tests or imaging rarely required\n\n";
    String LOWERBACK_BackPain_desc = "Low back pain is a universal human experience -- almost everyone has it at some point. The lower back, which starts below the ribcage, is called the lumbar region. Pain here can be intense and is one of the top causes of missed work. \n\n";
    String LOWERBACK_BackPain_card_desc = "Low back pain is a universal human experience -- almost everyone has it at some point.\n\n";

    //Symptoms

    String LOWERBACK_BackPain_causes_para1 = "Bulging or herniated disc. A disc may bulge outward. \n\n" +
            "•\tSpinal stenosis develops when the spinal canal or a nerve passageway abnormally narrows.\n\n" +
            "•\tSpinal arthritis, also called spinal osteoarthritis or spondylosis, is a common degenerative spine problem. It affects the spine's facet joints and may contribute to the development of bone spurs.\n\n" +
            "•\tSpondylolisthesis occurs when a lumbar (low back) vertebral body slips forward over the vertebra below it\n\n" +
            "•\tVertebral fractures (burst or compression types) are often caused by some type of trauma (eg, fall).\n\n" +
            "•\tOsteomyelitis is a bacterial infection that can develop in one of the spine's bones.\n\n";
    String LOWERBACK_BackPain_symptoms_para1 = "Pain areas: in the back, muscles and bones, hip, or leg\n\n" +
            "\n" +
            "Sensory: leg numbness or pins and needles\n\n" +
            "\n" +
            "Also common: back joint dysfunction or muscle spasms\n\n" +
            "\n";


    //Treatment

    String LOWERBACK_BackPain_treatment_para1 = "Nonsteroidal anti-inflammatory drug\n\n" +
            "Relieves pain, decreases inflammation and reduces fever.\n\n" +
            "Analgesic\n\n" +
            "Relieves pain.\n\n" +
            "Muscle Relaxant\n\n" +
            "Reduces muscle tension and helps relieve muscle pain and discomfort.\n\n" +
            "Narcotic\n\n" +
            "Relieves pain, dulls the senses and causes drowsiness. May become addictive.\n\n";
    String LOWERBACK_BackPain_homeremedies_para1 = "Heating pad\n\n" +
            "Soothes painful muscles or joints and can help drain skin infections.\n\n" +
            "Physical exercise\n\n" +
            "Aerobic activity for 20–30 minutes 5 days a week improves cardiovascular health. If injured, pursuing an activity that avoids the injured muscle group or joint can help maintain physical function while recovering.\n\n" +
            "\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about
    String LOWERBACK_Spondylitis_title = "Spondylitis\n";
    String LOWERBACK_Spondylitis_status = "Common\n";
    String LOWERBACK_Spondylitis_about = "More than 1 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String LOWERBACK_Spondylitis_desc = "The condition is more common among men and usually begins in early adulthood.\n" +
            "Symptoms typically appear in early adulthood and include reduced flexibility in the spine. This reduced flexibility eventually results in a hunched-forward posture. Pain in the back and joints is also common.\n\n" +
            "Treatment includes medication, physiotherapy and in rare cases, surgery.\n\n";
    String LOWERBACK_Spondylitis_card_desc = "The condition is more common among men and usually begins in early adulthood.\n\n";

    //Symptoms

    String LOWERBACK_Spondylitis_causes_para1 = "The exact cause of AS is unknown, though genetics play a role. The genetic marker HLA-B27 is present in 95 percent of Caucasians with AS. This gene association varies across ethnic and racial groups. Overall, carrying the HLA-B27 gene may present a 40 percent risk for developing AS. Many people with this genetic marker don’t develop AS, and you don’t have to be HLA-B27 positive to have AS.\n\n";
    String LOWERBACK_Spondylitis_symptoms_para1 = "Other symptoms vary from person to person. These symptoms can include:\n\n\n" +
            "•\tloss of flexibility\n\n" +
            "•\tspinal fusion\n\n" +
            "•\tblurred vision\n\n" +
            "•\tsensitivity to light\n\n" +
            "•\tred, watery eyes\n\n" +
            "•\teye pain\n\n" +
            "•\treduced lung capacity\n\n" +
            "•\tdifficulty breathing\n\n" +
            "•\tcauda equina syndrome\n\n" +
            "•\tgeneral unwell feeling\n\n" +
            "•\tstomach or bowel problems\n\n";


    //Treatment

    String LOWERBACK_Spondylitis_homeremedies_para1 = "Stretching\\n\n" +
            "Stretching helps build flexibility and may reduce pain. Consider adding the spine stretch or the low-back rotation stretch to your daily routine.\n\n" +
            "2. Heat therapy\n\n" +
            "Apply a hot water bottle or heating pad to the affected area to reduce stiffness and pain. You may also use moist or dry heat. A warm bath may also help, especially before exercise. Don’t use heat therapy without consulting your doctor if you have diabetes, deep vein thrombosis, vascular disease, an open wound, or a skin condition such as dermatitis.\n\n" +
            "3. Cold therapy\n\n" +
            "Applying an ice pack, cold gel pack, or a bag of frozen vegetables to painful joints can help reduce swelling. After exercise, cold therapy may help reduce inflammation. Don’t apply ice for more than 20 minutes at a time. Don’t use cold therapy without consulting your doctor if you have circulation problems.\n\n" +
            "4. Massage therapy\n\n" +
            "Massage helps you relax. It may also help you feel more flexible or “loose” so that you can exercise or stretch. Massage may cause pain at tender points around your spine. If this happens, avoid those areas and only use light massage techniques until the pain improves.\n\n" +
            "5. Movement\n\n" +
            "The more you sit, the stiffer you’re likely to feel. Get up, move around, and stretch regularly. If you have a desk job, take a “get up and move” break every hour.\n\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about
    String LOWERBACK_Osteomyelitis_title = "Osteomyelitis\n";
    String LOWERBACK_Osteomyelitis_status = "Extremely rare\n";
    String LOWERBACK_Osteomyelitis_about = "Fewer than 5 thousand cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Short-term: resolves within days to weeks\n\n";
    String LOWERBACK_Osteomyelitis_desc = "Infections can reach bones by travelling through the bloodstream or spreading from nearby tissue.\n\n" +
            "\n" +
            "Common symptoms include pain, fever and chills.\n" +
            "Treatment is usually surgery to remove portions of bone that have died. This is followed by strong antibiotics, often by an IV, for at least six weeks.\n\n" +
            "\n";
    String LOWERBACK_Osteomyelitis_card_desc = "";

    //Symptoms

    String LOWERBACK_Osteomyelitis_causes__para1 = "Certain conditions and behaviors that weaken the immune system increase a person's risk for osteomyelitis, including:\n\n\n" +
            "•\tDiabetes (most cases of osteomyelitis stem from diabetes)\n\n" +
            "•\tSickle cell disease\n\n" +
            "•\tHIV or AIDS\n\n" +
            "•\tRheumatoid arthritis\n\n" +
            "•\tIntravenous drug use\n\n" +
            "•\tAlcoholism\n\n" +
            "•\tLong-term use of steroids\n\n" +
            "•\tHemodialysis\n\n" +
            "•\tPoor blood supply\n\n" +
            "•\tRecent injury\n\n";
    String LOWERBACK_Osteomyelitis_symptoms_para1 ="Pain areas: in the bones or hip\n\n" +
            "Whole body: chills, fatigue, fever, malaise, or night sweats\n\n" +
            "Skin: ulcers or redness\n\n" +
            "Also common: swelling\n\n" +
            "\n" +
            "Acute osteomyelitis develops rapidly over a period of seven to 10 days. The symptoms for acute and chronic osteomyelitis are very similar and include:\n\n\n" +
            "•\tFever, irritability, fatigue\n\n" +
            "•\tNausea\n\n" +
            "•\tTenderness, redness, and warmth in the area of the infection\n\n" +
            "•\tSwelling around the affected bone\n\n" +
            "•\tLost range of motion\n\n";



    //Treatment

            String LOWERBACK_Osteomyelitis_treatment_para1 = "Figuring out if a person has osteomyelitis is the first step in treatment. It's also surprisingly difficult. Doctors rely on X-rays, blood tests, MRI, and bone scans to get a picture of what's going on. A bone biopsy is necessary to confirm a diagnosis of osteomyelitis. This also helps determine the type of organism, typically bacteria, causing the infection so the right medicationcan be prescribed.\n\n";

}
