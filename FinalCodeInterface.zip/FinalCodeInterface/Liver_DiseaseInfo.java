public interface Liver_DiseaseInfo {
    //Liver
    //Acute Liver Failure
        //about

    String Liver_LiverFailure_title = "Acute Liver Failure";
    String Liver_LiverFailure_status = "Rare\n";
    String Liver_LiverFailure_about = "Fewer than 1 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n";
    String Liver_LiverFailure_desc = "Acute liver failure is loss of liver function that occurs rapidly — in days or weeks —usually in a person who has no pre-existing liver disease. Acute liver failure is less common than chronic liver failure, which develops more slowly.\n\n" +
            "Acute liver failure, also known as fulminant hepatic failure, can cause serious complications, including excessive bleeding and increasing pressure in the brain. It's a medical emergency that requires hospitalization.\n\n" +
            "Depending on the cause, acute liver failure can sometimes be reversed with treatment. In many situations, though, a liver transplant may be the only cure.\n\n\n";
    //Symptoms
        //causes

    String Liver_LiverFailure_causes_para1 = "•\tAcetaminophen overdose.  Acute liver failure can occur after one very large dose of acetaminophen, or after higher than recommended doses every day for several days.\n\n" +
            "•\tPrescription medications. Some prescription medications, including antibiotics, nonsteroidal anti-inflammatory drugs and anticonvulsants, can cause acute liver failure.\n\n" +
            "•\tHerbal supplements. Herbal drugs and supplements, including kava, ephedra, skullcap and pennyroyal, have been linked to acute liver failure.\n\n" +
            "•\tHepatitis and other viruses. Hepatitis A, hepatitis B and hepatitis E can cause acute liver failure. Other viruses that can cause acute liver failure include Epstein-Barr virus, cytomegalovirus and herpes simplex virus.\n\n" +
            "•\tToxins. Toxins that can cause acute liver failure include the poisonous wild mushroom Amanita phalloides, which is sometimes mistaken for one that is safe to eat. Carbon tetrachloride is another toxin that can cause acute liver failure. It is an industrial chemical found in refrigerants and solvents for waxes, varnishes and other materials.\n\n" +
            "•\tAutoimmune disease. Liver failure can be caused by autoimmune hepatitis — a disease in which your immune system attacks liver cells, causing inflammation and injury.\n\n" +
            "•\tDiseases of the veins in the liver. Vascular diseases, such as Budd-Chiari syndrome, can cause blockages in the veins of the liver and lead to acute liver failure.\n\n" +
            "•\tMetabolic disease. Rare metabolic diseases, such as Wilson's disease and acute fatty liver of pregnancy, infrequently cause acute liver failure.\n\n" +
            "•\tCancer. Cancer that either begins in or spreads to your liver can cause your liver to fail.\n\n" +
            "•\tShock. Overwhelming infection (sepsis) and shock can severely impair blood flow to the liver, causing liver failure.\n\n\n";
        //symptoms

    String Liver_LiverFailure_symptoms_para1 = "Signs and symptoms of acute liver failure may include:\n\n\n" +
            "•\tYellowing of your skin and eyeballs (jaundice)\n" +
            "•\tPain in your upper right abdomen\n" +
            "•\tAbdominal swelling\n" +
            "•\tNausea\n" +
            "•\tVomiting\n" +
            "•\tA general sense of feeling unwell (malaise)\n" +
            "•\tDisorientation or confusion\n" +
            "•\tSleepiness\n\n\n";

    //Treatment
        //treatment

    String Liver_LiverFailure_treatment_para1 = "People with acute liver failure are often treated in the intensive care unit of a hospital in a facility that can perform a liver transplant, if necessary. Your doctor may try to treat the liver damage itself, but in many cases, treatment involves controlling complications and giving your liver time to heal.\n\n\n" +
            "Acute liver failure treatments may include:\\n\\n\n" +
            "•\tMedications to reverse poisoning. Acute liver failure caused by acetaminophen overdose is treated with a medication called acetylcysteine. This medication may also help treat other causes of acute liver failure. Mushroom and other poisonings also may be treated with drugs that can reverse the effects of the toxin and may reduce liver damage.\n\n" +
            "•\tLiver transplant. When acute liver failure can't be reversed, the only treatment may be a liver transplant. During a liver transplant, a surgeon removes your damaged liver and replaces it with a healthy liver from a donor.\n\n\n";

        //home remedies

    String Liver_LiverFailure_homeremedies_para1 = "Follow instructions on medications\n\n" +
            "Drink alchohol in moderations if at all\n\n" +
            "Get vaccinated\n\n";




    //AgeSpots>>>>>>
        //About


    String Liver_AgeSpots_title = "AgeSpots\n";
    String Liver_AgeSpots_status = "Very common\n";
    String Liver_AgeSpots_about = "More than 10 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Usually self-diagnosable\n\n" +
            "Lab tests or imaging not required\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String Liver_AgeSpots_desc = "Age spots — also called liver spots and solar lentigines — are flat tan, brown or black spots. They vary in size and usually appear on the face, hands, shoulders and arms — areas most exposed to the sun.\n\n" +
            "Age spots are very common in adults older than age 50. But, younger people can get them too, especially if they spend a lot of time in the sun.\n\n" +
            "Although age spots can look like cancerous growths, true age spots are harmless and don't need treatment. For cosmetic reasons, age spots can be lightened with skin-bleaching products or removed. However, preventing age spots — by avoiding the sun and using sunscreen — may be the easiest way to maintain your skin's youthful appearance.\n\n\n";

    //Symptoms
        //causes

    String Liver_Agespots_causes_para1 = "Age spots are caused by overactive pigment cells. Ultraviolet (UV) light accelerates the production of melanin. On the areas of skin that have had years of frequent and prolonged sun exposure, age spots appear when melanin becomes \"clumped\" or is produced in high concentrations.\n\n" +
            "The use of commercial tanning lamps and tanning beds can also contribute to the development of age spots.\n\n\n";

        //symptoms

    String Liver_Agespots_symptoms_para1 = "Age spots typically develop in people with a fair complexion, but they can be seen in those with darker skin. Age spots:\n\n\n" +
            "•\tAre flat, oval areas of increased pigmentation\n\n" +
            "•\tAre usually tan, brown or black\n\n" +
            "•\tOccur on skin that has had the most sun exposure over the years, such as the backs of hands, tops of feet, face, shoulders and upper back\n\n";



    //Enlarged Liver>>>>
        //About

    String Liver_EnlargedLiver_title = "EnlargeLiver\n";
    String Liver_EnlargedLiver_status = "Rare";
    String Liver_EnlargedLiver_desc = "An enlarged liver is one that's bigger than normal. The liver is a large, football-shaped organ found in the upper right portion of your abdomen. The medical term for enlarged liver is hepatomegaly.\n\n" +
            "Enlarged liver isn't a disease. It's a sign of an underlying problem, such as liver disease, congestive heart failure or cancer.\n\n" +
            "Treatment for enlarged liver involves identifying and controlling the underlying cause of the condition.\n\n\n";

    //Symptoms
        //causes

    String Liver_EnlargedLiver_causes_para1 = "Excessive alchohol use\n\n" +
            "Large doses of medicine\n\n" +
            "Herbal supplements\n\n" +
            "Infections\n\n" +
            "Poor eating habits\n\n\n";


    String Liver_EnlargedLiver_causes_para2 = "The liver is a large, football-shaped organ found in the upper right portion of your abdomen. The size of the liver varies with age, sex and body size. Many conditions can cause it to enlarge, including:\n\n\n" +
            "•\tCirrhosis\n\n" +
            "•\tHepatitis caused by a virus — including hepatitis A, B and C — or caused by infectious mononucleosis\n\n" +
            "•\tNonalcoholic fatty liver disease\n\n" +
            "•\tAlcoholic fatty liver disease\n\n" +
            "•\tA disorder that causes abnormal protein to accumulate in your liver (amyloidosis)\n\n" +
            "•\tA genetic disorder that causes copper to accumulate in your liver (Wilson's disease)\n\n" +
            "•\tA disorder that causes iron to accumulate in your liver (hemachromatosis)\n\n" +
            "•\tA disorder that causes fatty substances to accumulate in your liver (Gaucher's disease)\n\n" +
            "•\tFluid-filled pockets in the liver (liver cysts)\n\n" +
            "•\tNoncancerous liver tumors, including hemangioma and adenoma\n\n" +
            "•\tObstruction of the gallbladder or bile ducts\n\n" +
            "•\tToxic hepatitis\n\n\n";


        //symptoms

    String Liver_EnlargedLiver_symptoms_para1 = "An enlarged liver may not cause any symptoms.\n\n" +
            "When enlarged liver occurs because of liver disease, it may be accompanied by:\n\n" +
            "•\tAbdominal pain\n\n" +
            "•\tFatigue\n\n" +
            "•\tNausea and vomiting\n\n" +
            "•\tYellowing of the skin and the whites of the eyes (jaundice)\n\n\n";

    //Treatment
        //treatment

    String Liver_EnlargedLiver_treatment_para1 = "You're likely to start by seeing your primary care doctor. If your doctor suspects you have an enlarged liver, he or she might refer you to the appropriate specialist after testing to determine the cause.\n\n" +
            "If you have a liver disease, you might be referred to a specialist in liver problems (hepatologist).\n\n\n";


    //Home Remedies

    String Liver_EnlargedLiver_homeremedies_para1 = "Choose a healthy diet\n\n" +
            "Drink alchohol in moderations if at all\n\n" +
            "Limit contact  with chemicals\n\n" +
            "Quit smoking\n\n" +
            ".\tTurmeric. Turmeric can be extremely helpful to improve liver health\\n\n" +
            ".\tPapaya\\n\n" +
            ".\tApple Cider Vinegar\n\n" +
            ".\tIndian Gooseberry (Amla)\n \n" +
            ".\tSpinach and Carrot Juice\n\n" +
            ".\tApples and Leafy Vegetables\n\n" +
            ".\tDandelion Root Tea\n\n";




    //Liver Cancer>>>>>
        //About

    String Liver_LiverCancer_title = "LiverCancer\n";
    String Liver_LiverCancer_status = "Rare";
    //about

    String Liver_LiverCancer_about = "Fewer than 1 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n";
    String Liver_LiverCancer_desc = "Liver cancer is cancer that begins in the cells of your liver. Your liver is a football-sized organ that sits in the upper right portion of your abdomen, beneath your diaphragm and above your stomach.\n\n" +
            "The most common form of liver cancer is hepatocellular carcinoma, which begins in the main type of liver cell (hepatocyte). Other types of cells in the liver can develop cancer, but these are much less common.\n\n" +
            "Not all cancers that affect the liver are considered liver cancer. Cancer that begins in another area of the body — such as the colon, lung or breast — and then spreads to the liver is called metastatic cancer rather than liver cancer. And this type of cancer is named after the organ in which it began — such as metastatic colon cancer to describe cancer that begins in the colon and spreads to the liver.\n\n\n";


    //Symptoms
        //causes

    String Liver_LiverCancer_causes_para1 = "It's not clear what causes most cases of liver cancer. But in some cases, the cause is known. For instance, chronic infection with certain hepatitis viruses can cause liver cancer.\n\n" +
            "Liver cancer occurs when liver cells develop changes (mutations) in their DNA — the material that provides instructions for every chemical process in your body. DNA mutations cause changes in these instructions. One result is that cells may begin to grow out of control and eventually form a tumor — a mass of cancerous cells.\n\n\n";

    String Liver_LiverCancer_symptoms_para1 = "Most people don't have signs and symptoms in the early stages of primary liver cancer. When signs and symptoms do appear, they may include:\n\n\n" +
            "•\tLosing weight without trying\n\n" +
            "•\tLoss of appetite\n\n" +
            "•\tUpper abdominal pain\n\n" +
            "•\tNausea and vomiting\n\n" +
            "•\tGeneral weakness and fatigue\n\n" +
            "•\tAbdominal swelling\n\n" +
            "•\tYellow discoloration of your skin and the whites of your eyes (jaundice)\n\n" +
            "•\tWhite, chalky stools\n\n\n";

    //Treatment
        //treatment

    String Liver_LiverCancer_treatment_para1 = "•\tBlood tests. Blood tests may reveal liver function abnormalities.\n" +
            "•\tImaging tests. Your doctor may recommend imaging tests, such as an ultrasound, computerized tomography (CT) scan and magnetic resonance imaging (MRI).\n\n" +
            "•\tRemoving a sample of liver tissue for testing.During a liver biopsy, a sample of tissue is removed from your liver and examined under a microscope. Your doctor may insert a thin needle through your skin and into your liver to obtain a tissue sample. Liver biopsy carries a risk of bleeding, bruising and infection.\n\n\n";


    //Home Remedies
        //home remedies

    String Liver_LiverCancer_homeremedies_para1 = "Drink alcohol in moderation, if at all. \n\n" +
            "•\t Maintain a healthy weight. \n\n" +
            "•\t Use caution with chemicals.\n\n" +
            "•\tKnow the health status of any sexual partner.\n\n" +
            "•\tDon't use intravenous (IV) drugs, but if you do, use a clean needle.\n\n" +
            "•\tSeek safe, clean shops when getting a piercing or tattoo\n\n\n";

        //alternative medicine

    String Liver_LiverCancer_alternative_para1 = "Alternative treatments may help control pain in people with advanced liver cancer. Your doctor will work to control pain with treatments and medications. But sometimes your pain may persist or you may want to avoid the side effects of pain medications.\n\n" +
            "Ask your doctor about alternative treatments that may help you cope with pain, such as:\n\n\n" +
            "•\tAcupressure\n\n" +
            "•\tAcupuncture\n\n" +
            "•\tDeep breathing\n\n" +
            "•\tListening to music (music therapy)\n\n" +
            "•\tMassage\n\n\n";



















}
