public interface MEDICINES_PRATIK {

//MEDICINES
    //INFO

    String MEDICINE_Combiflam_title = "Combiflam Tablet\n";
    String MEDICINE_Combiflam_desc = "Combiflam (325/400 mg) Tablet is a combination medicine used to relieve pain associated with menstrual cycles and arthritis. It is used to relieve mild to moderate pain associated with a headache, toothache, muscle pain, or back pain. It is also used to temporarily relieve fever. This medicine should be used with caution due to the increased risk of liver damage and bleeding complications.\n" +
            "\nCombiflam (325/400 mg) Tablet is a combination medicine used to relieve pain associated with menstrual cycles and arthritis. It is used to relieve mild to moderate pain associated with a headache, toothache, muscle pain, or back pain. It is also used to temporarily relieve fever. This medicine should be used with caution due to the increased risk of liver damage and bleeding complications.\n\n\n" ;

    String MEDICINE_Combiflam_uses = "Crocin Advance can be used for treatment of mild-to-moderate pain including:\n\n" +
            "Muscle ache (like generalized body pain, back pain, neck pain, shoulder pain etc.)\n\n" +
            "Musculoskeletal pain\n\n" +
            "Joint Pain\n\n" +
            "Toothache\n\n";
    String MEDICINE_Combiflam_dosage = "Age:\n\n\n" +
            "\n" +
            "Adults & children over 12 years\n\n" +
            "\n" +
            "Tablet:\n\n\n" +
            "1 to 2 tablets\n\n" +
            "\n" +
            "Time to be taken:\n\n\n" +
            "\n" +
            "Every 4-6 hours. Minimum dosing interval 4 hours. Maximum dose in 24 hours not to exceed 4g/day in equally divided doses.\n\n";









}
