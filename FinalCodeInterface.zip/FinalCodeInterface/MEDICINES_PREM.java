public interface MEDICINES_PREM {

    //MEDICINES
        //INFO

    String MEDICINE_Crocin_title = "Crocin Advance\n";
    String MEDICINE_Crocin_desc = "Do not exceed stated dose. Do not take more than three days without medical advice.   Not recommended in children under 12 years of age. Patient Advice: Seek medical advice if symptoms persist or patient is suffering from liver / kidney impairment. Overdose may be injurious to liver. \n\n";

    String MEDICINE_Crocin_uses = "Crocin Advance can be used for treatment of mild-to-moderate pain including:\n\n" +
            "Muscle ache (like generalized body pain, back pain, neck pain, shoulder pain etc.)\n\n" +
            "Musculoskeletal pain\n\n" +
            "Joint Pain\n\n" +
            "Toothache\n\n";
    String MEDICINE_Crocin_dosage = "Age:\n\n\n" +
            "\n" +
            "Adults & children over 12 years\n\n" +
            "\n" +
            "Tablet:\n\n\n" +
            "1 to 2 tablets\n\n" +
            "\n" +
            "Time to be taken:\n\n\n" +
            "\n" +
            "Every 4-6 hours. Minimum dosing interval 4 hours. Maximum dose in 24 hours not to exceed 4g/day in equally divided doses.\n\n";


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    String MEDICINE_Cyclopam_title = "Cyclopam\n";
    String MEDICINE_Cyclopam_desc = "Dicyclomine is used to treat a certain type of intestinal problem called irritable bowel syndrome.\n\n" +
            "\n" +
            " It helps to reduce the symptoms of stomach and intestinal cramping.\n\n" +
            "\n" +
            " This medication works by slowing the natural movements of the gut and by relaxing the muscles in the stomach and intestines.\n\n";
    String MEDICINE_Cyclopam_use = "Headache\n\n" +
            "Toothache\n\n" +
            "Fever \n\n" +
            "Cold \n\n" +
            "Pain in abdomen\n\n" +
            "Joint pain\n\n" +
            "Intestinal cramps\n\n" +
            "\n";
    String MEDICINE_Cyclopam_dosage = "The usual dosage prescribed is up to 80 mg in total for a day, which should be taken in 4 parts.\n\n" +
            "The Cyclopam should be consumed 1 hour before meal.\n\n" +
            "\n" +
            "Dosage may vary:\n\n\n" +
            "The dose of Cyclopam taken should be strictly on the basis of prescription given by a doctor.\n\n" +
            "The dose of Cyclopam may vary from person to person as it entirely depends on the severity of the  condition, age of the person, sex, any ongoing drugs and medical history of the person.\n\n" +
            "\n" +
            "\n" +
            "\n";
    String MEDICINE_Cyclopam_sideeffects = "Dizziness, drowsiness, lightheadedness, weakness, blurred vision, dry eyes, dry mouth, nausea, constipation, and abdominal bloating may occur. If any of these effects persist or worsen, tell your doctor or pharmacist promptly.\n\n";
    String MEDICINE_Cyclopam_precautions = "Before taking dicyclomine, tell your doctor or pharmacist if you are allergic to it; or if you have any other allergies. This product may contain inactive ingredients, which can cause allergic reactions or other problems. Talk to your pharmacist for more details.\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    String MEDICINE_Unienzyme_title = "Unienzyme\n";
    String MEDICINE_Unienzyme_desc = "Unienzyme Tablet is used for Digestion, Intestinal gas, Hangover, Flatulence, Lower cholesterol levels, Stomach gas, Sore throat and throat swelling, Bile flow problems during pregnancy, Herpes zoster, Poisoningand other conditions.\n";
    String MEDICINE_Unienzyme_use = "Digestion\n\n" +
            "Intestinal gas\n\n" +
            "Hangover \n\n" +
            "Flatulence\n\n" +
            "Lower cholesterol levels\n\n" +
            "Stomach gas\n\n" +
            "Sore throat and throat swelling\n\n" +
            "Bile flow problems during pregnancy\n\n" +
            "Poisoning\n\n";
    String MEDICINE_Unienzyme_sideeffects = "Constipation\n\n" +
            "Black stools\n\n" +
            "Abdominal pain\n\n" +
            "Painful urination\n\n" +
            "Black faeces \n\n" +
            "Mild skin irritation\n \n" +
            "Diarrhea\n\n" +
            "Diadrrhea\n\n" +
            "Abdominal distress\n\n" +
            "Temporary burning sensation\n\n";
    String MEDICINE_Unienzymes_precautions = "Dosage is based on your condition. Tell your doctor if your condition persists or worsens. Important counseling points are listed below. \n\n" +
            "Bleeding disorders\n\n" +
            "Pregnant, planning to get pregnant or breastfeeding\n\n" +
            "Surgery\n\n" +
            "\n";


}
