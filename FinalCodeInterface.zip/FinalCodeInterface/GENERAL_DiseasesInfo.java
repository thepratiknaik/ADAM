public interface GENERAL_DiseasesInfo {

    // SpiderBites>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Spiderbites_title = "Spider bites";
    String GENERAL_Spiderbite_status = "Very common";
    String GENERAL_Spiderbite_about = "More than 10 million cases per year (India) \n\n" +
            "Usually self-treatable\n" +
            "Usually self-diagnosable\n" +
            "Lab tests or imaging not required\n" +
            "Short-term: resolves within days to weeks\n";
    String GENERAL_Spiderbite_desc = "Spider bites are usually harmless. In fact, many bites attributed to spiders turn out to have been inflicted by other bugs. Skin infections also have been mistaken for spider bites.\n\n" +
            "Only a few types of spiders have fangs long enough to penetrate human skin and venom strong enough to severely affect a human being. In the U.S., these include the black widow spider and the brown recluse spider.\n\n";
    String GENERAL_Spiderbite_card_desc = "Spider bites are usually harmless. In fact, many bites attributed to spiders turn out to have been inflicted by other bugs. Skin infections also have been mistaken for spider bites.";

    //SYMPTOMS
    String GENERAL_Spiderbite_cause_para1 = "Severe spider bite symptoms occur as a result of injected spider venom. The severity of symptoms depends on the type of spider, the amount of venom injected and how sensitive your body is to the venom\n";
    String GENERAL_Spiderbite_symptoms_para1 = "Typically, a spider bite looks like any other bug bite — a red, inflamed, sometimes itchy or painful bump on your skin — and may even go unnoticed. Harmless spider bites usually don't produce other symptoms.\n" +
            "•\tBlack widow spider bites \n\n" +
            "Signs and symptoms of a black widow spider bite may include:\n\n\n" +
            "•\tPain. Typically beginning within an hour of being bitten, pain can spread from the bite site into your abdomen, back or chest.\n\n" +
            "•\tCramping. Abdominal cramping or rigidity can be so severe that it's sometimes mistaken for appendicitis or a ruptured appendix.\n\n" +
            "•\tSweating. Excessive sweating can occur around the bite mark or may involve the entire limb.\n\n";

    String GENERAL_Spiderbite_symptoms_para2 = "•\tBrown recluse spider bite\n\n" +
            "The pain associated with a brown recluse spider bite typically increases during the first eight hours after the bite. The bite usually heals on its own in about a week. In a minority of cases, the skin at the center of the bite can become dusky red and then evolve into a deep open sore (ulcer) that enlarges as the surrounding skin dies. The ulcer usually stops growing within 10 days after the bite, but full healing can take months.\n";

    //TREATMENT
    String GENERAL_Spiderbite_treatment_para1 = "For most people with spider bites, including black widow and brown recluse spider bites, the following treatment measures are all that's required:\n\n\n" +
            "•\tClean the bite with mild soap and water.\n" +
            "•\tApply cold packs to the bite, to reduce pain and inflammation.\n" +
            "•\tIf the bite is on an extremity such as an arm or leg, keep it elevated.\n" +
            "•\tTake over-the-counter pain relievers as needed.\n" +
            "•\tObserve the bite for signs of infection.\n\n" +
            "Your doctor may also recommend a tetanus booster shot if you haven't had one in the last five years. Antibiotics may be prescribed if the bite becomes infected.\n\n" +
            "•\tBlack widow anti-venom\n\n\n" +
            "If a black widow bite is causing intractable pain or life-threatening symptoms, your doctor may recommend an anti-venom, which may be injected into a thigh muscle or given through a vein (intravenously). Anti-venom can cause serious allergic reactions, so it must be used with caution.\n";
    String GENERAL_Spiderbite_homeremedies_para1 = "Spiders in general, including the black widow and brown recluse, bite only in defense, when being crushed between your skin and another object.\n\n" +
            "To prevent spider bites:\n\n" +
            "•\tWear a long-sleeve shirt, hat, gloves and boots when handling stored boxes or firewood, and when cleaning out sheds, garages, basements, attics and crawl spaces.\n" +
            "•\tInspect and shake out gardening gloves, boots and clothing that have been unused for a while.\n" +
            "•\tUse insect repellents, such as DEET or Picaridin, on clothing and footwear.\n";



    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Beesting_title = "";
    String GENERAL_Beesting_status = "";
    String GENERAL_Beesting_about = "";
    String GENERAL_Beesting_desc = "";
    String GENERAL_Beesting_card_desc = "";

    //SYMPTOMS
    String GENERAL_Beesting_cause_para1 = "";
    String GENERAL_Beesting_symptoms_para1 = "";
    String GENERAL_Beesting_symptoms_para2 = "";


    //TREATMENT
    String GENERAL_Beesting_treatment_para1 = "";
    String GENERAL_Beesting_treatment_para2 = "";
    String GENERAL_Beesting_homeremedies_para1 = "";


    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Rabies_title = "";
    String GENERAL_Rabies_status = "";
    String GENERAL_Rabies_about = "";
    String GENERAL_Rabies_desc = "";
    String GENERAL_Rabies_card_desc = "";

    //SYMPTOMS
    String GENERAL_Rabies_cause_para1 = "";
    String GENERAL_Rabies_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_Rabies_treatment_para1 = "";
    String GENERAL_Rabies_homeremedies_para1 = "";



    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Fever_title = "";
    String GENERAL_Fever_status = "";
    String GENERAL_Fever_desc = "";
    String GENERAL_Fever_card_desc = "";


    //SYMPTOMS
    String GENERAL_Fever_causes_para1 = "";
    String GENERAL_Fever_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_Fever_treatment_para1 = "";



    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Jaundice_title = "";
    String GENERAL_Jaundice_status = "";
    String GENERAL_Jaundice_desc = "";
    String GENERAL_Jaundice_card_desc = "";


    //SYMPTOMS
    String GENERAL_Jaundice_causes_para1 = "";
    String GENERAL_Jaundice_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_Jaundice_treatment_para1 = "";


    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_ChickenPox_title = "";
    String GENERAL_ChickenPox_status = "";
    String GENERAL_ChickenPox_desc = "";
    String GENERAL_ChickenPox_card_desc = "";


    //SYMPTOMS
    String GENERAL_ChickenPox_causes_para1 = "";
    String GENERAL_Chicken_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_ChickenPox_treatment_para1 = "";




    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_DengueFever_title = "";
    String GENERAL_DengueFever_status = "";
    String GENERAL_DengueFever_about = "";
    String GENERAL_DengueFever_desc = "";
    String GENERAL_DengueFever_card_desc = "";

    //SYMPTOMS
    String GENERAL_DengueFever_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_DengueFever_treatment_para1 = "";
    String GENERAL_DengueFever_prevention_para1 = "";



    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Malaria_title = "";
    String GENERAL_Malaria_status = "";
    String GENERAL_Malaria_about = "";
    String GENERAL_Malaria_desc = "";
    String GENERAL_Malaria_card_desc = "";

    //SYMPTOMS
    String GENERAL_Malaria_causes_para1 = "";
    String GENERAL_Malaria_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_Malaria_treatment_para1 = "";
    String GENERAL_Malaria_prevention_para1 = "";


    // >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String GENERAL_Typhoid_title = "";
    String GENERAL_Typhoid_status = "";
    String GENERAL_Typhoid_about = "";
    String GENERAL_Typhoid_desc = "";
    String GENERAL_Typhoid_card_desc = "";

    //SYMPTOMS
    String GENERAL_Typhoid_causes_para1 = "";
    String GENERAL_Typhoid_symptoms_para1 = "";


    //TREATMENT
    String GENERAL_Typhoid_treatment_para1 = "";




}
