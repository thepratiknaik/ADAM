public interface UPPERBACK_Diseases {

    //ARTHRITIS
    //ABOUT

    //about

    String UPPERBACK_Arthritis_title = "Arthritis\n";
    String UPPERBACK_Athritis_status = "Very common\n";
    String UPPERBACK_Arthritis_about = "More than 10 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String UPPERBACK_Arthritis_desc = "Arthritis is an inflammation of the joints. It can affect one joint or multiple joints. There are more than 100 different types of arthritis, with different causes and treatment methods. Two of the most common types are osteoarthritis (OA) and rheumatoid arthritis (RA).\n\n";
    String UPPERBACK_Arthritis_card_desc = "Arthritis is an inflammation of the joints. It can affect one joint or multiple joints.\n\n";

    //Symptoms

    String UPPERBACK_Arthritis_causes_para1 = "Cartilage is a firm but flexible connective tissue in your joints. It protects the joints by absorbing the pressure and shock created when you move and put stress on them. A reduction in the normal amount of this cartilage tissue cause some forms of arthritis.\n\n" +
            "Normal wear and tear causes OA, one of the most common forms of arthritis. An infection or injury to the joints can exacerbate this natural breakdown of cartilage tissue. Your risk of developing OA may be higher if you have a family history of the disease.\n\n" +
            "Another common form of arthritis, RA, is an autoimmune disorder. It occurs when your body’s immune system attacks the tissues of the body. These attacks affect the synovium, a soft tissue in your joints that produces a fluid that nourishes the cartilage and lubricates the joints.\n\n" +
            "RA is a disease of the synovium that will invade and destroy a joint. It can eventually lead to the destruction of both bone and cartilage inside the joint.\n\n" +
            "The exact cause of the immune system’s attacks is unknown. But scientists have discovered genetic markers that increase your risk of developing RA fivefold.\n\n";
    String UPPERBACK_Arthritis_symptoms_para1 = "Joint pain, stiffness and swelling are the most common symptoms of arthritis. Your range of motion may also decrease, and you may experience redness of the skin around the joint. Many people with arthritis notice their symptoms are worse in the morning.\n\n" +
            "\n" +
            "In the case of RA, you may feel tired or experience a loss of appetite due to the inflammation the immune system’s activity causes. You may also become anemic — meaning your red blood cell count decreases — or have a slight fever. Severe RA can cause joint deformity if left untreated.\n\n";

    //Treatment

    String UPPERBACK_Arthritias_treatment_para1 = "The main goal of treatment is to reduce the amount of pain you’re experiencing and prevent additional damage to the joints. You’ll learn what works best for you in terms of controlling pain. Some people find heating pads and ice packs to be soothing. Others use mobility assistance devices, like canes or walkers, to help take pressure off sore joints.\n\n" +
            "Improving your joint function is also important. Your doctor may prescribe you a combination of treatment methods to achieve the best results.\n\n";
    String UPPERBACK_Arthritis_homeremedies_para1 = "At-home exercises you can try include:\n\n\n" +
            "•\tthe head tilt, neck rotation, and other exercises to relieve pain in your neck\n\n" +
            "•\tfinger bends and thumb bends to ease pain in your hands\n\n" +
            "•\tleg raises, hamstring stretches, and other easy exercises for knee arthritis\n\n";
    String UPPERBACK_Arthritis_medication_para1 = "A number of different types of medication treat arthritis:\n\n\n" +
            "•\tAnalgesics, such as hydrocodone (Vicodin) or acetaminophen (Tylenol), are effective for pain management, but don’t help decrease inflammation.\n\n" +
            "•\tNonsteroidal anti-inflammatory drugs (NSAIDs), such as ibuprofen (Advil) and salicylates, help control pain and inflammation. Salicylates can thin the blood, so they should be used very cautiously with additional blood thinning medications.\n\n" +
            "•\tMenthol or capsaicin creams block the transmission of pain signals from your joints.\n\n" +
            "•\tImmunosuppressants like prednisone or cortisone help reduce inflammation.\n\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about

    String UPPERBACK_HerniatedDisc_title = "Herniated Disc\n";
    String UPPERBACK_HerniatedDisc_status = "Very common\n";
    String UPPERBACK_HerniatedDisc_about = "More than 10 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n";
    String UPPERBACK_HerniatedDisc_desc = "A herniated disc occurs when the fibrous outer portion of the disc ruptures or tears, and the jelly-like core squeezes out. When the herniated disc compresses a nearby nerve, as in the image below, the result can be a pinched nerve. A pinched nerve may cause pain, numbness, tingling or weakness in the arms or legs. The substance that makes up the disc’s jelly-like core can also inflame and irritate the nerve, causing additional pain.\n\n";
    String UPPERBACK_HerniatedDisc_card_desc = "A herniated disc occurs when the fibrous outer portion of the disc ruptures or tears, and the jelly-like core squeezes out.\n\n";

    //Symptoms

    String UPPERBACK_HerniatedDisc_causes_para1 = "Herniated discs can often be the result of degenerative disc disease. As people age, the intervertebral discs lose their water content and ability to cushion the vertebrae. As a result, the discs are not as flexible. Furthermore, the fibrous outer portion of the disc is more likely to rupture or tear.\n\n" +
            "Acute disc herniations can occur in young, healthy people as a result of an injury or tear to the outer layer of the disc (called the annulus fibrosis) that allows the central, jelly-like portion of the disc (called the nucleus pulposis) to herniate into the spinal canal or foramen.\n\n";
    String UPPERBACK_HerniatedDisc_symptoms_para1 = "•\tMuscle weakness in the legs\n\n" +
            "•\tNumbness in the leg or foot\n\n" +
            "•\tDecreased reflexes at the knee or ankle\n\n" +
            "•\tChanges in bladder or bowel function\n\n" +
            "•\tDifficulty walking\n\n" +
            "•\tIncoordination\n\n";

    //Treatment

    String UPPERBACK_HerniatedDisc_treatment_para1 = "Before discussing surgery as an option, the surgeon may initiate the following nonoperative treatments:\n\n\n" +
            "•\tActivity modification\n\n" +
            "•\tPatient education on proper body mechanics (to help decrease the chance of worsening pain or damage to the disc)\n\n" +
            "•\tPhysical therapy, which may include ultrasound, massage, conditioning, and exercise programs\n\n" +
            "•\tWeight control\n\n" +
            "•\tMedications (to reduce inflammation, control pain and/or relax muscles)\n\n";
    String UPPERBACK_HerniatedDisc_surgery_desc = "Surgical treatment for a herniated disc will be based on the following:\n\n\n" +
            "•\tThe history, severity and duration of pain\n\n" +
            "•\tWhether or not the patient has received previous treatments for disc disorders and how effective the treatments were\n\n" +
            "•\tWhether or not there is any evidence of neurologic damage such as sensory loss, weakness, impaired coordination, or bowel or bladder problems\n\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about

    String UPPERBACK_Spondylosis_title = "Spondylosis\n";
    String UPPERBACK_Spondylosis_status = "Very common\n";
    String UPPERBACK_Spondylosis_about = "More than 10 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Chronic: can last for years or be lifelong\\\n";
    String UPPERBACK_Spondylosis_desc = "Spondylosis is common and worsens with age. This condition is often used to describe degenerative arthritis (osteoarthritis) of the spine.\n\n" +
            "\n" +
            "Most people don't have symptoms, but some may experience pain or muscle spasms.\n\n" +
            "\n" +
            "In many cases, no specific treatment is required. If symptoms occur, treatments include medication, corticosteroid injections, physiotherapy and sometimes surgery.\n\n" +
            "\n";
    String UPPERBACK_Spondylosis_card_desc = "The bones and protective cartilage in your neck are prone to wear and tear that can lead to cervical spondylosis. Possible causes of the condition include:\n\n\n" +
            "Bone spurs\n\n\n" +
            "These overgrowths of bone are the result of the body trying to grow extra bone to make the spine stronger.\n\n" +
            "However, the extra bone can press on delicate areas of the spine, such as the spinal cord and nerves, resulting in pain.\n\n";

    //Symptoms

    String UPPERBACK_Spondylosis_causes_para1 = "The bones and protective cartilage in your neck are prone to wear and tear that can lead to cervical spondylosis. Possible causes of the condition include:\n\n\n" +
            "Bone spurs\n\n\n" +
            "";
    String UPPERBACK_Spondylosis_causes_para2 = "These overgrowths of bone are the result of the body trying to grow extra bone to make the spine stronger.\n\n"+
            "However, the extra bone can press on delicate areas of the spine, such as the spinal cord and nerves, resulting in pain.\n\n";
    String UPPERBACK_Spondylosis_symptoms_para1 = "One common symptom is pain around the shoulder blade. Some complain of pain along the arm and in the fingers. The pain might increase when:\n\n\n" +
            "•\tStanding\n\n" +
            "•\tSitting\n\n" +
            "•\tsneezing\n\n" +
            "•\tcoughing\n\n" +
            "•\ttilting your neck backward\n\n" +
            "Another common symptom is muscle weakness. Muscle weakness makes it hard to lift the arms or grasp objects firmly.\n\n" +
            "Other common signs include:\n\n" +
            "•\ta stiff neck that becomes worse\n\n" +
            "•\theadaches that mostly occur in the back of the head\n\n" +
            "•\ttingling or numbness that mainly affects the shoulders and arms, although it can also occur in the legs\n\n";

    //Treatment

    String UPPERBACK_Spondylosis_treatment_para1 = "Treatments for cervical spondylosis focus on providing pain relief, lowering the risk of permanent damage, and helping you lead a normal life.\n\n" +
            "Nonsurgical methods are usually very effective.\n\n" +
            "You might also have neck traction. This involves using weights to increase the space between the cervical joints and relieve the pressure on the cervical discs and nerve roots.\n\n";
    String UPPERBACK_Spondylosis_homeremedies_para1 = "If your condition is mild, you can try a few things at home to treat it:\n\n\n" +
            "•\tTake an OTC pain reliever, such as acetaminophen (Tylenol) or an NSAID, which includes ibuprofen (Advil) and naproxen sodium (Aleve).\n\n" +
            "•\tUse a heating pad or a cold pack on your neck to provide pain relief for sore muscles.\n\n" +
            "•\tExercise regularly to help you recover faster.\n\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



}
