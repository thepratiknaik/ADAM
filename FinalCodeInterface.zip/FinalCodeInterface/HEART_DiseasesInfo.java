public interface HEART_DiseasesInfo {
    // Arrhythmia >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String HEART_Arrhythmia_title = "Arrhythhmia\n";
    String HEART_Arrhythmia_status = "Very common\n";
    String HEART_Arrhythmia_about = "More than 10 million cases per year (India)\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Treatable by a medical professional\n\n" +
            "\n";
    String HEART_Arrhythmia_desc = "An irregular heartbeat is an arrhythmia (also called dysrhythmia). Heart rates can also be irregular. A normal heart rate is 50 to 100 beats per minute. Arrhythmias and abnormal heart rates don't necessarily occur together. Arrhythmias can occur with a normal heart rate, or with heart rates that are slow (called bradyarrhythmias -- less than 50 beats per minute).\n" +
            "\n";
    String HEART_Arrhythmia_card_desc = "An irregular heartbeat is an arrhythmia (also called dysrhythmia).\n";


    //SYMPTOMS
    String HEART_Arrhythmia_causes_para1 = "Arrhythmias may be caused by many different factors, including:\n\n\n" +
            "Coronary artery disease.\n\n" +
            "Electrolyte imbalances in your blood (such as sodium or potassium).\n\n" +
            "Changes in your heart muscle.\n\n" +
            "Injury from a heart attack.\n\n" +
            "Healing process after heart surgery.\n\n" +
            "Irregular heart rhythms can also occur in normal, healthy hearts.\n\n";
    String HEART_Arrhythmia_symptoms_para1 = "When symptoms of an arrhythmia occur, they may include:\n\n\n" +
            "Palpitations (a feeling of skipped heart beats, fluttering or flip-flops, or feeling that your heart is running away).\n\n" +
            "Pounding in your chest.\n\n" +
            "Dizziness or feeling light-headed.\n\n" +
            "Fainting.\n\n" +
            "Shortness of breath.\n\n" +
            "Chest discomfort.\n\n" +
            "Weakness or fatigue (feeling very tired).\n\n";

    //Treatment

    String HEART_Arrhythmia_treatment_para1 = "Tests used to diagnose an arrhythmia or determine its cause include:\n\n\n" +
            "\n" +
            "1.Electrocardiogram\n\n" +
            "2.Holter monitor\n\n" +
            "3.Event monitor\n\n" +
            "4.Stress test\n\n" +
            "5.Echocardiogram\n\n" +
            "6.Cardiac catheterization\n\n" +
            "7.Electrophysiology study (EPS)\n\n" +
            "8.Head-up tilt table test\n\n" +
            "\n";


    //  Heart Attack >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String HEART_Attack_title = "Heart Attack\n";
    String HEART_Attack_status = "Very common\n";
    String HEART_Attack_about = "More than 10 million cases per year (India)\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Treatable by a medical professional\n\n" +
            "Short-term: resolves within days to weeks\n\n";
    String HEART_Attack_desc = "A heart attack is a medical emergency. A heart attack usually occurs when a blood clot blocks blood flow to the heart. Without blood, tissue loses oxygen and dies.\n\n";
    String HEART_Attack_card_desc = "A heart attack is a medical emergency. A heart attack usually occurs when a blood clot blocks blood flow to the heart.\n\n";


    //SYMPTOMS

    String HEART_Attack_causes_para1 = "Over time, cholesterol and a fatty material called plaque can build up on the walls inside blood vessels that take blood to your heart, called arteries. This makes it harder for blood to flow freely. Most heart attacks happen when a piece of this plaque breaks off. A blood clot forms around the broken-off plaque, and it blocks the artery.\n";
    String HEART_Attack_symptoms_para1 = "Tightness or pain in the chest, neck, back or arms\n\n" +
            "2.Fatigue\n\n" +
            "3.Lightheadedness\n\n" +
            "4.Abnormal heartbeat\n\n" +
            "5.Anxiety.\n\n" +
            "6.Women are more likely to have atypical symptoms than men.\n\n";

    //TREATMENT

    String HEART_Attack_treatment_para1 = "Electrocardiogram. An electrocardiogram (ECG) is a recording of the electrical activity of the heart. Abnormalities in the electrical activity usually occur with heart attacks and can identify the areas of heart muscle that are deprived of oxygen and/or areas of muscle that have died. In a patient with typical symptoms of heart attack (such as crushing chest pain) and characteristic changes of heart attack on the ECG, a secure diagnosis of heart attack can be made quickly in the emergency room and treatment can be started immediately.\n\n" +
            "Blood tests. Cardiac enzymes are proteins that are released into the blood by dying heart muscles. These cardiac enzymes are creatine phosphokinase (CPK), special sub-fractions of CPK (specifically, the MB fraction of CPK), and troponin, and their levels can be measured in blood. \n\n";

    String HEART_Attack_homeremedies_para1 = "Chew and swallow an aspirin, unless you are allergic to aspirin or have been told by your doctor never to take aspirin. But seek emergency help first, such as calling 102.\n\n" +
            "Take nitroglycerin, if prescribed. If you think you're having a heart attack and your doctor has previously prescribed nitroglycerin for you, take it as directed. Do not take anyone else's nitroglycerin, because that could put you in more danger.\n\n" +
            "Begin CPR if the person is unconscious. If you're with a person who might be having a heart attack and he or she is unconscious, tell the 911 dispatcher or another emergency medical specialist. \n\n";


    // Cardiomegaly >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String HEART_Cardiomegaly_title = "Cardiomegaly\n";
    String HEART_Cardiomegaly_status = "Common\n";
    String HEART_Cardiomegaly_about = "More than 1 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Chronic: can last for years or be lifelong\n\n" +
            "\n";
    String HEART_Cardiomegaly_desc = "Cardiomegaly is usually a sign of another condition such as a heart valve problem or heart disease. It may also signal a prior heart attack. It can also occur from bodily stress caused by pregnancy or certain infections.\n" +
            "\n\n";
    String HEART_Cardiomegaly_card_desc = "Cardiomegaly is usually a sign of another condition such as a heart valve problem or heart disease.\n\n";
    //SYMPTOMS
    String HEART_Cardiomegaly_causes_para1 = "The most common trigger is blockages that affect the heart's blood supply (coronary artery disease) and high blood pressure. There can be other causes, including:\n\n\n" +
            "Viral infection of the heart\n\n" +
            "Abnormal heart valve\n\n" +
            "Pregnancy, with the heart enlarging around the time of delivery (your doctor may call this peripartum cardiomyopathy)\n\n" +
            "Kidney disease that needs dialysis\n\n" +
            "Alcohol or cocaine abuse\n\n" +
            "HIV infection\n\n" +
            "Genetic and inherited conditions\n\n";
    String HEART_Cardiomegaly_symptoms_para1 = "Most often, an enlarged heart causes no symptoms. If it becomes unable to pump blood well enough, you may get symptoms of congestive heart failure, such as:\n\n\n" +
            "Shortness of breath (especially when active or when lying flat)\n\n" +
            "Leg swelling\n\n" +
            "Weight gain, particularly in your midsection\n\n" +
            "Tired feeling\n\n" +
            "Palpitations or skipped heartbeats\n\n";


    //TREATMENT
    String HEART_Cardiomegaly_treatment_para1 = "Though mild cardiomegaly will often resolve itself, treatment options include:\n\n\n" +
            "Medical devices\\n\\n\n" +
            "If medications do not effectively treat mild cardiomegaly, or if symptoms become moderate or severe, it may be necessary for someone to be fitted with a medical device.\n\n" +
            "A pacemaker may be fitted to regulate heartbeat in those with dilative cardiomyopathy. People with severe arrhythmias may require an implantable cardioverter-defibrillator (ICD) to deliver shocks to control the heart rhythm.\n\n";
    String HEART_Cardiomegaly_medication_para1= "Recommended medications depend on the condition that is causing the enlarged heart. Medication may be prescribed to treat abnormal heart rhythms and high blood pressure. Diuretics may be prescribed to lower pressure in the arteries, while anticoagulants can reduce the risk of blood clots.\n\n" +
            "Other underlying conditions, such as anemia or thyroid disorders, can also be treated with medication.\n\n";
    String HEART_Cardiomegaly_surgery_desc = "Surgery is usually reserved for more severe cases of cardiomegaly, or for those that do not respond to other treatments. Depending on several factors, the following surgeries may be recommended for people with cardiomegaly:\n\n\n" +
            "heart valve surgery\n\n" +
            "coronary bypass surgery\n\n" +
            "heart transplant\n\n";
    String HEART_Cardiomegaly_homeremedies_para1 = "stopping smoking\n\n" +
            "maintaining a healthy weight\n\n" +
            "monitoring blood pressure regularly\n\n" +
            "doing physical activity most days of the week\n\n" +
            "limiting alcohol and caffeine\n\n" +
            "sleeping 7 to 9 hours a night\n\n" +
            "increasing fruit and vegetable intake\n\n" +
            "replacing refined grains, such as white bread and pasta, with whole grain versions\n\n" +
            "cutting out processed, high-sugar, and high-fat foods\n\n";

    // CongestiveHeartFailure >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    //ABOUT
    String HEART_Failure_title = "Congestive heart failure\n";
    String HEART_Failure_status = "Common\n";
    String HEART_Failure_about = "More than 1 million cases per year (India)\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String HEART_Failure_desc = "Heart failure does not mean the heart has stopped working. Rather, it means that the heart works less efficiently than normal. Due to various possible causes, bloodmoves through the heart and body at a slower rate, and pressure in the heart increases.\n\n";
    String HEART_Failure_card_desc = "Heart failure does not mean the heart has stopped working. Rather, it means that the heart works less efficiently than normal.\n\n";
    //SYMPTOMS
    String HEART_Failure_causes_para1 = "Heart failure is caused by many conditions that damage the heart muscle, including:\n\n" +
            "\n" +
            "\n" +
            "Coronary artery disease. Coronary artery disease (CAD), a disease of the arteries that supply blood and oxygen to the heart, causes decreased blood flow to the heart muscle. If the arteries become blocked or severely narrowed, the heart becomes starved for oxygen and nutrients.\n\n" +
            "\n" +
            "\n" +
            "Heart attack. A heart attack occurs when a coronary artery becomes suddenly blocked, stopping the flow of blood to the heart muscle. A heart attack damages the heart muscle, resulting in a scarred area that does not function properly.\n\n" +
            "\n" +
            "\n" +
            "Cardiomyopathy. Damage to the heart muscle from causes other than artery or blood flow problems, such as from infections or alcohol or drug abuse.\n\n";
    String HEART_Failure_symptoms_para1 = "The symptoms can include:\n\n\n" +
            "Congested lungs. Fluid backup in the lungs can cause shortness of breath with exercise or difficulty breathing at rest or when lying flat in bed. Lung congestion can also cause a dry, hacking cough or wheezing.\n\n" +
            "Fluid and water retention.Less blood to your kidneyscauses fluid and water retention, resulting in swollen ankles, legs, abdomen (called edema), and weight gain. Symptoms may cause an increased need to urinate during the night. Bloating in your stomach may cause a loss of appetite or nausea.\n\n" +
            "Dizziness, fatigue, and weakness. Less blood to your major organs and muscles makes you feel tired and weak. Less blood to the brain can cause dizziness or confusion.\n\n" +
            "Rapid or irregular heartbeats. The heart beats faster to pump enough blood to the body. This can cause a rapid or irregular heartbeat\n\n";


    //TREATMENT
    String HEART_Failure_treatment_para1 = "There are more treatment options available for heart failure than ever before. Tight control over your medications and lifestyle, coupled with careful monitoring, are the first steps. As the condition progresses, doctors specializing in the treatment of heart failure can offer more advanced treatment options.\n\n" +
            "The goals of treating heart failure are primarily to decrease the likelihood of disease progression (thereby decreasing the risk of death and the need for hospitalization), to lessen symptoms, and to improve quality of life.\n\n" +
            "Together, you and your doctor can determine the best course of treatment for you.\n\n";

    String HEART_Failure_homeremedies_para1 = "Stop smoking. Smoking damages your blood vessels, raises blood pressure, reduces the amount of oxygen in your blood and makes your heart beat faster.\n\n" +
            "Discuss weight monitoring with your doctor. Discuss with your doctor how often you should weigh yourself. Ask your doctor how much weight gain you should notify him or her about. Weight gain may mean that you're retaining fluids and need a change in your treatment plan.\n\n" +
            "Check your legs, ankles and feet for swelling daily. Check for any changes in swelling in your legs, ankles or feet daily. Check with your doctor if the swelling worsens.\n\n" +
            "Eat a healthy diet. Aim to eat a diet that includes fruits and vegetables, whole grains, fat-free or low-fat dairy products, and lean proteins.\n\n" +
            "Restrict sodium in your diet. Too much sodium contributes to water retention, which makes your heart work harder and causes shortness of breath and swollen legs, ankles and feet.\n\n" +
            " \n";


}