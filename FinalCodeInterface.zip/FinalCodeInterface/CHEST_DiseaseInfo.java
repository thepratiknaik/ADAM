public interface CHEST_DiseaseInfo {
    //CHEST

    //Pneumonia>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //ABOUT
    String CHEST_Pneumonia_title = "Pneumonia\n";
    String CHEST_Pneumonia_status = "Rare";
    String CHEST_Pneumonia_desc = "Pneumonia is an infection of the lungs with a range of possible causes. It can be a serious and life-threatening disease.\n" +
            "It normally starts with a bacterial, viral, or fungal infection.\n\n" +
            "The lungs become inflamed, and the tiny air sacs, or alveoli, inside the lungs fill up with fluid.\n\n" +
            "Pneumonia can occur in young and healthy people, but it is most dangerous for older adults, infants, people with other diseases, and those with impaired immune systems.\n\n";
    String CHEST_Pneumonia_card_desc = "Pneumonia is an infection of the lungs with a range of possible causes. It can be a serious and life-threatening disease.";

        //SYMPTOMS
        //causes
    String CHEST_Pheumonia_cause_para1 = ".Bacteria and viruses are the main causes of pneumonia. Pneumonia-causing germs can settle in the alveoli and multiply after a person breathes them in.\n\n" +
                ".Pneumonia can be contagious. The bacteria and viruses that cause pneumonia are usually inhaled.\n\n" +
                ".They can be passed on through coughing and sneezing, or spread onto shared objects through touch.\n\n" +
                ".The body sends white blood cells to attack the infection. This is why the air sacs become inflamed. The bacteria and viruses fill the lung sacs with fluid and pus, causing pneumonia.\n\n\n";
        //symptoms
    String CHEST_Pneumonia_symptoms_para1 = "Common symptoms include:\n\n\n" +
                "•\tcough\n\n" +
                "•\trusty or green phlegm, or sputum, coughed up from lungs\\n\n" +
                "•\tfever\n\n" +
                "•\tfast breathing and shortness of breath\n\n" +
                "•\tshaking chills\n\n" +
                "•\tchest pain that usually worsens when taking a deep breath, known as pleuritic pain\n\n" +
                "•\tfast heartbeat\n\n" +
                "•\tfatigue and weakness\n\n" +
                "•\tnausea and vomiting\n\n" +
                "•\tdiarrhea\n\n" +
                "•\tsweating\n\n" +
                "•\theadache\n\n" +
                "•\tmuscle pain\n\n" +
                "•\tconfusion or delirium, especially in older adults\n\n" +
                "•\tdusky or purplish skin color, or cyanosis, from poorly oxygenated blood\n\n" +
                "\n";

        //TREATMENT
        //treatment
    String CHEST_pneumonia_treatment_para1 = "Treatment depends on the type and severity of the pneumonia.\n\n" +
                "•\tBacterial types of pneumonia are usually treated with antibiotics.\n\n" +
                "•\tViral types of pneumonia are usually treated with rest and plenty of fluids. Antiviral medications can be used in influenza.\n\n" +
                "•\tFungal types of pneumonia are usually treated with antifungal medications.\n" +
                "Doctors commonly prescribe over-the-counter (OTC) medications to help manage the symptoms of pneumonia. These include treatments for reducing fever, reducing aches and pains, and suppressing coughs.\n\n" +
                "There are some symptoms which are seen in kids :\n\n\n" +
                "In most children, the immune system can protect them from pneumonia. If a child does develop pneumonia, it is usually due to a virus.\n\n\n";




    //TB>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //ABOUT
    String CHEST_TB_title = "Tuberculosis\n";
    String CHEST_TB_status = "Common\n";
    String CHEST_TB_about = "More than 1 million cases per year (India)\n\n" +
            "Partly preventable by vaccine\n\n" +
            "Treatable by a medical professional\n\n" +
            "Spreads easily\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Medium-term: resolves within months\n\n";
    String CHEST_TB_desc = "Tuberculosis is an infectious disease that usually affects the lungs. Compared with other diseases caused by a single infectious agent, tuberculosis is the second biggest killer, globally.\n\n";
    String CHEST_TB_card_desc = "Tuberculosis is an infectious disease that usually affects the lungs.\n\n";

        //SYMPTOMS
        //symptoms
    String CHEST_TB_symptoms_para1 = "TB symptoms (cough, fever, night sweats, weight loss, etc.) may be mild for many months, and people ill with TB can infect up to 10-15 other people through close contact over the course of a year.\n\n" +
                "TB is an airborne pathogen, meaning that the bacteria that cause TB can spread through the air from person to person\n\n";

        //TREATMENT
        //treatment
    String CHEST_TB_treatment_para1 = "To check for TB, a doctor will use a stethoscope to listen to the lungs and check for swelling in the lymph nodes. They will also ask about symptoms and medical history as well as assessing the individual's risk of exposure to TB.\n\n" +
                "The most common diagnostic test for TB is a skin test where a small injection of PPD tuberculin, an extract of the TB bacterium, is made just below the inside forearm.\n\n" +
                "The injection site should be checked after 2-3 days, and, if a hard, red bump has swollen up to a specific size, then it is likely that TB is present.\n\n" +
                "Unfortunately, the skin test is not 100 percent accurate and has been known to give incorrect positive and negative readings.\n\n" +
                "However, there are other tests that are available to diagnose TB. Blood tests, chest X-rays, and sputum tests can all be used to test for the presence of TB bacteria and may be used alongside a skin test.\n\n\n";
        //home remedies
    String CHEST_TB_homeremedies_para1 = "Probiotics\n\n" +
                "Green Tea\n\n" +
                "Garlic\n\n" +
                "Orange Juice\n\n" +
                "Indian Gooseberry\n\n" +
                "Walnuts\n\n" +
                "Black Pepper\n\n" +
                "Banana\n\n" +
                "Custard Apple\n\n" +
                "Mint\n\n" +
                "Drumstick Leaves\n\n" +
                " \n";



    //ASTHMA>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //ABOUT
    String CHEST_Asthma_title = "Asthma\n";
    String CHEST_Asthma_status = "Very common\n";
    String CHEST_Asthma_about = "More than 10 million cases per year (India)\n\n" +
            "Treatable by a medical professional\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging often required\n\n" +
            "Chronic: can last for years or be lifelong\n" +
            "\n";
    String CHEST_Asthma_desc = "Asthma is an inflammatory disease of the airways to the lungs. It makes breathing difficult and can make some physical activities difficult or even impossible.\n\n" +
            "Normally, with every breath you take, air goes through your nose and down into your throat, into your airways, eventually making it to your lungs. There are lots of small air passages in your lungs that help deliver oxygen from the air into your bloodstream.\n\n" +
            "Asthma symptoms occur when the lining of your airways swell and the muscles around them tighten. Mucus then fills the airways, further reducing the amount of air that can pass through.\n\n";
    String CHEST_Asthma_card_desc = "Asthma is an inflammatory disease of the airways to the lungs.\n\n";

        //SYMPTOMS
        //causes
    String CHEST_Asthma_causes_para1 = "Genetics. If a parent has asthma, you’re more likely to develop it.\n\n" +
                "History of viral infections. People with a history of viral infections during childhood are more likely to develop the condition.\n\n" +
                ". llness. Respiratory illnesses such as the flu and pneumonia can trigger asthma attacks.\n\n" +
                "Exercise. Increased movement may make breathing more difficult.\n\n" +
                "Irritants in the air. People with asthma may be sensitive to irritants such as chemical fumes, strong odors, and smoke.\n\n" +
                "Allergens. Animal dander, dust mites, and pollen are just a few examples of allergens that can trigger symptoms.\n\n" +
                "Extreme weather conditions. Conditions such as very high humidity or low temperaturesmay trigger asthma.\n\n" +
                "Emotions. Shouting, laughing, and crying may trigger an attack.\n\n\n";
    String CHEST_Asthma_symptoms_para1 = "Symptoms of asthma include:\n\n\n" +
            "coughing, especially at night, when laughing, or during exercise\n\n" +
            "wheezing, a squealing or whistling sound made when breathing\n\n" +
            "tightness in the chest\n\n" +
            "shortness of breath\n\n" +
            "fatigue\n\n" +
            "The first indication that you have asthma may not be an actual asthma attack.\n\n\n";

        //TREATMENT
    String CHEST_Asthma_treatment_para1 = "Treatments for asthma fall into three primary categories: breathing exercises, rescue or first aid treatments, and long-term asthma control medications.\n\n" +
                "Breathing exercises\n\n\n" +
                "These exercises can help you get more air into and out of your lungs. Over time, this may help increase lung capacity and cut down on severe asthma symptoms. Your doctor or an occupational therapist can help you learn these breathing exercises for asthma.\n\n\n";
    String CHEST_Asthma_homeremedies_para1 = "Coffee or caffeinated tea\n\n\n" +
            "A chemical in caffeine acts similarly to the asthma drug theophylline. It opens up airways and may ease symptoms of asthma for up to four hours.\n\n" +
            "Purchase coffee and tea online.\n\n" +
            "Mustard oil\n\n\n" +
            "This fatty oil, made from pressed mustard seeds, can be massaged into the skin to help open airways. Mustard oil is different than mustard essential oil, a medicinal oil which shouldn’t be applied directly to the skin.\n\n" +
            "Shop for mustard oil.\n\n" +
            "Other home remedies may help ease symptoms of an asthma attack. Read about even more home remedies that can allow you to breathe more efficiently.\n\n\n";


    //Bronchiectasis>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //ABOUT
    String CHEST_Bronchiectasis_title = "Bronchiectasis \n";
    String CHEST_Bronchiectasis_status = "Common";
    String CHEST_Bronchiectasis_about = "More than 1 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Chronic: can last for years or be lifelong\n\n\n";
    String CHEST_Bronchiectasis_desc = "Bronchiectasis is a condition where the bronchial tubes of your lungs are permanently damaged, widened, and thickened. These damaged air passages allow bacteria and mucus to build up and pool in your lungs. This results in frequent infections and blockages of the airways.\n\n" +
            "There is no cure for bronchiectasis, but it is manageable. With treatment, you can typically live a normal life. However, flare-ups must be treated quickly to maintain oxygen flow to the rest of your body and prevent further lung damage.\n\n\n";
    String CHEST_Bronchietasis_card_desc = "Bronchiectasis is a condition where the bronchial tubes of your lungs are permanently damaged, widened, and thickened.\n\n";

        //SYMPTOMS
    String CHEST_Bronchiectasis_cause_para1 = "Any lung injury can cause bronchiectasis.\n\n\n" +
                "an abnormally functioning immune system\n\n" +
                "inflammatory bowel disease\n\n" +
                "autoimmune diseases\n\n" +
                "chronic obstructive pulmonary disease (COPD)\n\n" +
                "alpha 1-antitrypsin deficiency (an inheritable cause of COPD)\n\n" +
                "HIV\n\n" +
                "allergic aspergillosis (an allergic lung reaction to fungus)\n\n" +
                "lung infections such as whooping cough and tuberculosis\n\n";
    String CHEST_Bronchietasis_symptoms_para1 = "Symptoms of bronchiectasis can take months or even years to develop. Some typical symptoms include:\n\n\n" +
            "chronic daily cough\n\n" +
            "coughing up blood\n\n" +
            "abnormal sounds or wheezing in the chest with breathing\n\n" +
            "shortness of breath\n\n" +
            "chest pain\n\n" +
            "coughing up large amounts of thick mucus every day\n\n" +
            "weight loss\n\n" +
            "fatigue\n\n" +
            "change in the structure of fingernails and toenails, known as clubbing\n\n" +
            "frequent respiratory infections\n\n";
        //TREATMENT
    String CHEST_Bronchietasis_treatment_para1 = "methods for clearing the airways (like breathing exercises and chest physiotherapy)\n\n" +
                "pulmonary rehabilitation\n\n" +
                "antibiotics to prevent and treat infection — studies are currently being done on new formulations of inhaled antibiotics\n\n" +
                "bronchodilators like albuterol (Proventil) and tiotropium (Spiriva) to open up airways\n\n" +
                "medications to thin mucus\n\n" +
                "expectorants to aid in coughing up mucus\n\n" +
                "oxygen therapy\n\n" +
                "vaccinations to prevent respiratory infections\n\n";


    //CysticFibrosis>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //ABOUT
    String CHEST_Fibrosis_title = "Cystic Fibrosis\n";
    String CHEST_Fibrosis_status = "Rare\n";
    String CHEST_Fibrosis_about = "Fewer than 1 million cases per year (India)\n\n" +
            "Treatment can help, but this condition can't be cured\n\n" +
            "Requires a medical diagnosis\n\n" +
            "Lab tests or imaging always required\n\n" +
            "Chronic: can last for years or be lifelong\n\n";
    String CHEST_Fibrosis_desc = "Cystic fibrosis is an inherited disorder that causes severe damage to the lungs, digestive system and other organs in the body.\n\n" +
            "Cystic fibrosis affects the cells that produce mucus, sweat and digestive juices. These secreted fluids are normally thin and slippery. But in people with cystic fibrosis, a defective gene causes the secretions to become sticky and thick. Instead of acting as a lubricant, the secretions plug up tubes, ducts and passageways, especially in the lungs and pancreas.\n\n";
    String CHEST_Fibrosis_card_desc = "Cystic fibrosis is an inherited disorder that causes severe damage to the lungs, digestive system and other organs in the body.\n\n";

        //SYMPTOMS
    String CHEST_Fibrosis_cause_para1 = "In cystic fibrosis, a defect (mutation) in a gene changes a protein that regulates the movement of salt in and out of cells. The result is thick, sticky mucus in the respiratory, digestive and reproductive systems, as well as increased salt in sweat.\n\n" +
                "Many different defects can occur in the gene. The type of gene mutation is associated with the severity of the condition.\n\n" +
                "Children need to inherit one copy of the gene from each parent in order to have the disease. If children inherit only one copy, they won't develop cystic fibrosis. However, they will be carriers and possibly pass the gene to their own children.\n\n";
    String CHEST_Fibrosis_symptoms_para1 = "Respiratory signs and symptoms:\n\n\n" +
            "The thick and sticky mucus associated with cystic fibrosis clogs the tubes that carry air in and out of your lungs. This can cause signs and symptoms such as:\n\n\n" +
            "A persistent cough that produces thick mucus (sputum)\n\n" +
            "Wheezing\n\n" +
            "Breathlessness\n\n" +
            "Exercise intolerance\n\n" +
            "Repeated lung infections\n\n" +
            "Inflamed nasal passages or a stuffy nose\n\n";
    String CHEST_Fibrosis_symptoms_para2 = "Digestive signs and symptoms:\n\n\n" +
            "Foul-smelling, greasy stools\n\n" +
            "Poor weight gain and growth\n\n" +
            "Intestinal blockage, particularly in newborns (meconium ileus)\n\n" +
            "Severe constipation\n\n";

        //TREATMENT
    String CHEST_Fibrosis_treatment_para1 = "There is no cure for cystic fibrosis, but treatment can ease symptoms and reduce complications.\n\n\n" +
                "The goals of treatment include:\n\n\n" +
                "Preventing and controlling infections that occur in the lungs\n\n" +
                "Removing and loosening mucus from the lungs\n\n" +
                "Treating and preventing intestinal blockage\n\n" +
                "Providing adequate nutrition\n\n" +
                "Antibiotics to treat and prevent lung infections\n\n" +
                "Anti-inflammatory medications to lessen swelling in the airways in your lungs\n\n" +
                "Mucus-thinning drugs to help you cough up the mucus, which can improve lung function\n\n" +
                "Inhaled medications called bronchodilators that can help keep your airways open by relaxing the muscles around your bronchial tubes.\n\n";





}
