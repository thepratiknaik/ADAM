public interface KIDNEY_Diseases {

    //KIDNEY
    //KidneyFailure
    //ABOUT
    //about
    String KIDNEY_KidneyFailure_title = "Acute Kidney Failure\n";
    String KIDNEY_KidneyFailure_status = "Common\n";
    String KIDNEY_KidneyFailure_about = "More than 1 million cases per year (India)\n\n" +
            "\n" +
            "Treatable by a medical professional\n\n" +
            "\n" +
            "Requires a medical diagnosis\n\n" +
            "\n" +
            "Lab tests or imaging always required\n\n" +
            "\n" +
            "Short-term: resolves within days to weeks\n\n";
    String KIDNEY_KidneyFailure_desc = "Acute kidney failure occurs when your kidneys suddenly become unable to filter waste products from your blood. When your kidneys lose their filtering ability, dangerous levels of wastes may accumulate, and your blood's chemical makeup may get out of balance.\n\n" +
            "Acute kidney failure — also called acute renal failure or acute kidney injury — develops rapidly, usually in less than a few days. Acute kidney failure is most common in people who are already hospitalized, particularly in critically ill people who need intensive care.\n\n";
    String KIDNEY_KidneyFailure_card_desc = "Acute kidney failure occurs when your kidneys suddenly become unable to filter waste products from your blood.\n\n";

    //Symptoms

    String KIDNEY_KidneyFailure_causes_para1 = "Acute kidney failure can occur when:\n\n" +
            "·\tYou have a condition that slows blood flow to your kidneys\n\n" +
            "·\tYou experience direct damage to your kidneys\n\n" +
            "·\tYour kidneys' urine drainage tubes (ureters) become blocked and wastes can't leave your body through your urine\n\n" +
            "·\tBlood or fluid loss\n\n" +
            "·\tBlood pressure medications\n\n" +
            "·\tHeart attack\n\n" +
            "·\tHeart disease\n\n" +
            "·\tInfection\n\n" +
            "·\tLiver failure\n\n" +
            "·\tUse of aspirin, ibuprofen (Advil, Motrin IB, others), naproxen sodium (Aleve, others) or related drugs\n\n" +
            "·\tSevere allergic reaction (anaphylaxis)\n\n" +
            "·\tSevere burns\n\n" +
            "·\tSevere dehydration\n\n";
    String KIDNEY_KidneyFailure_symptoms_para1 = "The signs and symptoms of Acute Kidney Failure includes:\n\n" +
            "·\tDecreased urine output, although occasionally urine output remains normal\n\n" +
            "·\tFluid retention, causing swelling in your legs, ankles or feet\n\n" +
            "·\tShortness of breath\n\n" +
            "·\tFatigue\n\n" +
            "·\tConfusion\n\n" +
            "·\tNausea\n\n" +
            "·\tWeakness\n\n" +
            "·\tIrregular heartbeat\n\n" +
            "·\tChest pain or pressure\n\n" +
            "·\tSeizures or coma in severe cases\n\n";

    //Treatment

    String KIDNEY_KidneyFailure_treatment_para1 = "Treatment for acute kidney failure typically requires a hospital stay. Most people with acute kidney failure are already hospitalized. How long you'll stay in the hospital depends on the reason for your acute kidney failure and how quickly your kidneys recover.\n\n" +
            "In some cases, you may be able to recover at home.\n\n" +
            "Treating the underlying cause of your kidney injury\n\n" +
            "Treatment for acute kidney failure involves identifying the illness or injury that originally damaged your kidneys. Your treatment options depend on what's causing your kidney failure.\n\n";

    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about
    String KIDNEY_KidneyStone_title = "Kidney Stones\n";
    String KIDNEY_KidneyStone_status = "Common\n";
    String KIDNEY_KidneyStone_about = "More than 1 million cases per year (India)\n\n" +
            "\n" +
            "Treatable by a medical professionan\n" +
            "\n" +
            "Requires a medical diagnosis\n\n" +
            "\n" +
            "Lab tests or imaging often required\n\n" +
            "\n" +
            "Short-term: resolves within days to weeks\n\n" +
            "\n";
    String KIDNEY_KidneyStone_desc = "Kidney stones are the result of a buildup of dissolved minerals on the inner lining of the kidneys.\n" +
            "They usually consist of calcium oxalate but may be composed of several other compounds.\n\n" +
            "Kidney stones can grow to the size of a golf ball while maintaining a sharp, crystalline structure.\n\n" +
            "The stones may be small and pass unnoticed through the urinary tract, but they can also cause extreme pain as they leave the body.\n\n";
    String KIDNEY_KidneyStone_card_desc = "Kidney stones are the result of a buildup of dissolved minerals on the inner lining of the kidneys.\n\n";


    //Symptoms

    String KIDNEY_KidneyStone_causes_para1 = "The leading cause of kidney stones is a lack of water in the body.\n\n" +
            "Stones are more commonly found in individuals who drink less than the recommended eight to ten glasses of water a day.\n\n" +
            "When there is not enough water to dilute the uric acid, a component of urine, the urine becomes more acidic.\n\n" +
            "An excessively acidic environment in urine can lead to the formation of kidney stones.\n\n";
    String KIDNEY_KidneyStone_symptoms_para1 = "Symptoms of kidney stones normally include:\\n\n" +
            "·\tsevere pain in the groin and/or side\n\n" +
            "·\tblood in urine\n\n" +
            "·\tvomiting and nausea\n\n" +
            "·\twhite blood cells or pus in the urine\n\n" +
            "·\treduced amount of urine excreted\n\n" +
            "·\tburning sensation during urination\n\n" +
            "·\tpersistent urge to urinate\n\n" +
            "·\tfever and chills if there is an infection\n\n";


    //Treatment

    String KIDNEY_KidneyStone_treatment_para1 = "Treating kidney stones is primarily focused on symptom management. Passing a stone can be very painful.\n\n" +
            "If a person has a history of kidney stones, home treatment may be suitable. Individuals who have never passed a kidney stone should speak with a doctor.\n\n" +
            "If hospital treatment is needed, an individual may be rehydrated via an intravenous (IV) tube, and anti-inflammatory medication may also be administered.\n\n";
    String KIDNEY_KidneyStone_homeremedies_para1 = "The first is drinking enough water to make the urine completely clear. A person can tell they are not consuming enough water if their urine is yellow or brown.\n\n" +
            "A doctor may also request that a kidney stone is passed naturally though urinating. They will then ask that you retrieved a kidney stone from the urine by filtering it through a stocking or gauze.\n\n" +
            "On studying the retrieved stone, they will be able to determine what further treatment is required.\n\n";

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about
    String KIDNEY_Uremia_title = "Uremia and Uremic  Syndrome\n";
    String KIDNEY_Uremia_status = "Rare\n";
    String KIDNEY_Uremia_about = "Fewer than 1 million cases per year (India)\n\n" +
            "\n" +
            "Treatable by a medical professional\n\n" +
            "\n" +
            "Requires a medical diagnosis\n\n" +
            "\n" +
            "Lab tests or imaging always required\n\n";
    String KIDNEY_Uremia_desc = "Your kidneys filter waste and extra fluid from your blood, and your body gets rid of them through urine. If your kidneys don’t work well, those things can stay in your blood. That condition is called uremia, or uremic syndrome.\n\n";
    String KIDNEY_Uremia_card_desc = "Your kidneys filter waste and extra fluid from your blood, and your body gets rid of them through urine. \n\n";


    //Symptoms

    String KIDNEY_Uremia_symptoms_para1 = "As waste and fluid build up in your blood, you might:\n\n" +
            "·\tFeel nauseated\n\n" +
            "·\tFeel itchy\n\n" +
            "·\tLose your appetite or taste for some foods\n\n" +
            "·\tFeel more tired than usual\n\n" +
            "·\tLose weight\n\n" +
            "·\tHave trouble concentrating\n\n" +
            "·\tFeel pain, numbness, or cramps in your legs or feet (caused by damage to your nerves)\n\n";


    //Treatment

    String KIDNEY_Uremia_treatment_para1 = "This depends on the reason for the problem with your kidneys. If it’s caused by a condition like high blood pressure or diabetes, treating that may keep them from getting worse.\n\n" +
            "If your kidneys are damaged to the point that they’re failing, you may need help getting waste out of your blood. One option is a process called dialysis. It usually involves pumping your blood through a machine that cleans it and sends it back into your body. It can take several hours, and most people who need the treatment need to have it done 3 times a week at a medical center.\n\n";


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //about
    String KIDNEY_KidneyCyst_title = "Kidney Cyst\n";
    String KIDNEY_KidneyCyst_desc = "Kidney cysts are round pouches of fluid that form on or in the kidneys. Kidney cysts can be associated with serious disorders that may impair kidney function. But more commonly, kidney cysts are a type called simple kidney cysts — noncanceros cysts that rarely cause complications.\n\n" +
            "It's not clear what causes simple kidney cysts. Typically, only one cyst occurs on the surface of a kidney, but multiple cysts can affect one or both kidneys. However, simple kidney cysts aren't the same as the cysts that form with polycystic kidney disease.\n\n";
    String KIDNEY_KidneyCyst_card_desc = "Kidney cysts are round pouches of fluid that form on or in the kidneys. Kidney cysts can be associated with serious disorders that may impair kidney function.\n";


    //Symptoms

    String KIDNEY_KidneyCyst_causes_para1 = "It's not clear what causes simple kidney cysts. One theory suggests that kidney cysts develop when the surface layer of the kidney weakens and forms a pouch (diverticulum). The pouch then fills with fluid, detaches and develops into a cyst.\n\n" +
            "Kidney Cyst leads to complications like:\n\n" +
            "·\tAn infected cyst. A kidney cyst may become infected, causing fever and pain.\n\n" +
            "·\tA burst cyst. A kidney cyst that bursts causes severe pain in your back or side.\n\n" +
            "·\tUrine obstruction. A kidney cyst that obstructs the normal flow of urine may lead to swelling of the kidney (hydronephrosis).\n\n";
    String KIDNEY_KidneyCyst_symptoms_para1 = "Simple kidney cysts typically don't cause signs or symptoms. If a simple kidney cyst grows large enough, symptoms may include:\n\n\n" +
            "·\tDull aim in your back or side\n\n" +
            "·\tFever\n\n" +
            "·\tUpper abdominal pain\n\n";


    //Treatment

    String KIDNEY_KidneyCyst_treatment_para1 = "Treatment may not be necessary\\n\n" +
            "If your simple kidney cyst causes no signs or symptoms and doesn't interfere with your kidney function, you may not need treatment. Instead, your doctor may recommend that you have an imaging test, such as ultrasound, periodically to see whether your kidney cyst has enlarged. If your kidney cyst changes and causes signs and symptoms, you may choose to have treatment at that time. Sometimes a simple kidney cyst goes away on its own.\n\n" +
            "Treatments that the doctor will suggest for cyst based on the signs and symptoms:\n\n" +
            "·\tPuncturing and draining the cyst, then filling it with alcohol. Rarely, to shrink the cyst, your doctor inserts a long, thin needle through your skin and through the wall of the kidney cyst. Then the fluid is drained from the cyst. Your doctor may fill the cyst with an alcohol solution to prevent it from reforming\n\n" +
            "·\tSurgery to remove the cyst. A large or symptomatic cyst may require surgery to drain and remove it. To access the cyst, the surgeon makes several small incisions in your skin and inserts special tools and a small video camera. While watching a video monitor in the operating room, the surgeon guides the tools to the kidney and uses them to drain the fluid from the cyst. Then the walls of the cyst are cut or burned away.\n\n";


    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //about
    String KIDNEY_Hematuria_title = "Hematuria(Blood in Urine)\n";
    String KIDNEY_Hematuria_desc = "Seeing blood in your urine can be alarming. While in many instances the cause is harmless, blood in urine (hematuria) can indicate a serious disorder.\n\n" +
            "Blood that you can see is called gross hematuria. Urinary blood that's visible only under a microscope (microscopic hematuria) is found when your doctor tests your urine. Either way, it's important to determine the reason for the bleeding.\n\n";
    String KIDNEY_Hematuria_card_desc = "Seeing blood in your urine can be alarming. While in many instances the cause is harmless, blood in urine (hematuria) can indicate a serious disorder.\n\n";


    //Symptoms

    String KIDNEY_Hematuria_causes_para1 = "In hematuria, your kidneys — or other parts of your urinary tract — allow blood cells to leak into urine. Various problems can cause this leakage, including:\n\n" +
            "Urinary tract infections. These occur when bacteria enter your body through the urethra and multiply in your bladder.\n\n" +
            "Kidney infections (pyelonephritis). These can occur when bacteria enter your kidneys from your bloodstream or move from your ureters to your kidney(s).\n \n" +
            "A bladder or kidney stone. The minerals in concentrated urine sometimes form crystals on the walls of your kidneys or bladder.\n\n" +
            "Enlarged prostate. The prostate gland — which is just below the bladder and surrounding the top part of the urethra — often enlarges as men approach middle age. It then compresses the urethra, partially blocking urine flow.\n \n";
    String KIDNEY_Hematuria_symptoms_para1 = "Gross hematuria produces pink, red or cola-colored urine due to the presence of red blood cells. It takes little blood to produce red urine, and the bleeding usually isn't painful. Passing blood clots in your urine, however, can be painful.\n\n" +
            "Bloody urine often occurs without other signs or symptoms.\n\n";


    //Treatment

    String KIDNEY_Hematuria_treatment_para1 = "Depending on the condition causing your hematuria, treatment might involve taking antibiotics to clear a urinary tract infection, trying a prescription medication to shrink an enlarged prostate or having shock wave therapy to break up bladder or kidney stones. In some cases, no treatment is necessary.\n\n" +
            "Be sure to follow up with your doctor after treatment to ensure there's no more blood in your urine.\n\n";

}